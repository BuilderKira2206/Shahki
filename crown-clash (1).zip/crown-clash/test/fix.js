const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 600 } }); p.on('pageerror', e => console.log('PAGEERROR', e.message));
  await p.goto('file:///home/claude/crown-clash/index.html'); await p.waitForFunction(() => window.__ready); await p.waitForTimeout(800);
  await p.evaluate(() => { Profile.d.xp = 99999; Profile.save(); UI.refreshChip(); });
  await p.locator('#dock button[data-p=collection]').click();
  const cnt = () => p.locator('#pBody .card').count();
  const seq = []; for (const t of ['Доски', 'Шашки', 'Аватары', 'Доски', 'Аватары', 'Шашки']) { await p.locator('.tabs button', { hasText: t }).click(); await p.waitForTimeout(150); seq.push(t + ':' + await cnt() + ':grids=' + await p.locator('#pBody .grid').count()); }
  console.log('tabs (expect avatars13 boards7 sets7, one grid):', seq.join(' | '));
  await p.locator('#dock button[data-p=awards]').click(); await p.locator('.tabs button', { hasText: 'Уровни' }).click(); await p.locator('.tabs button', { hasText: 'Достижения' }).click();
  console.log('ach rows (expect 10):', await p.locator('#pBody .ach').count());
  await p.evaluate(() => { Profile.d.xp = 0; Profile.save(); });
  // cooldown: super-two, cast shield turn 0, track availability over own turns
  await p.locator('#dock button[data-p=awards]').click();
  await p.locator('.mbtn', { hasText: 'Суперрежим' }).click(); await p.locator('.mbtn', { hasText: 'На двоих' }).click(); await p.waitForTimeout(400);
  await p.locator('#dgo').click(); await p.locator('#pgo').click(); await p.locator('#dgo').click(); await p.locator('#pgo').click();
  await p.evaluate(() => { __scene.timeScale = 8; Game.abil[0] = ['shield', 'frost', 'crown']; Game.abil[1] = ['shield', 'frost', 'crown']; });
  await p.waitForFunction(() => Game.inputOn);
  const log = [];
  for (let i = 0; i < 12; i++) {
    await p.waitForFunction(() => Game.inputOn || Game.over, null, { timeout: 20000 });
    const r = await p.evaluate(() => {
      const side = Game.side, before = Game.availAbil(side).includes('shield');
      let note = '';
      if (side === 0 && before && !Game._c) { Game.openAbility('shield'); const t = Abil.combos(Abil.by.shield, Game.S, 0)[0]; Game.onTap(t[0]); Game._c = 1; note = 'CAST'; return { side, before, cd: Game.used[0].shield || 0, note, wait: true }; }
      const m = Game.moves[0]; if (m) { Game.onTap(m.from); for (const c of m.path) Game.onTap(c); }
      return { side, before, cd: Game.used[side].shield || 0, note };
    });
    log.push(`${r.side}:${r.before ? 'avail' : 'cd' + r.cd}${r.note}`); await p.waitForTimeout(250);
  }
  console.log('side0 availability by own turn:', log.filter(x => x.startsWith('0')).join(' '));
  await b.close();
})();
