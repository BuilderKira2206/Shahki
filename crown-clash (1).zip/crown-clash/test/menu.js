const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  for (const [w, h, n] of [[390, 780, 'p'], [1000, 560, 'l']]) {
    const p = await b.newPage({ viewport: { width: w, height: h } }); p.on('pageerror', e => console.log('PAGEERROR', e.message));
    await p.goto('file:///home/claude/crown-clash/index.html'); await p.waitForFunction(() => window.__ready); await p.waitForTimeout(1500);
    await p.locator('#dock button[data-p=profile]').click(); await p.waitForTimeout(1000); await p.screenshot({ path: process.argv[2] + '/' + n + '-prof.png' });
    await p.locator('#dock button[data-p=awards]').click(); await p.waitForTimeout(800); await p.screenshot({ path: process.argv[2] + '/' + n + '-awards.png' });
    await p.locator('#dock button[data-p=help]').click(); await p.waitForTimeout(800); await p.screenshot({ path: process.argv[2] + '/' + n + '-help.png' });
    await p.close();
  }
  await b.close();
})();
