// Plays a whole match in the real page (headless Chromium + swiftshader), driving the UI like a player.
const { chromium } = require('playwright');
const mode = process.argv[2] || 'single', diff = +(process.argv[3] || 0), shotDir = process.argv[4] || '/tmp';
const log = (...a) => console.log(...a);
(async () => {
  const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 640 } });
  const errs = []; p.on('pageerror', e => { errs.push(e.message); log('PAGEERROR', e.message, (e.stack || '').split('\n')[1]); });
  p.on('console', m => { const t = m.text(); if (m.type() === 'error' && !/GL Driver/.test(t)) log('console.error', t); });
  await p.goto('file:///home/claude/crown-clash/index.html'); await p.waitForFunction(() => window.__ready);
  await p.evaluate(() => { __scene.timeScale = 7; });
  const clickBtn = async txt => { await p.locator('.mbtn', { hasText: txt }).first().click(); await p.waitForTimeout(150); };
  if (mode === 'single') { await clickBtn('Одиночная'); await clickBtn(['Лёгкий', 'Средний', 'Сложный'][diff]); }
  else if (mode === 'two') { await clickBtn('На двоих'); }
  else if (mode === 'super-bot') { await clickBtn('Суперрежим'); await clickBtn('Против бота'); await clickBtn(['Лёгкий', 'Средний', 'Сложный'][diff]); }
  else if (mode === 'super-two') { await clickBtn('Суперрежим'); await clickBtn('На двоих'); }
  await p.waitForTimeout(600);
  if (mode.startsWith('super')) {
    await p.screenshot({ path: shotDir + '/draft-' + mode + '.png' });
    await p.locator('#dgo').click();
    if (mode === 'super-two') { await p.locator('#pgo').click(); await p.waitForTimeout(200); await p.locator('#dgo').click(); await p.locator('#pgo').click(); }
  }
  await p.waitForTimeout(500);
  const t0 = Date.now(); let plies = 0, shots = 0, lastTurn = -1, stuck = Date.now(), castsDone = {};
  while (Date.now() - t0 < 170000) {
    const st = await p.evaluate(() => ({ over: Game.over, input: Game.inputOn, turn: Game.turn, side: Game.side, phase: Game.phase }));
    if (st.over) break;
    if (!st.input) { await p.waitForTimeout(120); if (Date.now() - stuck > 40000) { log('STUCK', JSON.stringify(st)); await p.screenshot({ path: shotDir + '/stuck-' + mode + '.png' }); process.exitCode = 2; break; } continue; }
    stuck = Date.now();
    // try an ability now and then in super modes (never the same twice)
    const did = await p.evaluate(async (castsDone) => {
      if (!Game.isSuper()) return null;
      const ids = Game.availAbil(Game.side).filter(id => !castsDone[Game.side + id]); if (!ids.length || Math.random() < .55) return null;
      const id = ids[Math.random() * ids.length | 0], a = Abil.by[id], cs = a.steps.length ? Abil.combos(a, Game.S, Game.side) : [[]]; if (!cs.length) return null;
      const t = cs[Math.random() * cs.length | 0]; Game.openAbility(id); for (const c of t) Game.onTap(c);
      return Game.side + id;
    }, castsDone);
    if (did) { castsDone[did] = 1; log('cast', did); await p.waitForTimeout(300); continue; }
    const ok = await p.evaluate(() => {
      if (!Game.inputOn || Game.phase === 'ability') return false; const ms = Game.moves; if (!ms.length) return false;
      const m = ms[Math.random() * ms.length | 0]; Game.onTap(m.from); for (const c of m.path) Game.onTap(c); return true;
    });
    if (ok) { plies++; if (plies % 12 === 0 && shots < 3) { await p.screenshot({ path: shotDir + '/play-' + mode + '-' + (shots++) + '.png' }); } }
    await p.waitForTimeout(150);
  }
  const res = await p.evaluate(() => ({ over: Game.over, turn: Game.turn, counts: Game.counts(), quiet: Game.quiet, xp: Profile.d.xp, stats: Profile.d.stats }));
  log('RESULT', JSON.stringify(res), 'humanPlies', plies, 'errors', errs.length);
  if (res.over) { await p.waitForSelector('#goR', { timeout: 8000 }).catch(() => log('no gameover modal')); await p.waitForTimeout(2800); await p.screenshot({ path: shotDir + '/over-' + mode + '.png' }); }
  else { log('NOT FINISHED'); await p.screenshot({ path: shotDir + '/unfinished-' + mode + '.png' }); process.exitCode = process.exitCode || 3; }
  await b.close();
})();
