// Triggers each of the 16 abilities on a mid-game position and records frames of the effect.
const { chromium } = require('playwright');
const out = process.argv[2], only = process.argv[3] ? process.argv[3].split(',') : null;
(async () => {
  const b = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const p = await b.newPage({ viewport: { width: 760, height: 480 } });
  const errs = []; p.on('pageerror', e => { errs.push(e.message); console.log('PAGEERROR', e.message, (e.stack || '').split('\n')[1]); });
  await p.goto('file:///home/claude/crown-clash/index.html'); await p.waitForFunction(() => window.__ready);
  await p.locator('.mbtn', { hasText: 'Суперрежим' }).click(); await p.locator('.mbtn', { hasText: 'На двоих' }).click();
  await p.waitForTimeout(500); await p.locator('#dgo').click(); await p.locator('#pgo').click(); await p.locator('#dgo').click(); await p.locator('#pgo').click(); await p.waitForTimeout(400);
  const ids = await p.evaluate(() => Abil.list.map(a => a.id));
  for (const id of ids) {
    if (only && !only.includes(id)) continue;
    // build a lively mid-game position, reset game bookkeeping
    const ok = await p.evaluate((id) => {
      const R = Rules; let S, side;
      for (let tries = 0; tries < 40; tries++) {
        S = R.newState(); S.nid = 100; side = 0;
        for (let n = 0; n < 12; n++) { const ms = R.genMoves(S, side); if (!ms.length) break; const caps = ms.filter(m => m.caps.length); const m = (caps.length ? caps : ms)[Math.random() * (caps.length || ms.length) | 0]; R.apply(S, m); side = 1 - side; }
        if (side !== 0) { const ms = R.genMoves(S, side); if (ms.length) { R.apply(S, ms[0]); side = 0; } }
        // an enemy king for frog / a friendly king for variety
        for (let i = 0; i < 64; i++) if (S.c[i] === 3 && (i >> 3) >= 3 && Math.random() < .3) { S.c[i] = 4; break; }
        if (Abil.usable(id, S, 0, { hist: 1 })) break;
      }
      Game.token++; Game.S = S; Game.side = 0; Game.over = false; Game.active = true; Game.used = [{}, {}]; Game.abil = [[id, 'shield', 'frost'], ['frost', 'shield', 'crown']];
      Game.hist = [{ S: R.clone(S), side: 0 }, { S: R.clone(S), side: 1 }];
      Game.scene.loadState(S); Game.scene.hasteGlow = [false, false]; Game.beginTurn();
      return Abil.usable(id, S, 0, Game.env(0));
    }, id);
    await p.waitForTimeout(500);
    if (!ok) { console.log('skip (not usable)', id); continue; }
    // a pre-frame with the targeting marks, then trigger
    await p.evaluate((id) => { const a = Abil.by[id]; if (!a.steps.length) { return; } Game.openAbility(id); }, id);
    await p.waitForTimeout(350); if (await p.evaluate(() => Game.phase === 'ability')) await p.screenshot({ path: `${out}/${id}-0.png` });
    await p.evaluate((id) => { const a = Abil.by[id]; if (a.steps.length) { const cs = Abil.combos(a, Game.S, Game.side), t = cs[Math.random() * cs.length | 0]; for (const c of t) Game.onTap(c); } else Game.openAbility(id); }, id);
    const shots = id === 'meteor' ? [] : [550, 600, 650];
    let k = 1; for (const dt of shots) { await p.waitForTimeout(dt); await p.screenshot({ path: `${out}/${id}-${k++}.png` }); }
    if (id === 'meteor') {
      await p.waitForFunction(() => Game.inputOn, null, { timeout: 15000 });
      await p.evaluate(() => { const m = Game.moves[0]; Game.onTap(m.from); for (const c of m.path) Game.onTap(c); }); await p.waitForTimeout(1200);
      await p.waitForFunction(() => Game.inputOn, null, { timeout: 15000 }); await p.screenshot({ path: `${out}/${id}-1.png` });
      await p.evaluate(() => { const m = Game.moves[0]; Game.onTap(m.from); for (const c of m.path) Game.onTap(c); });
      await p.waitForTimeout(1350); await p.screenshot({ path: `${out}/${id}-2.png` }); await p.waitForTimeout(500); await p.screenshot({ path: `${out}/${id}-3.png` });
    }
    await p.waitForFunction(() => Game.inputOn || Game.over || Game.phase === 'idle', null, { timeout: 20000 }).catch(() => console.log('timeout waiting after', id));
    const st = await p.evaluate(() => ({ turn: Game.turn, side: Game.side, input: Game.inputOn }));
    console.log('ok', id, JSON.stringify(st));
  }
  console.log('errors', errs.length); await b.close();
})();
