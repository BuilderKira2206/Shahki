/* Crown & Clash — raw WebGL core: matrices, mesh builder, renderer, particles. No external libraries. */
(function (g) {
'use strict';

/* ---------- Matrix math (column-major) ---------- */
const M4 = {};
const _t = new Float32Array(16);
M4.id = () => new Float32Array([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]);
M4.mul = (a, b, o) => {
  o = o || new Float32Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++)
    _t[c*4+r] = a[r]*b[c*4] + a[4+r]*b[c*4+1] + a[8+r]*b[c*4+2] + a[12+r]*b[c*4+3];
  o.set(_t); return o;
};
M4.perspective = (fovDeg, asp, n, f) => {
  const t = 1 / Math.tan(fovDeg * Math.PI / 360), m = new Float32Array(16);
  m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
  return m;
};
M4.lookAt = (e, t, u) => {
  let zx = e[0]-t[0], zy = e[1]-t[1], zz = e[2]-t[2];
  let l = Math.hypot(zx, zy, zz); zx/=l; zy/=l; zz/=l;
  let xx = u[1]*zz - u[2]*zy, xy = u[2]*zx - u[0]*zz, xz = u[0]*zy - u[1]*zx;
  l = Math.hypot(xx, xy, xz); xx/=l; xy/=l; xz/=l;
  const yx = zy*xz - zz*xy, yy = zz*xx - zx*xz, yz = zx*xy - zy*xx;
  return new Float32Array([xx,yx,zx,0, xy,yy,zy,0, xz,yz,zz,0,
    -(xx*e[0]+xy*e[1]+xz*e[2]), -(yx*e[0]+yy*e[1]+yz*e[2]), -(zx*e[0]+zy*e[1]+zz*e[2]), 1]);
};
M4.T = (x, y, z) => { const m = M4.id(); m[12]=x; m[13]=y; m[14]=z; return m; };
M4.S = (x, y, z) => { const m = M4.id(); m[0]=x; m[5]=y===undefined?x:y; m[10]=z===undefined?x:z; return m; };
M4.RY = a => { const m = M4.id(), c = Math.cos(a), s = Math.sin(a); m[0]=c; m[2]=-s; m[8]=s; m[10]=c; return m; };
M4.RX = a => { const m = M4.id(), c = Math.cos(a), s = Math.sin(a); m[5]=c; m[6]=s; m[9]=-s; m[10]=c; return m; };
M4.RZ = a => { const m = M4.id(), c = Math.cos(a), s = Math.sin(a); m[0]=c; m[1]=s; m[4]=-s; m[5]=c; return m; };
M4.trs = (x, y, z, ry, sx, sy, sz, o) => {
  o = o || new Float32Array(16);
  const c = Math.cos(ry), s = Math.sin(ry);
  o[0]=c*sx; o[1]=0; o[2]=-s*sx; o[3]=0; o[4]=0; o[5]=sy; o[6]=0; o[7]=0;
  o[8]=s*sz; o[9]=0; o[10]=c*sz; o[11]=0; o[12]=x; o[13]=y; o[14]=z; o[15]=1; return o;
};
M4.inv = m => {
  const o = new Float32Array(16);
  const a00=m[0],a01=m[1],a02=m[2],a03=m[3],a10=m[4],a11=m[5],a12=m[6],a13=m[7],
        a20=m[8],a21=m[9],a22=m[10],a23=m[11],a30=m[12],a31=m[13],a32=m[14],a33=m[15];
  const b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,
        b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,
        b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;
  let d = b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;
  if (!d) return M4.id(); d = 1/d;
  o[0]=(a11*b11-a12*b10+a13*b09)*d; o[1]=(a02*b10-a01*b11-a03*b09)*d; o[2]=(a31*b05-a32*b04+a33*b03)*d; o[3]=(a22*b04-a21*b05-a23*b03)*d;
  o[4]=(a12*b08-a10*b11-a13*b07)*d; o[5]=(a00*b11-a02*b08+a03*b07)*d; o[6]=(a32*b02-a30*b05-a33*b01)*d; o[7]=(a20*b05-a22*b02+a23*b01)*d;
  o[8]=(a10*b10-a11*b08+a13*b06)*d; o[9]=(a01*b08-a00*b10-a03*b06)*d; o[10]=(a30*b04-a31*b02+a33*b00)*d; o[11]=(a21*b02-a20*b04-a23*b00)*d;
  o[12]=(a11*b07-a10*b09-a12*b06)*d; o[13]=(a00*b09-a01*b07+a02*b06)*d; o[14]=(a31*b01-a30*b03-a32*b00)*d; o[15]=(a20*b03-a21*b01+a22*b00)*d;
  return o;
};
M4.pt = (m, x, y, z) => {
  const w = m[3]*x + m[7]*y + m[11]*z + m[15];
  return [(m[0]*x+m[4]*y+m[8]*z+m[12])/w, (m[1]*x+m[5]*y+m[9]*z+m[13])/w, (m[2]*x+m[6]*y+m[10]*z+m[14])/w];
};
M4.nmat = (m, o) => {
  o = o || new Float32Array(9);
  const a0=[m[0],m[1],m[2]], a1=[m[4],m[5],m[6]], a2=[m[8],m[9],m[10]];
  const cr = (a, b, k) => { o[k]=a[1]*b[2]-a[2]*b[1]; o[k+1]=a[2]*b[0]-a[0]*b[2]; o[k+2]=a[0]*b[1]-a[1]*b[0]; };
  cr(a1, a2, 0); cr(a2, a0, 3); cr(a0, a1, 6); return o;
};

/* ---------- Mesh builder ---------- */
class MB {
  constructor() { this.v = []; this.i = []; }
  add(p, n, c) { this.v.push(p[0],p[1],p[2], n[0],n[1],n[2], c[0],c[1],c[2], c.length>3?c[3]:1); return this.v.length/10-1; }
  tri(a, b, c) { this.i.push(a,b,c); return this; }
  quad(a, b, c, d) { this.i.push(a,b,c, a,c,d); return this; }
  xf(m) {
    const v = this.v, N = M4.nmat(m);
    for (let k = 0; k < v.length; k += 10) {
      const x=v[k], y=v[k+1], z=v[k+2], nx=v[k+3], ny=v[k+4], nz=v[k+5];
      v[k]=m[0]*x+m[4]*y+m[8]*z+m[12]; v[k+1]=m[1]*x+m[5]*y+m[9]*z+m[13]; v[k+2]=m[2]*x+m[6]*y+m[10]*z+m[14];
      let X=N[0]*nx+N[3]*ny+N[6]*nz, Y=N[1]*nx+N[4]*ny+N[7]*nz, Z=N[2]*nx+N[5]*ny+N[8]*nz;
      const l = Math.hypot(X,Y,Z) || 1; v[k+3]=X/l; v[k+4]=Y/l; v[k+5]=Z/l;
    }
    return this;
  }
  tint(c) { const v = this.v; for (let k = 0; k < v.length; k += 10) { v[k+6]*=c[0]; v[k+7]*=c[1]; v[k+8]*=c[2]; } return this; }
  append(o, m) {
    const off = this.v.length/10;
    if (m) { const t = new MB(); t.v = o.v.slice(); t.xf(m); for (const x of t.v) this.v.push(x); }
    else for (const x of o.v) this.v.push(x);
    for (const x of o.i) this.i.push(x + off);
    return this;
  }
  build(gl) {
    if (this.v.length/10 > 65535) throw new Error('mesh too big');
    const vb = gl.createBuffer(), ib = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.v), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(this.i), gl.STATIC_DRAW);
    return { vb, ib, n: this.i.length };
  }
}

const AX = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
const UV = [[[0,1,0],[0,0,1]], [[0,0,1],[0,1,0]], [[0,0,1],[1,0,0]], [[1,0,0],[0,0,1]], [[1,0,0],[0,1,0]], [[0,1,0],[1,0,0]]];
const Prim = {
  box(w, h, d, col, topCol) {
    const m = new MB(), hs = [w/2, h/2, d/2];
    for (let f = 0; f < 6; f++) {
      const n = AX[f], u = UV[f][0], v = UV[f][1];
      const hn = Math.abs(n[0])*hs[0] + Math.abs(n[1])*hs[1] + Math.abs(n[2])*hs[2];
      const hu = Math.abs(u[0])*hs[0] + Math.abs(u[1])*hs[1] + Math.abs(u[2])*hs[2];
      const hv = Math.abs(v[0])*hs[0] + Math.abs(v[1])*hs[1] + Math.abs(v[2])*hs[2];
      const c = (f === 2 && topCol) ? topCol : col, ids = [];
      for (const [su, sv] of [[-1,-1],[1,-1],[1,1],[-1,1]])
        ids.push(m.add([n[0]*hn+u[0]*hu*su+v[0]*hv*sv, n[1]*hn+u[1]*hu*su+v[1]*hv*sv, n[2]*hn+u[2]*hu*su+v[2]*hv*sv], n, c));
      m.quad(ids[0], ids[1], ids[2], ids[3]);
    }
    return m;
  },
  // profile: [[r,y,shade?],...] from bottom centre outward and upward to top centre
  lathe(prof, seg, col, closed) {
    const m = new MB(), nS = prof.length - 1, nn = [];
    for (let k = 0; k < nS; k++) {
      const dr = prof[k+1][0]-prof[k][0], dy = prof[k+1][1]-prof[k][1], l = Math.hypot(dr, dy) || 1;
      nn.push([dy/l, -dr/l]);
    }
    const pn = (k, side) => {
      const a = nn[k], b = side < 0 ? nn[k-1] : nn[k+1];
      if (b && a[0]*b[0]+a[1]*b[1] > 0.55) { const x = a[0]+b[0], y = a[1]+b[1], l = Math.hypot(x, y) || 1; return [x/l, y/l]; }
      return a;
    };
    for (let k = 0; k < nS; k++) {
      const p0 = prof[k], p1 = prof[k+1];
      const n0 = pn(k, -1), n1 = pn(k, 1);
      const sh0 = p0[2] === undefined ? 1 : p0[2], sh1 = p1[2] === undefined ? 1 : p1[2];
      if (Math.hypot(p1[0]-p0[0], p1[1]-p0[1]) < 1e-6) continue;
      const A = [], B = [];
      for (let j = 0; j <= seg; j++) {
        const th = j / seg * Math.PI * 2, c = Math.cos(th), s = Math.sin(th);
        A.push(m.add([p0[0]*c, p0[1], p0[0]*s], [n0[0]*c, n0[1], n0[0]*s], [col[0]*sh0, col[1]*sh0, col[2]*sh0, col[3]===undefined?1:col[3]]));
        B.push(m.add([p1[0]*c, p1[1], p1[0]*s], [n1[0]*c, n1[1], n1[0]*s], [col[0]*sh1, col[1]*sh1, col[2]*sh1, col[3]===undefined?1:col[3]]));
      }
      for (let j = 0; j < seg; j++) m.quad(A[j], B[j], B[j+1], A[j+1]);
    }
    return m;
  },
  sphere(r, seg, rings, col) {
    const p = [];
    for (let i = 0; i <= rings; i++) { const a = -Math.PI/2 + Math.PI*i/rings; p.push([Math.max(0, r*Math.cos(a)), r*Math.sin(a)]); }
    p[0][0] = 0; p[rings][0] = 0;
    return Prim.lathe(p, seg, col);
  },
  cone(r, h, seg, col) { return Prim.lathe([[0,0],[r,0],[0,h]], seg, col); },
  cyl(r, h, seg, col) { return Prim.lathe([[0,0],[r,0],[r,h],[0,h]], seg, col); },
  torus(R, r, seg, segr, col) {
    const p = [];
    for (let i = 0; i <= segr; i++) { const a = -Math.PI/2 + Math.PI*2*i/segr; p.push([R + r*Math.cos(a), r*Math.sin(a)]); }
    return Prim.lathe(p, seg, col);
  },
  disc(r, seg, aC, aE, col) {
    const m = new MB(), c = m.add([0,0,0],[0,1,0],[col[0],col[1],col[2],aC]), e = [];
    for (let j = 0; j <= seg; j++) { const th = j/seg*Math.PI*2; e.push(m.add([r*Math.cos(th),0,r*Math.sin(th)],[0,1,0],[col[0],col[1],col[2],aE])); }
    for (let j = 0; j < seg; j++) m.tri(c, e[j+1], e[j]);
    return m;
  },
  ring(r0, r1, seg, a0, a1, col) {
    const m = new MB(), I = [], O = [];
    for (let j = 0; j <= seg; j++) {
      const th = j/seg*Math.PI*2, c = Math.cos(th), s = Math.sin(th);
      I.push(m.add([r0*c,0,r0*s],[0,1,0],[col[0],col[1],col[2],a0]));
      O.push(m.add([r1*c,0,r1*s],[0,1,0],[col[0],col[1],col[2],a1]));
    }
    for (let j = 0; j < seg; j++) m.quad(I[j], I[j+1], O[j+1], O[j]);
    return m;
  },
  plane(w, d, col) {
    const m = new MB(), x = w/2, z = d/2;
    const a = m.add([-x,0,-z],[0,1,0],col), b = m.add([-x,0,z],[0,1,0],col), c = m.add([x,0,z],[0,1,0],col), e = m.add([x,0,-z],[0,1,0],col);
    m.quad(a, b, c, e); return m;
  }
};

/* ---------- Shaders ---------- */
const VS = `attribute vec3 aPos;attribute vec3 aNor;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uModel;uniform mat3 uNM;
varying vec3 vN;varying vec3 vW;varying vec4 vC;
void main(){vec4 w=uModel*vec4(aPos,1.);vW=w.xyz;vN=normalize(uNM*aNor);vC=aCol;gl_Position=uVP*w;}`;
const FS = `precision mediump float;
uniform vec3 uTint;uniform float uAlpha;uniform vec3 uEmis;uniform float uUnlit;uniform float uSpec;uniform float uShin;uniform float uRim;
uniform vec3 uCam;uniform vec3 uSky;uniform vec3 uGnd;uniform vec3 uKey;uniform vec3 uKeyCol;
varying vec3 vN;varying vec3 vW;varying vec4 vC;
void main(){
  vec3 base=vC.rgb*uTint;float a=vC.a*uAlpha;
  if(uUnlit>.5){gl_FragColor=vec4(base+uEmis,a);return;}
  vec3 N=normalize(vN);vec3 V=normalize(uCam-vW);
  vec3 amb=mix(uGnd,uSky,N.y*.5+.5);
  float nl=max(dot(N,uKey),0.);
  vec3 col=base*(amb+uKeyCol*nl);
  vec3 H=normalize(uKey+V);
  col+=uKeyCol*pow(max(dot(N,H),0.),uShin)*uSpec;
  vec3 F=normalize(vec3(-uKey.x,.35,-uKey.z));
  col+=base*max(dot(N,F),0.)*.14*vec3(.85,.9,1.);
  float rim=pow(1.-clamp(dot(N,V),0.,1.),2.4)*uRim;
  col+=rim*.55;a=clamp(a+rim*.55,0.,1.);
  gl_FragColor=vec4(col+uEmis,a);
}`;
const PVS = `attribute vec3 aPos;attribute float aSize;attribute vec4 aCol;
uniform mat4 uVP;uniform mat4 uRoot;uniform float uPx;varying vec4 vC;
void main(){vec4 p=uVP*uRoot*vec4(aPos,1.);gl_Position=p;gl_PointSize=clamp(aSize*uPx/max(p.w,.1),1.,220.);vC=aCol;}`;
const PFS = `precision mediump float;varying vec4 vC;
void main(){vec2 d=gl_PointCoord-.5;float r=length(d)*2.;if(r>1.)discard;float a=pow(1.-r,1.5);gl_FragColor=vec4(vC.rgb,vC.a*a);}`;

function prog(gl, vs, fs) {
  const mk = (t, s) => { const x = gl.createShader(t); gl.shaderSource(x, s); gl.compileShader(x);
    if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x)); return x; };
  const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const a = gl.getActiveUniform(p, i); u[a.name] = gl.getUniformLocation(p, a.name); }
  return { p, u };
}

/* ---------- Renderer ---------- */
const WHITE = [1,1,1], ZERO = [0,0,0];
class Renderer {
  constructor(cv) {
    this.cv = cv;
    const o = { alpha: true, antialias: true, premultipliedAlpha: true, powerPreference: 'high-performance' };
    const gl = this.gl = cv.getContext('webgl', o) || cv.getContext('experimental-webgl', o);
    if (!gl) throw new Error('WebGL not supported');
    this.main = prog(gl, VS, FS); this.part = prog(gl, PVS, PFS);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
    gl.enable(gl.BLEND); this.blendNormal();
    gl.clearColor(0, 0, 0, 0);
    this.nm = new Float32Array(9);
    this.vp = M4.id(); this.proj = M4.id(); this.cam = [0, 8, 8];
    this.scale = 1; this.W = 2; this.H = 2; this.aspect = 1;
  }
  blendNormal() { const gl = this.gl; gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); }
  blendAdd() { const gl = this.gl; gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); }
  resize(scale) {
    if (scale) this.scale = scale;
    const cv = this.cv, dpr = Math.min(window.devicePixelRatio || 1, 2) * this.scale;
    const w = Math.max(2, Math.floor(cv.clientWidth * dpr)), h = Math.max(2, Math.floor(cv.clientHeight * dpr));
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    this.gl.viewport(0, 0, w, h); this.W = w; this.H = h; this.aspect = w / h;
  }
  setCamera(eye, tgt, fov, sx, sy) {
    this.proj = M4.perspective(fov, this.aspect, 0.5, 80);
    const view = M4.lookAt(eye, tgt, [0, 1, 0]);
    this.vp = M4.mul(M4.mul(M4.T(sx || 0, sy || 0, 0), this.proj), view);
    this.cam = eye; this.inv = M4.inv(this.vp);
  }
  ray(px, py) {
    const x = px / this.cv.clientWidth * 2 - 1, y = 1 - py / this.cv.clientHeight * 2;
    const a = M4.pt(this.inv, x, y, -1), b = M4.pt(this.inv, x, y, 1);
    const d = [b[0]-a[0], b[1]-a[1], b[2]-a[2]], l = Math.hypot(d[0], d[1], d[2]);
    return { o: a, d: [d[0]/l, d[1]/l, d[2]/l] };
  }
  begin() {
    const gl = this.gl, u = this.main.u;
    gl.depthMask(true); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(this.main.p);
    gl.uniformMatrix4fv(u.uVP, false, this.vp); gl.uniform3fv(u.uCam, this.cam);
    gl.uniform3f(u.uSky, 0.56, 0.58, 0.70); gl.uniform3f(u.uGnd, 0.34, 0.28, 0.28);
    const k = [-0.42, 1.0, 0.55], l = Math.hypot(k[0], k[1], k[2]);
    gl.uniform3f(u.uKey, k[0]/l, k[1]/l, k[2]/l); gl.uniform3f(u.uKeyCol, 0.60, 0.54, 0.47);
    const A = gl.getAttribLocation(this.main.p, 'aPos'); this.loc = { p: A, n: gl.getAttribLocation(this.main.p, 'aNor'), c: gl.getAttribLocation(this.main.p, 'aCol') };
    gl.enableVertexAttribArray(this.loc.p); gl.enableVertexAttribArray(this.loc.n); gl.enableVertexAttribArray(this.loc.c);
  }
  draw(mesh, model, o) {
    o = o || {}; const gl = this.gl, u = this.main.u, L = this.loc;
    gl.uniformMatrix4fv(u.uModel, false, model); gl.uniformMatrix3fv(u.uNM, false, M4.nmat(model, this.nm));
    gl.uniform3fv(u.uTint, o.color || WHITE); gl.uniform1f(u.uAlpha, o.alpha === undefined ? 1 : o.alpha);
    gl.uniform3fv(u.uEmis, o.emis || ZERO); gl.uniform1f(u.uUnlit, o.unlit ? 1 : 0);
    gl.uniform1f(u.uSpec, o.spec || 0); gl.uniform1f(u.uShin, o.shin || 32); gl.uniform1f(u.uRim, o.rim || 0);
    if (o.noDepth) gl.depthMask(false);
    if (o.add) this.blendAdd();
    if (o.cullOff) gl.disable(gl.CULL_FACE);
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ib);
    gl.vertexAttribPointer(L.p, 3, gl.FLOAT, false, 40, 0); gl.vertexAttribPointer(L.n, 3, gl.FLOAT, false, 40, 12); gl.vertexAttribPointer(L.c, 4, gl.FLOAT, false, 40, 24);
    gl.drawElements(gl.TRIANGLES, mesh.n, gl.UNSIGNED_SHORT, 0);
    if (o.noDepth) gl.depthMask(true);
    if (o.add) this.blendNormal();
    if (o.cullOff) gl.enable(gl.CULL_FACE);
  }
  mesh(mb) { return mb.build(this.gl); }
}

/* ---------- Particles ---------- */
class Particles {
  constructor(R, max, additive) {
    this.R = R; this.max = max; this.n = 0; this.additive = additive;
    this.p = new Float32Array(max*3); this.v = new Float32Array(max*3); this.c = new Float32Array(max*4);
    this.s = new Float32Array(max); this.l = new Float32Array(max); this.ml = new Float32Array(max);
    this.gr = new Float32Array(max); this.dr = new Float32Array(max); this.gw = new Float32Array(max);
    this.buf = R.gl.createBuffer(); this.data = new Float32Array(max*8);
  }
  emit(x, y, z, vx, vy, vz, col, size, life, grav, drag, grow) {
    if (this.n >= this.max) return; const i = this.n++, a = i*3;
    this.p[a]=x; this.p[a+1]=y; this.p[a+2]=z; this.v[a]=vx; this.v[a+1]=vy; this.v[a+2]=vz;
    this.c[i*4]=col[0]; this.c[i*4+1]=col[1]; this.c[i*4+2]=col[2]; this.c[i*4+3]=col[3] === undefined ? 1 : col[3];
    this.s[i]=size; this.l[i]=this.ml[i]=life; this.gr[i]=grav || 0; this.dr[i]=drag || 0; this.gw[i]=grow === undefined ? 0.3 : grow;
  }
  update(dt) {
    for (let i = 0; i < this.n; i++) {
      this.l[i] -= dt;
      if (this.l[i] <= 0) {
        const j = --this.n; if (i !== j) {
          for (let k = 0; k < 3; k++) { this.p[i*3+k]=this.p[j*3+k]; this.v[i*3+k]=this.v[j*3+k]; }
          for (let k = 0; k < 4; k++) this.c[i*4+k]=this.c[j*4+k];
          this.s[i]=this.s[j]; this.l[i]=this.l[j]; this.ml[i]=this.ml[j]; this.gr[i]=this.gr[j]; this.dr[i]=this.dr[j]; this.gw[i]=this.gw[j];
        }
        i--; continue;
      }
      const a = i*3, d = Math.exp(-this.dr[i]*dt);
      this.v[a]*=d; this.v[a+1]=this.v[a+1]*d - this.gr[i]*dt; this.v[a+2]*=d;
      this.p[a]+=this.v[a]*dt; this.p[a+1]+=this.v[a+1]*dt; this.p[a+2]+=this.v[a+2]*dt;
    }
  }
  draw(root) {
    if (!this.n) return; const R = this.R, gl = R.gl, P = R.part, d = this.data;
    for (let i = 0; i < this.n; i++) {
      const t = this.l[i]/this.ml[i], o = i*8;
      d[o]=this.p[i*3]; d[o+1]=this.p[i*3+1]; d[o+2]=this.p[i*3+2];
      d[o+3]=this.s[i]*(1+(this.gw[i]-1)*(1-t));
      d[o+4]=this.c[i*4]; d[o+5]=this.c[i*4+1]; d[o+6]=this.c[i*4+2]; d[o+7]=this.c[i*4+3]*Math.min(1, t*1.7);
    }
    gl.useProgram(P.p); gl.uniformMatrix4fv(P.u.uVP, false, R.vp); gl.uniformMatrix4fv(P.u.uRoot, false, root);
    gl.uniform1f(P.u.uPx, R.H * R.proj[5] * 0.5);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf); gl.bufferData(gl.ARRAY_BUFFER, d.subarray(0, this.n*8), gl.DYNAMIC_DRAW);
    const a = gl.getAttribLocation(P.p, 'aPos'), s = gl.getAttribLocation(P.p, 'aSize'), c = gl.getAttribLocation(P.p, 'aCol');
    gl.enableVertexAttribArray(a); gl.enableVertexAttribArray(s); gl.enableVertexAttribArray(c);
    gl.vertexAttribPointer(a, 3, gl.FLOAT, false, 32, 0); gl.vertexAttribPointer(s, 1, gl.FLOAT, false, 32, 12); gl.vertexAttribPointer(c, 4, gl.FLOAT, false, 32, 16);
    gl.depthMask(false);
    if (this.additive) R.blendAdd(); else R.blendNormal();
    gl.drawArrays(gl.POINTS, 0, this.n);
    R.blendNormal(); gl.depthMask(true);
    gl.disableVertexAttribArray(a); gl.disableVertexAttribArray(s); gl.disableVertexAttribArray(c);
    gl.useProgram(R.main.p);
    gl.enableVertexAttribArray(R.loc.p); gl.enableVertexAttribArray(R.loc.n); gl.enableVertexAttribArray(R.loc.c);
  }
}

g.M4 = M4; g.MB = MB; g.Prim = Prim; g.Renderer = Renderer; g.Particles = Particles;
})(window);
