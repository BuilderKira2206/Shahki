/* Crown & Clash — player profile, XP/levels, rewards, achievements, settings (localStorage with safe fallback) + synth sound. */
(function (g) {
'use strict';
const KEY = 'crownclash.v1';
const ACH = [
  { id: 'first_win', name: 'Первая победа', desc: 'Выиграйте любую партию против бота', xp: 50, goal: 1 },
  { id: 'first_king', name: 'Первая дамка', desc: 'Проведите шашку в дамки', xp: 30, goal: 1 },
  { id: 'triple', name: 'Тройной прыжок', desc: 'Побейте 3 шашки и больше за один ход', xp: 40, goal: 1 },
  { id: 'sorcerer', name: 'Волшебник', desc: 'Примените 10 суперспособностей', xp: 40, goal: 10, stat: 'casts' },
  { id: 'arsenal', name: 'Полный арсенал', desc: 'Попробуйте 8 разных способностей', xp: 70, goal: 8, stat: 'distinct' },
  { id: 'super_win', name: 'Мастер магии', desc: 'Выиграйте партию в суперрежиме', xp: 60, goal: 1 },
  { id: 'streak3', name: 'Серия побед', desc: 'Выиграйте 3 партии подряд', xp: 60, goal: 3, stat: 'streakBest' },
  { id: 'hard_win', name: 'Покоритель бота', desc: 'Победите сложного бота', xp: 80, goal: 1 },
  { id: 'veteran', name: 'Ветеран', desc: 'Сыграйте 20 партий', xp: 50, goal: 20, stat: 'games' },
  { id: 'duel', name: 'Дуэль', desc: 'Завершите партию на двоих', xp: 25, goal: 1 }
];
const defaults = () => ({
  nick: 'Игрок', avatar: 0, board: 'classic', set: 'classic', xp: 0,
  stats: { games: 0, wins: 0, losses: 0, draws: 0, casts: 0, streak: 0, streakBest: 0, kings: 0, castSet: {}, distinct: 0 },
  ach: {}, settings: { sound: true, quality: 1, diff: 1, qSet: false }
});
let mem = null;
function merge(a, b) { for (const k in b) { if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object') merge(a[k], b[k]); else a[k] = b[k]; } return a; }
const xpNeed = L => 80 + 40 * (L - 1);
const Profile = {
  d: defaults(), ACH,
  load() { let raw = null; try { raw = localStorage.getItem(KEY); } catch (e) { raw = mem; } if (raw) { try { merge(this.d, JSON.parse(raw)); } catch (e) {} } this.fix(); },
  save() { const s = JSON.stringify(this.d); try { localStorage.setItem(KEY, s); } catch (e) { mem = s; } },
  fix() {
    const d = this.d; d.nick = String(d.nick || 'Игрок').slice(0, 14);
    if (!Skins.avatars.some(a => a.id === d.avatar)) d.avatar = 0;
    if (!Skins.boards.some(a => a.id === d.board)) d.board = 'classic';
    if (!Skins.sets.some(a => a.id === d.set)) d.set = 'classic';
  },
  level() { return this.info().level; },
  info() {
    let xp = this.d.xp, L = 1;
    while (L < Skins.MAX_LEVEL && xp >= xpNeed(L)) { xp -= xpNeed(L); L++; }
    const max = L >= Skins.MAX_LEVEL;
    return { level: L, cur: max ? 1 : xp, need: max ? 1 : xpNeed(L), pct: max ? 1 : xp / xpNeed(L), total: this.d.xp, max };
  },
  levelFor(xp) { let L = 1; while (L < Skins.MAX_LEVEL && xp >= xpNeed(L)) { xp -= xpNeed(L); L++; } return L; },
  unlocked(item) { return item.level <= this.level(); },
  rewardsAt(L) {
    const o = [];
    Skins.avatars.forEach(a => { if (a.level === L) o.push({ type: 'avatar', id: a.id, name: 'Аватар: ' + a.name }); });
    Skins.boards.forEach(a => { if (a.level === L) o.push({ type: 'board', id: a.id, name: 'Доска: ' + a.name }); });
    Skins.sets.forEach(a => { if (a.level === L) o.push({ type: 'set', id: a.id, name: 'Шашки: ' + a.name }); });
    return o;
  },
  equip(type, id) { if (type === 'avatar') this.d.avatar = id; else if (type === 'board') this.d.board = id; else this.d.set = id; this.save(); },
  progress(a) { const s = this.d.stats; const v = a.stat ? s[a.stat] : (this.d.ach[a.id] ? 1 : 0); return Math.min(a.goal, v || 0); },
  // report = {mode, diff, result, kings, maxCapture, casts:[ids]}
  finishGame(rep) {
    const d = this.d, s = d.stats, before = this.info().level, items = [], ach = [];
    s.games++;
    const vsBot = rep.mode === 'single' || rep.mode === 'super-bot';
    if (vsBot) {
      if (rep.result === 'win') { s.wins++; s.streak++; s.streakBest = Math.max(s.streakBest, s.streak); }
      else { if (rep.result === 'loss') s.losses++; else s.draws++; s.streak = 0; }
    }
    let base;
    if (!vsBot) base = 35; else base = rep.result === 'win' ? 60 : rep.result === 'draw' ? 30 : 20;
    items.push({ label: !vsBot ? 'Партия на двоих' : rep.result === 'win' ? 'Победа' : rep.result === 'draw' ? 'Ничья' : 'Участие в партии', xp: base });
    if (vsBot && rep.result === 'win' && rep.diff > 0) items.push({ label: rep.diff === 2 ? 'Бонус за сложного бота' : 'Бонус за средний уровень', xp: rep.diff === 2 ? 25 : 10 });
    if (rep.mode.indexOf('super') === 0) items.push({ label: 'Суперрежим', xp: 10 });
    (rep.casts || []).forEach(id => { s.casts++; if (!s.castSet[id]) { s.castSet[id] = 1; s.distinct = Object.keys(s.castSet).length; } });
    s.kings += rep.kings || 0;
    const got = id => { if (d.ach[id]) return; d.ach[id] = 1; const a = ACH.find(x => x.id === id); ach.push(a); items.push({ label: 'Достижение: ' + a.name, xp: a.xp }); };
    if (rep.result === 'win' && vsBot) got('first_win');
    if ((rep.kings || 0) > 0) got('first_king');
    if ((rep.maxCapture || 0) >= 3) got('triple');
    if (s.casts >= 10) got('sorcerer');
    if (s.distinct >= 8) got('arsenal');
    if (rep.result === 'win' && rep.mode === 'super-bot') got('super_win');
    if (s.streakBest >= 3) got('streak3');
    if (rep.result === 'win' && vsBot && rep.diff === 2) got('hard_win');
    if (s.games >= 20) got('veteran');
    if (!vsBot) got('duel');
    const gain = items.reduce((a, x) => a + x.xp, 0), startInfo = this.info();
    d.xp += gain; this.save();
    const after = this.info(), levelUps = [];
    for (let L = before + 1; L <= after.level; L++) levelUps.push({ level: L, rewards: this.rewardsAt(L) });
    return { items, gain, ach, levelUps, from: startInfo, to: after };
  }
};

/* ---------- Sound (WebAudio synth, no files) ---------- */
const SFX = {
  ctx: null, on: true,
  init() {
    if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.ctx = null; } }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  },
  tone(f, dur, type, vol, slide, delay) {
    const c = this.ctx; if (!c || !this.on) return; const t = c.currentTime + (delay || 0), o = c.createOscillator(), gn = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f * slide), t + dur);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol || 0.15, t + 0.012); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(c.destination); o.start(t); o.stop(t + dur + 0.02);
  },
  noise(dur, vol, freq, delay) {
    const c = this.ctx; if (!c || !this.on) return; const t = c.currentTime + (delay || 0), n = Math.floor(c.sampleRate * dur), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = c.createBufferSource(); s.buffer = b; const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq || 1500; const gn = c.createGain(); gn.gain.value = vol || 0.2;
    s.connect(f); f.connect(gn); gn.connect(c.destination); s.start(t);
  },
  play(n) {
    if (!this.ctx || !this.on) return;
    switch (n) {
      case 'ui': this.tone(620, 0.07, 'triangle', 0.08, 1.3); break;
      case 'select': this.tone(520, 0.06, 'sine', 0.09, 1.4); break;
      case 'move': this.tone(170, 0.12, 'sine', 0.2, 0.55); this.noise(0.05, 0.12, 900); break;
      case 'capture': this.tone(150, 0.16, 'sine', 0.22, 0.5); this.noise(0.12, 0.22, 2400); this.tone(760, 0.08, 'square', 0.05, 0.6, 0.02); break;
      case 'king': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.18, 'triangle', 0.12, 1, i * 0.07)); break;
      case 'cast': this.tone(380, 0.5, 'sine', 0.12, 3); this.tone(760, 0.5, 'triangle', 0.06, 2.4, 0.05); break;
      case 'boom': this.noise(0.6, 0.45, 700); this.tone(90, 0.5, 'sine', 0.3, 0.4); break;
      case 'zap': this.noise(0.25, 0.3, 6000); this.tone(1400, 0.2, 'sawtooth', 0.08, 0.3); break;
      case 'ice': [1200, 1600, 2100].forEach((f, i) => this.tone(f, 0.25, 'triangle', 0.06, 0.8, i * 0.05)); break;
      case 'turn': this.tone(440, 0.12, 'sine', 0.08, 1.5); this.tone(660, 0.14, 'sine', 0.08, 1.2, 0.09); break;
      case 'win': [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, 0.28, 'triangle', 0.13, 1, i * 0.11)); break;
      case 'lose': [392, 330, 262, 196].forEach((f, i) => this.tone(f, 0.3, 'sine', 0.13, 0.95, i * 0.14)); break;
      case 'level': [392, 523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, 0.3, 'triangle', 0.12, 1, i * 0.09)); break;
      case 'error': this.tone(180, 0.15, 'square', 0.06, 0.8); break;
    }
  }
};
g.Profile = Profile; g.SFX = SFX;
})(window);
