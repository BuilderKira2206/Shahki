/* Crown & Clash — 16 unique super abilities (logic only; visuals live in vfx.js) + bot decision logic. */
(function (g) {
'use strict';
const R = g.Rules, inb = R.inb, sideOf = R.sideOf, isKing = R.isKing;

const dark = i => (((i >> 3) + (i & 7)) & 1) === 1;
const free = (S, i) => S.c[i] === 0 && S.bl[i] === 0;
const own = (S, side) => { const o = []; for (let i = 0; i < 64; i++) if (S.c[i] && sideOf(S.c[i]) === side) o.push(i); return o; };
const foes = (S, side, f) => { const o = []; for (let i = 0; i < 64; i++) if (S.c[i] && sideOf(S.c[i]) !== side && (!f || f(i))) o.push(i); return o; };
const empties = S => { const o = []; for (let i = 0; i < 64; i++) if (dark(i) && free(S, i)) o.push(i); return o; };
const neighbors = i => { const r = i >> 3, c = i & 7, o = []; for (const d of R.DIRS) if (inb(r+d[0], c+d[1])) o.push((r+d[0])*8 + c+d[1]); return o; };
const move = (S, a, b) => { S.c[b] = S.c[a]; S.id[b] = S.id[a]; S.sh[b] = S.sh[a]; S.fr[b] = S.fr[a]; S.c[a] = 0; S.id[a] = -1; S.sh[a] = 0; S.fr[a] = 0; };
const leaps = (S, i) => {
  const r = i >> 3, c = i & 7, o = [];
  for (const d of R.DIRS) {
    const mr = r+d[0], mc = c+d[1], lr = r+2*d[0], lc = c+2*d[1];
    if (!inb(lr, lc)) continue;
    const mi = mr*8+mc, li = lr*8+lc;
    if (S.c[mi] && free(S, li)) o.push(li);
  }
  return o;
};
const slide = (S, i, dirIdx) => {
  const r = i >> 3, c = i & 7, d = R.DIRS[dirIdx]; let rr = r, cc = c;
  for (;;) {
    const nr = rr + d[0], nc = cc + d[1];
    if (!inb(nr, nc)) return -1;
    if (!free(S, nr*8+nc)) break;
    rr = nr; cc = nc;
  }
  return rr*8+cc;
};
const dirOf = (a, b) => { const dr = Math.sign((b>>3)-(a>>3)), dc = Math.sign((b&7)-(a&7)); return R.DIRS.findIndex(d => d[0] === dr && d[1] === dc); };

const L = [
{ id: 'unicorn', name: 'Единорог', color: '#ff9de2', kind: 'action',
  desc: 'Единорог перепрыгивает вашу шашку через любую соседнюю шашку (даже свою) на свободную клетку за ней. Без взятия. Завершает ход.',
  steps: [
    { prompt: 'Выберите свою шашку для прыжка', mark: 'own', opts: (S, s) => own(S, s).filter(i => !S.fr[i] && leaps(S, i).length) },
    { prompt: 'Выберите клетку приземления', mark: 'empty', opts: (S, s, t) => leaps(S, t[0]) }],
  apply(S, s, t) {
    const a = t[0], b = t[1], id = S.id[a], over = ((a >> 3) + (b >> 3)) / 2 * 8 + ((a & 7) + (b & 7)) / 2;
    move(S, a, b);
    return { id, from: a, to: b, over };
  } },
{ id: 'fireball', name: 'Огненный шар', color: '#ff7a2e', kind: 'action',
  desc: 'Огненный шар уничтожает выбранную шашку соперника и все его простые шашки на соседних по диагонали клетках. Завершает ход.',
  steps: [{ prompt: 'Выберите цель для огненного шара', mark: 'enemy', opts: (S, s) => foes(S, s, i => !S.sh[i]) }],
  apply(S, s, t) {
    const out = [R.kill(S, t[0])];
    for (const n of neighbors(t[0])) if (S.c[n] && sideOf(S.c[n]) !== s && !isKing(S.c[n]) && !S.sh[n]) out.push(R.kill(S, n));
    return { target: t[0], hit: out };
  } },
{ id: 'frost', name: 'Ледяные оковы', color: '#7fe0ff', kind: 'instant',
  desc: 'Замораживает шашку соперника на 2 его хода: она не может ходить, но её по-прежнему можно бить. После этого вы ходите как обычно.',
  steps: [{ prompt: 'Выберите шашку соперника для заморозки', mark: 'enemy', opts: (S, s) => foes(S, s, i => !S.fr[i] && !S.sh[i]) }],
  apply(S, s, t) { S.fr[t[0]] = 2; return { i: t[0], id: S.id[t[0]] }; } },
{ id: 'lightning', name: 'Молния', color: '#ffe85a', kind: 'action', auto: true,
  desc: 'Молния бьёт самую сильную шашку соперника: сначала дамку, иначе самую продвинутую простую шашку. Завершает ход.',
  steps: [],
  usable: (S, s) => foes(S, s, i => !S.sh[i]).length > 0,
  apply(S, s) {
    let best = -1, bv = -1;
    for (const i of foes(S, s, i => !S.sh[i])) {
      const code = S.c[i], r = i >> 3, adv = isKing(code) ? 20 : (sideOf(code) === 0 ? 7 - r : r);
      if (adv > bv) { bv = adv; best = i; }
    }
    return { target: best, hit: [R.kill(S, best)] };
  } },
{ id: 'shield', name: 'Магический щит', color: '#6fb3ff', kind: 'instant',
  desc: 'Выбранную вашу шашку нельзя бить в течение 2 ходов соперника. После этого вы ходите как обычно.',
  steps: [{ prompt: 'Выберите свою шашку под щит', mark: 'own', opts: (S, s) => own(S, s).filter(i => !S.sh[i]) }],
  apply(S, s, t) { S.sh[t[0]] = 2; return { i: t[0], id: S.id[t[0]] }; } },
{ id: 'crown', name: 'Коронация', color: '#ffcf40', kind: 'action',
  desc: 'Мгновенно превращает вашу простую шашку в дамку. Завершает ход.',
  steps: [{ prompt: 'Выберите простую шашку для коронации', mark: 'own', opts: (S, s) => own(S, s).filter(i => !isKing(S.c[i])) }],
  apply(S, s, t) { S.c[t[0]] = s === 0 ? 2 : 4; return { i: t[0], id: S.id[t[0]] }; } },
{ id: 'portal', name: 'Портал', color: '#a06bff', kind: 'action',
  desc: 'Переносит вашу шашку на любую свободную тёмную клетку (кроме ряда превращения). Завершает ход.',
  steps: [
    { prompt: 'Выберите свою шашку для переноса', mark: 'own', opts: (S, s) => own(S, s) },
    { prompt: 'Выберите клетку портала', mark: 'empty', opts: (S, s) => empties(S).filter(i => (i >> 3) !== R.PR(s)) }],
  apply(S, s, t) { const id = S.id[t[0]]; move(S, t[0], t[1]); return { id, from: t[0], to: t[1] }; } },
{ id: 'charm', name: 'Приворот', color: '#ff5fa2', kind: 'action',
  desc: 'Простая шашка соперника навсегда переходит на вашу сторону. Завершает ход.',
  steps: [{ prompt: 'Выберите простую шашку соперника', mark: 'enemy', opts: (S, s) => foes(S, s, i => !isKing(S.c[i]) && !S.sh[i]) }],
  apply(S, s, t) { S.c[t[0]] = s === 0 ? 1 : 3; S.fr[t[0]] = 0; return { i: t[0], id: S.id[t[0]], side: s }; } },
{ id: 'frog', name: 'Лягушка', color: '#7ddc4f', kind: 'instant',
  desc: 'Превращает дамку соперника в простую шашку. Доступно, только если у соперника есть дамка. После этого вы ходите как обычно.',
  steps: [{ prompt: 'Выберите дамку соперника', mark: 'enemy', opts: (S, s) => foes(S, s, i => isKing(S.c[i]) && !S.sh[i]) }],
  apply(S, s, t) { S.c[t[0]] = s === 0 ? 3 : 1; return { i: t[0], id: S.id[t[0]] }; } },
{ id: 'barrier', name: 'Каменная стена', color: '#b9a48a', kind: 'instant',
  desc: 'Создаёт два каменных блока на свободных клетках на 2 круга. Через них нельзя ходить и прыгать. После этого вы ходите как обычно.',
  steps: [
    { prompt: 'Выберите первую клетку для блока', mark: 'empty', opts: S => empties(S) },
    { prompt: 'Выберите вторую клетку для блока', mark: 'empty', opts: (S, s, t) => empties(S).filter(i => i !== t[0]) }],
  apply(S, s, t) { S.bl[t[0]] = 5; S.bl[t[1]] = 5; return { cells: [t[0], t[1]] }; } },
{ id: 'gust', name: 'Ураган', color: '#9fe8d8', kind: 'action',
  desc: 'Сдувает шашку соперника по диагонали до ближайшего препятствия. Если путь до края свободен — шашка улетает с доски. Завершает ход.',
  steps: [
    { prompt: 'Выберите шашку соперника', mark: 'enemy', opts: (S, s) => foes(S, s, i => !S.sh[i] && neighbors(i).some(n => free(S, n))) },
    { prompt: 'Выберите направление ветра', mark: 'empty', opts: (S, s, t) => neighbors(t[0]).filter(n => free(S, n)) }],
  apply(S, s, t) {
    const a = t[0], id = S.id[a], to = slide(S, a, dirOf(a, t[1]));
    if (to < 0) { const k = R.kill(S, a); return { id, from: a, to: -1, dir: dirOf(a, t[1]), hit: [k] }; }
    move(S, a, to); return { id, from: a, to, dir: dirOf(a, t[1]), hit: [] };
  } },
{ id: 'rewind', name: 'Перемотка времени', color: '#6a8cff', kind: 'instant', auto: true,
  desc: 'Отменяет ваш последний ход и ответ соперника. Затем вы ходите заново. Нужны хотя бы два сделанных хода.',
  steps: [],
  usable: (S, s, env) => !!env && env.hist >= 1,
  apply() { return { rewind: true }; } },
{ id: 'haste', name: 'Ускорение', color: '#ffb347', kind: 'instant', auto: true,
  desc: 'Сразу после вашего следующего хода вы ходите ещё раз. Применяется перед ходом.',
  steps: [],
  apply(S, s) { S.haste[s] = 1; return { side: s }; } },
{ id: 'summon', name: 'Призыв', color: '#8fff9f', kind: 'action',
  desc: 'На свободной клетке в ваших трёх домашних рядах появляется новая шашка. Завершает ход.',
  steps: [{ prompt: 'Выберите клетку для призыва', mark: 'empty', opts: (S, s) => empties(S).filter(i => s === 0 ? (i >> 3) >= 5 : (i >> 3) <= 2) }],
  apply(S, s, t) { S.nid = (S.nid || 100) + 1; S.c[t[0]] = s === 0 ? 1 : 3; S.id[t[0]] = S.nid; return { i: t[0], id: S.nid }; } },
{ id: 'meteor', name: 'Метеорит', color: '#ff4d3a', kind: 'instant',
  desc: 'Отмечает клетку. После ответного хода соперника в неё падает метеорит и уничтожает все шашки (любые) на ней и на соседних по диагонали клетках.',
  steps: [{ prompt: 'Выберите клетку удара', mark: 'any', opts: S => { const o = []; for (let i = 0; i < 64; i++) if (dark(i) && !S.mt.some(m => m.i === i)) o.push(i); return o; } }],
  apply(S, s, t) { S.mt.push({ i: t[0], t: 2, side: s }); return { i: t[0] }; },
  sim(S, s, t) { for (const n of [t[0]].concat(neighbors(t[0]))) if (S.c[n]) R.kill(S, n); return {}; } },
{ id: 'swap', name: 'Обмен местами', color: '#d58bff', kind: 'action',
  desc: 'Меняет местами вашу шашку и любую шашку соперника. Завершает ход.',
  steps: [
    { prompt: 'Выберите свою шашку', mark: 'own', opts: (S, s) => own(S, s) },
    { prompt: 'Выберите шашку соперника', mark: 'enemy', opts: (S, s) => foes(S, s) }],
  apply(S, s, t) {
    const a = t[0], b = t[1], ia = S.id[a], ib = S.id[b];
    const c = S.c[a], d = S.id[a], e = S.sh[a], f = S.fr[a];
    S.c[a] = S.c[b]; S.id[a] = S.id[b]; S.sh[a] = S.sh[b]; S.fr[a] = S.fr[b];
    S.c[b] = c; S.id[b] = d; S.sh[b] = e; S.fr[b] = f;
    return { a, b, idA: ia, idB: ib };
  } }
];
const BY = {}; L.forEach(a => { BY[a.id] = a; a.rgb = [parseInt(a.color.slice(1,3),16)/255, parseInt(a.color.slice(3,5),16)/255, parseInt(a.color.slice(5,7),16)/255]; });

const Abil = {
  list: L, by: BY,
  pick3() { const a = L.map(x => x.id); for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, 3); },
  usable(id, S, side, env) {
    const a = BY[id];
    if (a.usable) return a.usable(S, side, env);
    if (!a.steps.length) return true;
    return a.steps[0].opts(S, side, []).length > 0;
  },
  // all complete target tuples (for the bot)
  combos(a, S, side) {
    const out = [];
    const rec = t => {
      if (t.length === a.steps.length) { out.push(t.slice()); return; }
      for (const o of a.steps[t.length].opts(S, side, t)) { t.push(o); rec(t); t.pop(); }
    };
    rec([]); return out;
  },
  // Bot: returns {id, t} or null
  decide(S, side, avail, level, env) {
    const depth = [2, 3, 4][level], thr = [40, 18, 6][level];
    let base = R.value(S, side, depth), cands = [];
    for (const id of avail) {
      const a = BY[id]; if (id === 'rewind' || !Abil.usable(id, S, side, env)) continue;
      let cs = Abil.combos(a, S, side);
      if (cs.length > 120) cs = cs.sort(() => Math.random() - 0.5).slice(0, 120);
      for (const t of cs) {
        const S2 = R.clone(S);
        if (a.sim) a.sim(S2, side, t); else a.apply(S2, side, t);
        let q = R.evaluate(S2, side);
        if (a.id === 'haste') q += 30; if (a.id === 'meteor') q -= 25;
        cands.push({ id, a, t, q });
      }
    }
    if (!cands.length) return null;
    cands.sort((x, y) => y.q - x.q);
    let best = null, bv = -Infinity;
    for (const c of cands.slice(0, 6)) {
      const S2 = R.clone(S);
      if (c.a.sim) c.a.sim(S2, side, c.t); else c.a.apply(S2, side, c.t);
      let v;
      if (c.a.kind === 'action') { R.endTurn(S2, side); v = -R.value(S2, 1 - side, depth - 1); }
      else v = R.value(S2, side, depth);
      if (c.id === 'haste') v += 30; if (c.id === 'meteor') v -= 25;
      if (v > bv) { bv = v; best = c; }
    }
    return best && bv > base + thr ? { id: best.id, t: best.t } : null;
  }
};
g.Abil = Abil;
})(window);
