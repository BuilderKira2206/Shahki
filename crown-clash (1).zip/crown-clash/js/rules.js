/* Crown & Clash — Russian draughts rules, state, search-based bot.
   Board index = row*8+col. Row 7 is the bottom (side 0 / "A" starts there and moves up). Dark squares: (r+c) odd.
   Codes: 1 = A man, 2 = A king, 3 = B man, 4 = B king. */
(function (g) {
'use strict';
const DIRS = [[-1,-1],[-1,1],[1,-1],[1,1]];
const inb = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
const sideOf = code => code < 3 ? 0 : 1;
const isKing = code => (code & 1) === 0;
const PR = side => side === 0 ? 0 : 7;

function newState() {
  const S = { c: new Int8Array(64), id: new Int16Array(64).fill(-1), fr: new Int8Array(64), sh: new Int8Array(64), bl: new Int8Array(64), mt: [], haste: [0, 0] };
  let id = 0;
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    if ((r + c) % 2 !== 1) continue;
    const i = r*8+c;
    if (r < 3) { S.c[i] = 3; S.id[i] = id++; }
    else if (r > 4) { S.c[i] = 1; S.id[i] = id++; }
  }
  return S;
}
function clone(S) {
  return { c: S.c.slice(), id: S.id.slice(), fr: S.fr.slice(), sh: S.sh.slice(), bl: S.bl.slice(), mt: S.mt.map(m => ({ i: m.i, t: m.t, side: m.side })), haste: S.haste.slice(), nid: S.nid };
}

function canTake(S, mi, side, taken) {
  const c = S.c[mi]; return c !== 0 && sideOf(c) !== side && !taken[mi] && !S.sh[mi];
}
function capturesFor(S, from, out) {
  const code = S.c[from], side = sideOf(code), pr = PR(side);
  const empty = i => S.c[i] === 0 && S.bl[i] === 0;
  const taken = new Uint8Array(64), path = [], caps = [];
  S.c[from] = 0;
  const canCap = (pos, king) => {
    const r = pos >> 3, c = pos & 7;
    for (const d of DIRS) {
      if (!king) {
        const lr = r + 2*d[0], lc = c + 2*d[1];
        if (inb(lr, lc) && canTake(S, (r+d[0])*8 + c+d[1], side, taken) && empty(lr*8+lc)) return true;
      } else {
        let rr = r + d[0], cc = c + d[1];
        while (inb(rr, cc) && empty(rr*8+cc)) { rr += d[0]; cc += d[1]; }
        if (inb(rr, cc) && canTake(S, rr*8+cc, side, taken) && inb(rr+d[0], cc+d[1]) && empty((rr+d[0])*8 + cc+d[1])) return true;
      }
    }
    return false;
  };
  const rec = (pos, king, promo) => {
    let any = false; const r = pos >> 3, c = pos & 7;
    for (const d of DIRS) {
      if (!king) {
        const lr = r + 2*d[0], lc = c + 2*d[1]; if (!inb(lr, lc)) continue;
        const mi = (r+d[0])*8 + c+d[1], li = lr*8+lc;
        if (!canTake(S, mi, side, taken) || !empty(li)) continue;
        any = true; taken[mi] = 1; path.push(li); caps.push(mi);
        const np = promo || lr === pr;
        if (!rec(li, np, np)) out.push({ from, path: path.slice(), caps: caps.slice(), promo: np });
        path.pop(); caps.pop(); taken[mi] = 0;
      } else {
        let rr = r + d[0], cc = c + d[1];
        while (inb(rr, cc) && empty(rr*8+cc)) { rr += d[0]; cc += d[1]; }
        if (!inb(rr, cc)) continue;
        const mi = rr*8+cc; if (!canTake(S, mi, side, taken)) continue;
        const lands = []; let lr = rr + d[0], lc = cc + d[1];
        while (inb(lr, lc) && empty(lr*8+lc)) { lands.push(lr*8+lc); lr += d[0]; lc += d[1]; }
        if (!lands.length) continue;
        any = true; taken[mi] = 1; caps.push(mi);
        const conts = lands.map(li => canCap(li, true)), anyCont = conts.some(x => x);
        lands.forEach((li, k) => {
          if (anyCont && !conts[k]) return;
          path.push(li);
          if (!rec(li, true, promo)) out.push({ from, path: path.slice(), caps: caps.slice(), promo });
          path.pop();
        });
        caps.pop(); taken[mi] = 0;
      }
    }
    return any;
  };
  rec(from, isKing(code), false);
  S.c[from] = code;
}
function genMoves(S, side) {
  const caps = [], simple = [], pr = PR(side), fwd = side === 0 ? -1 : 1;
  for (let i = 0; i < 64; i++) {
    const code = S.c[i]; if (!code || sideOf(code) !== side || S.fr[i]) continue;
    capturesFor(S, i, caps);
  }
  if (caps.length) return caps;
  for (let i = 0; i < 64; i++) {
    const code = S.c[i]; if (!code || sideOf(code) !== side || S.fr[i]) continue;
    const r = i >> 3, c = i & 7;
    if (!isKing(code)) {
      for (const dc of [-1, 1]) {
        const rr = r + fwd, cc = c + dc;
        if (inb(rr, cc) && S.c[rr*8+cc] === 0 && !S.bl[rr*8+cc]) simple.push({ from: i, path: [rr*8+cc], caps: [], promo: rr === pr });
      }
    } else {
      for (const d of DIRS) {
        let rr = r + d[0], cc = c + d[1];
        while (inb(rr, cc) && S.c[rr*8+cc] === 0 && !S.bl[rr*8+cc]) { simple.push({ from: i, path: [rr*8+cc], caps: [], promo: false }); rr += d[0]; cc += d[1]; }
      }
    }
  }
  return simple;
}
function apply(S, m) {
  const code = S.c[m.from], id = S.id[m.from], sh = S.sh[m.from], side = sideOf(code);
  S.c[m.from] = 0; S.id[m.from] = -1; S.sh[m.from] = 0; S.fr[m.from] = 0;
  const capIds = [];
  for (const ci of m.caps) { capIds.push({ i: ci, id: S.id[ci] }); S.c[ci] = 0; S.id[ci] = -1; S.sh[ci] = 0; S.fr[ci] = 0; }
  const to = m.path[m.path.length - 1];
  S.c[to] = (m.promo || isKing(code)) ? (side === 0 ? 2 : 4) : code; S.id[to] = id; S.sh[to] = sh;
  return { capIds, promo: !!m.promo && !isKing(code), to, from: m.from, id };
}
function kill(S, i) { const r = { i, id: S.id[i], code: S.c[i] }; S.c[i] = 0; S.id[i] = -1; S.sh[i] = 0; S.fr[i] = 0; return r; }
// ticks effect timers at the end of a turn of `side`; returns meteor impacts
function endTurn(S, side) {
  const impacts = [];
  for (let i = 0; i < 64; i++) {
    const c = S.c[i];
    if (c && sideOf(c) === side && S.fr[i] > 0) S.fr[i]--;
    if (c && sideOf(c) !== side && S.sh[i] > 0) S.sh[i]--;
    if (S.bl[i] > 0) S.bl[i]--;
  }
  for (const m of S.mt) m.t--;
  const keep = [];
  for (const m of S.mt) {
    if (m.t > 0) { keep.push(m); continue; }
    const r = m.i >> 3, c = m.i & 7, hit = [];
    for (const [dr, dc] of [[0,0],[-1,-1],[-1,1],[1,-1],[1,1]]) {
      const rr = r + dr, cc = c + dc; if (!inb(rr, cc)) continue;
      const i = rr*8+cc; if (S.c[i]) hit.push(kill(S, i));
      S.bl[i] = 0;
    }
    impacts.push({ i: m.i, hit });
  }
  S.mt = keep;
  return impacts;
}
function counts(S) {
  const o = { a: 0, b: 0, ak: 0, bk: 0 };
  for (let i = 0; i < 64; i++) { const c = S.c[i]; if (!c) continue; if (sideOf(c) === 0) { o.a++; if (isKing(c)) o.ak++; } else { o.b++; if (isKing(c)) o.bk++; } }
  return o;
}
function evaluate(S, side) {
  let sc = 0;
  for (let i = 0; i < 64; i++) {
    const code = S.c[i]; if (!code) continue;
    const s = sideOf(code), r = i >> 3, c = i & 7;
    let v;
    if (isKing(code)) v = 330 + (3.5 - Math.abs(c - 3.5) + 3.5 - Math.abs(r - 3.5)) * 1.2;
    else { const adv = s === 0 ? 7 - r : r; v = 100 + adv * 4 + (adv === 0 ? 7 : 0) + (3.5 - Math.abs(c - 3.5)) * 1.4; }
    if (S.fr[i]) v -= 14; if (S.sh[i]) v += 9;
    sc += s === side ? v : -v;
  }
  return sc;
}
function order(ms) { return ms.sort((a, b) => b.caps.length - a.caps.length || (b.promo ? 1 : 0) - (a.promo ? 1 : 0)); }
function negamax(S, side, depth, alpha, beta, ply, ctx) {
  if ((++ctx.nodes & 127) === 0 && ctx.deadline && performance.now() > ctx.deadline) ctx.timeout = true;
  if (ctx.timeout) return 0;
  const ms = genMoves(S, side);
  if (!ms.length) return -100000 + ply;
  if (depth <= 0) { if (ms[0].caps.length && ply < ctx.maxPly) depth = 1; else return evaluate(S, side); }
  order(ms);
  let best = -Infinity;
  for (const m of ms) {
    const S2 = clone(S); apply(S2, m); endTurn(S2, side);
    const v = -negamax(S2, 1 - side, depth - 1, -beta, -alpha, ply + 1, ctx);
    if (ctx.timeout) return 0;
    if (v > best) best = v; if (v > alpha) alpha = v; if (alpha >= beta) break;
  }
  return best;
}
function value(S, side, depth) {
  return negamax(S, side, depth, -Infinity, Infinity, 0, { nodes: 0, deadline: 0, timeout: false, maxPly: depth + 4 });
}
// level: 0 easy, 1 medium, 2 hard. Returns {move, score}
function pickMove(S, side, level) {
  const ms = order(genMoves(S, side));
  if (!ms.length) return null;
  if (ms.length === 1) return { move: ms[0], score: 0 };
  const cfg = [{ d: 2, t: 120, noise: 40 }, { d: 4, t: 350, noise: 6 }, { d: 9, t: 800, noise: 0 }][level];
  const ctx = { nodes: 0, deadline: performance.now() + cfg.t, timeout: false, maxPly: 14 };
  let best = { move: ms[0], score: -Infinity }, scored = [];
  for (let d = 1; d <= cfg.d; d++) {
    ctx.timeout = false; let cur = [], alpha = -Infinity;
    for (const m of ms) {
      const S2 = clone(S); apply(S2, m); endTurn(S2, side);
      const v = -negamax(S2, 1 - side, d - 1, -Infinity, Infinity, 1, ctx);
      if (ctx.timeout) break;
      cur.push({ move: m, score: v + (cfg.noise ? (Math.random() - 0.5) * cfg.noise : 0) });
    }
    if (ctx.timeout || cur.length < ms.length) break;
    scored = cur;
    cur.sort((a, b) => b.score - a.score);
    // keep best first for next iteration
    ms.length = 0; for (const x of cur) ms.push(x.move);
    best = cur[0];
    if (Math.abs(best.score) > 50000) break;
  }
  return best;
}

g.Rules = { DIRS, inb, sideOf, isKing, PR, newState, clone, genMoves, apply, kill, endTurn, counts, evaluate, value, pickMove, order };
})(window);
