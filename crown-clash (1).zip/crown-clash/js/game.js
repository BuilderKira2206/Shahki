/* Crown & Clash — match controller: turns, input, bot, abilities, win/draw detection, XP report. */
(function (g) {
'use strict';
const R = g.Rules, Abil = g.Abil;
const sideOf = R.sideOf;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const MARK = { own: [.45, 1, .65], enemy: [1, .4, .35], empty: [.7, .9, 1], any: [1, .55, .3] };
const WHITE = [1, 1, 1], GOLD = [1, .82, .3], ORANGE = [1, .7, .25];

const Game = {
  scene: null, ui: null, active: false, S: null, side: 0, mode: 'single', diff: 1, over: true, inputOn: false, phase: 'idle',
  moves: [], sel: null, partial: [], cands: [], cur: null, abil: [[], []], used: [{}, {}], hist: [], quiet: 0, turn: 0, token: 0,
  kings: 0, maxCap: 0, casts: [], paused: false,
  init(scene, ui) { this.scene = scene; this.ui = ui; },
  isSuper() { return this.mode.indexOf('super') === 0; },
  isBot(side) { return side === 1 && (this.mode === 'single' || this.mode === 'super-bot'); },
  isTwo() { return this.mode === 'two' || this.mode === 'super-two'; },
  names() {
    const me = g.Profile.d.nick, diffName = ['Лёгкий', 'Средний', 'Сложный'][this.diff];
    return this.isTwo() ? [me, 'Игрок 2'] : [me, 'Бот · ' + diffName];
  },
  async start(mode, diff) {
    const sc = this.scene; this.token++;
    this.mode = mode; this.diff = diff === undefined ? 1 : diff; this.over = false; this.active = true; this.paused = false;
    this.S = R.newState(); this.S.nid = 100; this.side = 0; this.hist = []; this.quiet = 0; this.turn = 0; this.kings = 0; this.maxCap = 0; this.casts = []; this.used = [{}, {}];
    this.abil = this.isSuper() ? [Abil.pick3(), Abil.pick3()] : [[], []];
    this.phase = 'idle'; this.inputOn = false; this.sel = null; this.partial = []; this.cur = null; this.pendingAbil = null;
    sc.menu = false; sc.loadState(this.S); sc.marks = []; sc.hasteGlow = [false, false]; sc.setView({ yaw: 0, pitch: .95 }); sc.yaw = 0; sc.yawT = 0;
    this.ui.enterGame(this);
    if (this.isSuper()) { await this.ui.draft(this); if (!this.active) return; }
    this.ui.setTheme(0, true);
    this.beginTurn();
  },
  counts() { return R.counts(this.S); },
  /* ---------- turn flow ---------- */
  async beginTurn(noTick) {
    if (this.over || !this.active) return; const tok = this.token, S = this.S, side = this.side, sc = this.scene;
    if (!noTick) for (const id in this.used[side]) if (this.used[side][id] > 0) this.used[side][id]--;
    this.hist.push({ S: R.clone(S), side }); if (this.hist.length > 30) this.hist.shift();
    const cnt = R.counts(S);
    if ((side === 0 ? cnt.a : cnt.b) === 0) return this.finish(1 - side, 'Все шашки побеждены');
    this.moves = R.genMoves(S, side); this.phase = 'idle'; this.sel = null; this.partial = []; this.cur = null;
    this.ui.setTheme(side); this.ui.refresh();
    if (!this.moves.length) {
      let frozen = false; for (let i = 0; i < 64; i++) if (S.c[i] && sideOf(S.c[i]) === side && S.fr[i]) frozen = true;
      if (frozen) { this.ui.toast('Все ходы заблокированы заморозкой: ход пропущен'); this.inputOn = false; await sleep(1100); if (tok !== this.token) return; return this.afterAction('pass'); }
      if (this.isSuper() && this.availAbil(side).length) {
        if (this.isBot(side)) return this.botTurn();
        this.ui.toast('Нет доступных ходов: примените способность'); this.inputOn = true; this.ui.setPrompt('Нет ходов — выберите способность', false); this.refreshMarks(); return;
      }
      return this.finish(1 - side, side === 0 && this.isBot(1) ? 'Нет доступных ходов' : 'У соперника нет ходов');
    }
    if (this.isBot(side)) return this.botTurn();
    this.inputOn = true; this.ui.setPrompt(this.isTwo() ? 'Ход игрока ' + (side + 1) : 'Ваш ход: выберите шашку', false); this.refreshMarks();
  },
  async afterAction(kind) {
    const S = this.S, side = this.side, sc = this.scene, tok = this.token; this.inputOn = false; this.clearMarks();
    const imp = R.endTurn(S, side);
    for (const i of imp) { await g.Vfx.meteorImpact(sc, i); if (tok !== this.token) return; }
    await sc.syncTo(S, imp.length ? .25 : .05); if (tok !== this.token) return;
    let extra = false;
    if (kind === 'move' && S.haste[side]) { S.haste[side] = 0; sc.hasteGlow[side] = false; extra = true; this.ui.toast('Ускорение: ходите ещё раз'); }
    if (this.quiet >= 60) return this.finish(-1, 'Ничья: 30 ходов без взятий');
    this.turn++; if (!extra) this.side = 1 - side;
    if (this.isTwo() && !extra) { this.ui.setTheme(this.side); sc.setView({ yaw: this.side ? Math.PI : 0 }); SFXp('turn'); await sleep(750); if (tok !== this.token) return; }
    this.beginTurn();
  },
  /* ---------- input ---------- */
  onTap(cell) {
    if (!this.inputOn || this.over || this.paused || cell < 0) return;
    const S = this.S, side = this.side;
    if (this.phase === 'ability') {
      const st = this.cur.a.steps[this.cur.step], opts = st.opts(S, side, this.cur.t);
      if (opts.indexOf(cell) < 0) { SFXp('error'); return; }
      this.cur.t.push(cell); this.cur.step++; SFXp('select');
      if (this.cur.step >= this.cur.a.steps.length) this.castNow(this.cur.id, this.cur.t); else this.showStep();
      return;
    }
    const ownMovable = S.c[cell] && sideOf(S.c[cell]) === side && this.moves.some(m => m.from === cell);
    if (this.sel !== null && this.phase === 'sel') {
      const dests = this.destCells();
      if (dests.indexOf(cell) >= 0) {
        this.partial.push(cell); this.cands = this.cands.filter(m => m.path[this.partial.length - 1] === cell);
        const done = this.cands.find(m => m.path.length === this.partial.length);
        if (done) return this.doMove(done);
        SFXp('select'); this.refreshMarks(); return;
      }
    }
    if (ownMovable && cell !== this.sel) { this.select(cell); return; }
    if (S.c[cell] && sideOf(S.c[cell]) === side) { SFXp('error'); this.ui.toast(this.moves[0] && this.moves[0].caps.length ? 'Обязательно бейте шашку' : 'Эта шашка сейчас не может ходить'); return; }
    if (this.sel !== null) { this.deselect(); }
  },
  select(cell) {
    this.deselect(true); this.sel = cell; this.phase = 'sel'; this.partial = []; this.cands = this.moves.filter(m => m.from === cell);
    const p = this.scene.pieces.get(this.S.id[cell]); if (p) p.lift = .2; SFXp('select'); this.refreshMarks();
  },
  deselect(silent) { if (this.sel !== null) { const p = this.scene.pieces.get(this.S.id[this.sel]); if (p) p.lift = 0; } this.sel = null; this.partial = []; this.cands = []; if (this.phase === 'sel') this.phase = 'idle'; if (!silent) this.refreshMarks(); },
  destCells() { const n = this.partial.length, s = new Set(); for (const m of this.cands) if (m.path.length > n) s.add(m.path[n]); return [...s]; },
  clearMarks() { this.scene.marks = []; for (const p of this.scene.pieces.values()) p.lift = 0; },
  refreshMarks() {
    const sc = this.scene, marks = [], S = this.S; sc.marks = marks;
    if (this.phase === 'ability' && this.cur) { const st = this.cur.a.steps[this.cur.step], col = MARK[st.mark] || WHITE; for (const i of st.opts(S, this.side, this.cur.t)) { marks.push({ kind: 'tile', i, col, a: .35 }); marks.push({ kind: 'ring', i, col }); } for (const t of this.cur.t) marks.push({ kind: 'ring', i: t, col: GOLD }); return; }
    const cap = this.moves.length && this.moves[0].caps.length > 0, seen = new Set();
    for (const m of this.moves) if (!seen.has(m.from) && m.from !== this.sel) { seen.add(m.from); marks.push(cap ? { kind: 'tile', i: m.from, col: ORANGE, a: .38 } : { kind: 'soft', i: m.from, col: WHITE, a: .2 }); }
    if (this.sel !== null) {
      marks.push({ kind: 'ring', i: this.sel, col: GOLD });
      for (const i of this.partial) marks.push({ kind: 'ring', i, col: ORANGE });
      const n = this.partial.length;
      for (const c of this.destCells()) { const isCap = this.cands.some(m => m.path[n] === c && m.caps.length); marks.push({ kind: 'dot', i: c, col: isCap ? [1, .5, .25] : WHITE }); if (isCap) marks.push({ kind: 'ring', i: c, col: [1, .5, .25] }); }
    }
  },
  /* ---------- moves ---------- */
  capFx(c) {
    const sc = this.scene, p = sc.pieces.get(c.id); if (!p) return; sc.pieces.delete(c.id); sc.ghost(p);
    const col = (p.code < 3 ? sc.set.A : sc.set.B); sc.burst(p.x, .3, p.z, col.concat(1), 14, 2.2, 3, .2, .7); sc.burst(p.x, .3, p.z, [1, .9, .6], 8, 1.6, 2, .15, .5); sc.shakeCam(.18); SFXp('capture');
  },
  async doMove(m) {
    this.inputOn = false; const tok = this.token, sc = this.scene, S = this.S, side = this.side; this.clearMarks();
    const p = sc.pieces.get(S.id[m.from]), wasKing = R.isKing(S.c[m.from]); p.lift = 0;
    const res = R.apply(S, m), caps = res.capIds;
    if (!caps.length) SFXp('move');
    await sc.hop(p, m.path, { cap: caps.length > 0, mid: n => { if (caps[n]) this.capFx(caps[n]); } });
    if (tok !== this.token) return;
    const human = !this.isBot(side);
    if (caps.length) { this.quiet = 0; if (human) this.maxCap = Math.max(this.maxCap, caps.length); } else if (!wasKing) this.quiet = 0; else this.quiet++;
    if (m.promo && !wasKing) { this.quiet = 0; if (human) this.kings++; SFXp('king'); }
    await sc.syncTo(S, .2); if (tok !== this.token) return;
    this.ui.refresh(); this.afterAction('move');
  },
  /* ---------- bot ---------- */
  env(side) { return { hist: this.rewindIndex(side) >= 0 ? 1 : 0 }; },
  availAbil(side) { return this.abil[side].filter(id => !(this.used[side][id] > 0) && Abil.usable(id, this.S, side, this.env(side))); },
  async botTurn() {
    this.inputOn = false; this.ui.setPrompt('Соперник думает', false); this.ui.refresh();
    const tok = this.token, S = this.S, side = this.side; await sleep(450); if (tok !== this.token) return;
    if (this.isSuper() && this.turn >= 2) {
      const avail = this.availAbil(side).filter(id => id !== 'rewind');
      if (avail.length && Math.random() < [.3, .45, .6][this.diff]) {
        await sleep(30); const d = Abil.decide(S, side, avail, this.diff, this.env(side)); if (tok !== this.token) return;
        if (d) { const kind = Abil.by[d.id].kind; await this.castNow(d.id, d.t, true); if (tok !== this.token || this.over) return; if (kind === 'action') return; }
      }
    }
    this.moves = R.genMoves(S, side); if (!this.moves.length) { return this.finish(1 - side, 'У соперника нет ходов'); }
    await sleep(30); const r = R.pickMove(S, side, this.diff); if (tok !== this.token) return;
    if (!r) return this.finish(1 - side, 'У соперника нет ходов');
    this.doMove(r.move);
  },
  /* ---------- abilities ---------- */
  rewindIndex(side) { for (let j = this.hist.length - 2; j >= 0; j--) if (this.hist[j].side === side) return j; return -1; },
  openAbility(id) { // from UI, after the user confirmed
    if (!this.inputOn || this.over || this.phase === 'ability' || this.isBot(this.side)) return;
    if (this.used[this.side][id] > 0 || !this.abil[this.side].includes(id)) return;
    if (!Abil.usable(id, this.S, this.side, this.env(this.side))) { SFXp('error'); return; }
    this.deselect(true); const a = Abil.by[id];
    if (!a.steps.length) { this.castNow(id, []); return; }
    this.phase = 'ability'; this.cur = { id, a, step: 0, t: [] }; this.showStep();
  },
  showStep() { const st = this.cur.a.steps[this.cur.step]; this.ui.setPrompt(this.cur.a.name + ': ' + st.prompt.toLowerCase(), true); this.refreshMarks(); this.ui.refresh(); },
  cancelAbility() { if (this.phase !== 'ability') return; this.phase = 'idle'; this.cur = null; this.ui.setPrompt(this.isTwo() ? 'Ход игрока ' + (this.side + 1) : 'Ваш ход: выберите шашку', false); this.refreshMarks(); this.ui.refresh(); },
  async castNow(id, t, byBot) {
    const sc = this.scene, S = this.S, side = this.side, tok = this.token, a = Abil.by[id];
    this.inputOn = false; this.clearMarks(); this.phase = 'idle'; this.cur = null; this.used[side][id] = 4; this.ui.setPrompt('', false);
    if (!byBot || true) this.casts.push(id);
    this.ui.banner(a, byBot ? (this.names()[1]) : null); this.ui.refresh();
    if (id === 'rewind') {
      const j = this.rewindIndex(side), snap = this.hist[j], S2 = R.clone(snap.S); this.hist.length = j;
      await g.Vfx.cast(sc, 'rewind', {}, { side, restore: () => sc.syncTo(S2, 1.0) }); if (tok !== this.token) return;
      this.S = S2; this.quiet = 0; sc.hasteGlow = [false, false]; await sc.syncTo(S2, .01);
      this.beginTurn(true); return;
    }
    const before = R.clone(S), info = a.apply(S, side, t);
    await g.Vfx.cast(sc, id, info, { side, t, S }); if (tok !== this.token) return;
    this.quiet = 0;
    await sc.syncTo(S, .35); if (tok !== this.token) return;
    this.ui.refresh();
    if (a.kind === 'action') { this.afterAction('ability'); return; }
    // instant: the same player continues with a normal move
    this.moves = R.genMoves(S, side);
    if (byBot) return;
    if (!this.moves.length) { const any = this.availAbil(side).length; if (!any) return this.finish(1 - side, 'У соперника нет ходов'); this.ui.toast('Нет ходов: примените ещё способность'); }
    this.inputOn = true; this.phase = 'idle'; this.ui.setPrompt(this.isTwo() ? 'Ход игрока ' + (side + 1) : 'Теперь сделайте ход', false); this.refreshMarks(); this.ui.refresh();
  },
  /* ---------- end of match ---------- */
  async finish(winner, reason) {
    if (this.over) return; this.over = true; this.inputOn = false; const tok = this.token, sc = this.scene; this.clearMarks(); this.ui.setPrompt('', false); this.ui.refresh();
    const two = this.isTwo();
    let result = winner < 0 ? 'draw' : (two ? 'win' : winner === 0 ? 'win' : 'loss');
    const rep = { mode: this.mode, diff: this.diff, result, kings: this.kings, maxCapture: this.maxCap, casts: this.casts };
    const out = g.Profile.finishGame(rep);
    if (winner >= 0 && (two || winner === 0)) { SFXp('win'); g.Vfx.confetti(sc, winner); } else if (winner < 0) SFXp('ui'); else SFXp('lose');
    await sleep(1100); if (tok !== this.token) return;
    this.ui.gameOver({ winner, reason, out, two, mode: this.mode, diff: this.diff, names: this.names() });
  },
  pause(v) { this.paused = v; this.scene.paused = v; },
  quit() { this.token++; this.active = false; this.over = true; this.inputOn = false; this.paused = false; const sc = this.scene; sc.paused = false; sc.marks = []; sc.hasteGlow = [false, false]; sc.tw.length = 0; sc.fx.length = 0; sc.setView({ yaw: 0 }); }
};
function SFXp(n) { try { g.SFX.play(n); } catch (e) {} }
g.Game = Game;
})(window);
