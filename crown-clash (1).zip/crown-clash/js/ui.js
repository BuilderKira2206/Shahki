/* Crown & Clash — all DOM UI: menu, panels, HUD, draft, game over, level-up. No emoji: icons are inline SVG / canvas art. */
(function (g) {
'use strict';
const { Profile, Skins, Art, Abil } = g;
const I = Art.icons;
const $ = (s, r) => (r || document).querySelector(s);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sfx = n => { try { g.SFX.play(n); } catch (e) {} };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const CROWN = '<svg viewBox="0 0 48 34"><path d="M4 28L1.5 7 14 17 24 2 34 17 46.5 7 44 28z" fill="#fff"/><rect x="4" y="29.5" width="40" height="4" rx="2" fill="#fff"/><circle cx="1.5" cy="6" r="3" fill="#fff"/><circle cx="24" cy="2.5" r="3" fill="#fff"/><circle cx="46.5" cy="6" r="3" fill="#fff"/></svg>';
const MINI_CROWN = '<svg viewBox="0 0 48 34" width="14" height="10" style="vertical-align:-1px;margin-right:3px"><path d="M4 28L1.5 7 14 17 24 2 34 17 46.5 7 44 28z" fill="#ffd25a"/></svg>';
const DIFF = ['Лёгкий', 'Средний', 'Сложный'];
const DIFF_SUB = ['Для спокойной партии', 'Достойный соперник', 'Думает на много ходов вперёд'];
const REASON = { 'win': 'Победа', 'loss': 'Поражение', 'draw': 'Ничья' };
const SKIN_SCALE = [.6, .85, 1];

const UI = {
  scene: null, root: null, mode: 'menu', panel: null, panelTab: null, toastT: 0, nav: null, game: null,
  init(scene) {
    this.scene = scene; const root = this.root = $('#root'); this.game = g.Game;
    const menu = this.menuEl = el('div', 'screen'); menu.id = 'menu';
    menu.innerHTML = `
      <div class="chip" id="chip" role="button" tabindex="0" aria-label="Профиль"><img id="chipAv" alt=""><div><div class="nick" id="chipNick"></div><div class="row"><span class="lv" id="chipLv"></span><div class="xpbar"><i id="chipBar"></i></div></div><small id="chipXp"></small></div></div>
      <div id="left"><div class="logo">${CROWN}<h1>CROWN</h1><h2>&amp; CLASH</h2></div><div id="nav"></div></div>
      <div class="dock" id="dock">
        <button data-p="profile">${I.user}<span>Профиль</span></button>
        <button data-p="collection">${I.grid}<span>Коллекция</span></button>
        <button data-p="awards">${I.star}<span>Награды</span></button>
        <button data-p="help">${I.book}<span>Справка</span></button>
        <button data-p="settings">${I.gear}<span>Настройки</span></button>
      </div><div id="panelHost"></div>`;
    const hud = this.hudEl = el('div', 'screen hidden'); hud.id = 'hud';
    hud.innerHTML = `
      <div class="top"><button class="iconbtn" id="pauseBtn" aria-label="Пауза">${I.pause}</button><div class="pcard" id="pc0"></div><div class="sp"></div><div class="pcard right" id="pc1"></div></div>
      <div class="prompt" id="prompt"><span id="promptTx"></span><button class="btn" id="promptCancel">Отмена</button></div>
      <div id="abar"></div><div id="abinfoHost"></div><div id="banner"></div>`;
    const layer = this.layer = el('div'); layer.id = 'layer';
    const toast = this.toastEl = el('div'); toast.id = 'toast';
    root.append(menu, hud, layer, toast);
    this.nav = $('#nav');
    $('#chip').onclick = () => { sfx('ui'); this.openPanel('profile'); };
    $('#chip').onkeydown = e => { if (e.key === 'Enter') this.openPanel('profile'); };
    menu.querySelectorAll('#dock button').forEach(b => b.onclick = () => { sfx('ui'); this.panel === b.dataset.p ? this.closePanel() : this.openPanel(b.dataset.p); });
    $('#pauseBtn').onclick = () => { sfx('ui'); this.pauseMenu(); };
    $('#promptCancel').onclick = () => { sfx('ui'); g.Game.cancelAbility(); };
    this.showMain(); this.refreshChip(); this.layout();
    window.addEventListener('resize', () => this.layout());
    if (window.visualViewport) window.visualViewport.addEventListener('resize', () => this.layout());
  },
  isPortrait() { return window.innerWidth / Math.max(1, window.innerHeight) < .9; },
  layout() {
    const sc = this.scene, p = this.isPortrait(), sup = this.game.active && this.game.isSuper();
    let L;
    if (this.mode === 'game') L = p ? { frac: .98, vfrac: sup ? .5 : .56, sx: 0, sy: sup ? .08 : .05 } : { frac: .82, vfrac: sup ? .72 : .8, sx: 0, sy: sup ? .07 : .02 };
    else if (this.panel) L = p ? { frac: .86, vfrac: .26, sx: 0, sy: .56 } : { frac: .4, vfrac: .68, sx: .5, sy: 0 };
    else L = p ? { frac: .94, vfrac: .36, sx: 0, sy: -.52 } : { frac: .54, vfrac: .8, sx: .38, sy: .05 };
    this.menuEl.classList.toggle('pan', !!this.panel);
    sc.setLayout(L);
  },
  /* ---------- toast / banner ---------- */
  toast(t, ms) { const e = this.toastEl; e.textContent = t; e.classList.add('on'); clearTimeout(this.toastT); this.toastT = setTimeout(() => e.classList.remove('on'), ms || 1900); },
  banner(a, who) {
    const b = $('#banner'); b.innerHTML = '';
    const n = el('div', 'bn'); n.style.setProperty('--bc', a.color);
    n.innerHTML = `<img src="${Art.abilityIcon(a.id)}" alt=""><div><small>${who ? esc(who) + ' применяет' : 'Суперспособность'}</small><b>${esc(a.name)}</b></div>`;
    b.append(n); setTimeout(() => { if (n.parentNode) n.remove(); }, 1750);
  },
  /* ---------- profile chip ---------- */
  refreshChip() {
    const d = Profile.d, i = Profile.info();
    $('#chipAv').src = Art.avatar(d.avatar); $('#chipNick').textContent = d.nick; $('#chipLv').textContent = 'Ур. ' + i.level;
    $('#chipBar').style.width = (i.pct * 100).toFixed(1) + '%'; $('#chipXp').textContent = i.max ? 'XP ' + i.total + ' · максимум' : 'XP ' + i.cur + ' / ' + i.need;
  },
  /* ---------- main navigation ---------- */
  setNav(title, items) {
    const n = this.nav; n.innerHTML = '';
    if (title) n.append(el('div', 'navtitle', esc(title)));
    items.forEach((it, k) => {
      const b = el('button', 'mbtn' + (it.cls ? ' ' + it.cls : '') + (it.sel ? ' sel' : ''), esc(it.label) + (it.sub ? '<small>' + esc(it.sub) + '</small>' : ''));
      b.style.animationDelay = (k * .06) + 's'; b.onclick = () => { sfx('ui'); it.fn(); }; n.append(b);
    });
  },
  showMain() {
    this.setNav(null, [
      { label: 'Одиночная игра', sub: 'Против компьютера', fn: () => this.showDiff('single') },
      { label: 'На двоих', sub: 'Два игрока на одном экране', fn: () => this.begin('two', 1) },
      { label: 'Суперрежим', sub: '16 суперспособностей', fn: () => this.showSuper() }]);
  },
  showDiff(mode) {
    const cur = Profile.d.settings.diff;
    this.setNav('Сложность бота', DIFF.map((d, i) => ({ label: d, sub: DIFF_SUB[i], sel: i === cur, fn: () => this.begin(mode, i) })).concat([{ label: 'Назад', cls: 'back', fn: () => mode === 'single' ? this.showMain() : this.showSuper() }]));
  },
  showSuper() {
    this.setNav('Суперрежим', [
      { label: 'Против бота', sub: '3 случайные способности у каждого', fn: () => this.showDiff('super-bot') },
      { label: 'На двоих', sub: 'Способности для обоих игроков', fn: () => this.begin('super-two', 1) },
      { label: 'Назад', cls: 'back', fn: () => this.showMain() }]);
  },
  begin(mode, diff) {
    sfx('ui'); this.closePanel(true);
    if (mode === 'single' || mode === 'super-bot') { Profile.d.settings.diff = diff; Profile.save(); }
    g.Game.start(mode, diff);
  },
  /* ---------- panels ---------- */
  openPanel(name, tab) {
    this.panel = name; this.panelTab = tab || (name === 'collection' ? (this.panelTab || 'avatars') : name === 'awards' ? (this.panelTab || 'ach') : null);
    this.menuEl.querySelectorAll('#dock button').forEach(b => b.classList.toggle('on', b.dataset.p === name));
    const host = $('#panelHost'); host.innerHTML = '';
    const P = el('div', 'panel'); host.append(P);
    const titles = { profile: 'Профиль', collection: 'Коллекция', awards: 'Награды', help: 'Справка', settings: 'Настройки' };
    P.innerHTML = `<header><h3>${titles[name]}</h3><button class="iconbtn" id="pClose" aria-label="Закрыть">${I.close}</button></header><div id="pTabs"></div><div class="pbody" id="pBody"></div>`;
    $('#pClose').onclick = () => { sfx('ui'); this.closePanel(); };
    this.renderPanel(); this.layout();
  },
  closePanel(quick) {
    if (!this.panel) return; this.panel = null; $('#panelHost').innerHTML = ''; this.menuEl.querySelectorAll('#dock button').forEach(b => b.classList.remove('on')); this.layout();
  },
  tabs(list, cur, fn) {
    const t = $('#pTabs'); t.className = 'tabs'; t.innerHTML = '';
    list.forEach(([id, label]) => { const b = el('button', id === cur ? 'on' : '', esc(label)); b.onclick = () => { sfx('ui'); fn(id); }; t.append(b); });
  },
  renderPanel() {
    const body = $('#pBody'); if (!body) return; body.innerHTML = ''; body.className = 'pbody'; body.scrollTop = 0; $('#pTabs').className = ''; $('#pTabs').innerHTML = '';
    ({ profile: () => this.pProfile(body), collection: () => this.pCollection(body), awards: () => this.pAwards(body), help: () => this.pHelp(body), settings: () => this.pSettings(body) })[this.panel]();
  },
  pProfile(body) {
    const d = Profile.d, i = Profile.info(), s = d.stats;
    body.innerHTML = `<div class="prof-top"><img id="pfAv" alt=""><div style="flex:1;min-width:0"><div class="nickrow"><input id="pfNick" maxlength="14" aria-label="Никнейм" autocomplete="off"><button class="iconbtn" id="pfSave" aria-label="Сохранить">${I.check}</button></div>
      <div class="bigbar"><div class="xpbar"><i style="width:${(i.pct * 100).toFixed(1)}%"></i></div><div class="t"><span>Уровень ${i.level}</span><span>${i.max ? 'Максимум' : i.cur + ' / ' + i.need + ' XP'}</span></div></div></div></div>
      <button class="btn sm" id="pfAvBtn">Сменить аватар</button>
      <div class="secttl">Статистика</div>
      <div class="stats">${[['Партий', s.games], ['Побед', s.wins], ['Поражений', s.losses], ['Ничьих', s.draws], ['Лучшая серия', s.streakBest], ['Дамок', s.kings], ['Способностей', s.casts], ['Разных способностей', s.distinct + ' / 16']].map(x => `<div class="stat"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')}</div>
      <div class="hint">Всего опыта: ${d.xp} XP. Опыт даётся за партии и достижения.</div>`;
    $('#pfAv').src = Art.avatar(d.avatar); $('#pfNick').value = d.nick;
    const save = () => { let v = $('#pfNick').value.replace(/\s+/g, ' ').trim().slice(0, 14) || 'Игрок'; Profile.d.nick = v; $('#pfNick').value = v; Profile.save(); this.refreshChip(); };
    $('#pfNick').onchange = save; $('#pfNick').onkeydown = e => { if (e.key === 'Enter') { save(); e.target.blur(); } };
    $('#pfSave').onclick = () => { save(); sfx('select'); this.toast('Никнейм сохранён'); };
    const toAv = () => { sfx('ui'); this.panelTab = 'avatars'; this.openPanel('collection', 'avatars'); };
    $('#pfAv').onclick = toAv; $('#pfAvBtn').onclick = toAv;
  },
  pCollection(body) {
    const tab = this.panelTab || 'avatars';
    this.tabs([['avatars', 'Аватары'], ['boards', 'Доски'], ['sets', 'Шашки']], tab, id => { this.panelTab = id; this.renderPanel(); });
    const lvl = Profile.level(), d = Profile.d;
    const defs = { avatars: { list: Skins.avatars, cur: d.avatar, thumb: a => Art.avatar(a.id), type: 'avatar', key: a => a.id },
      boards: { list: Skins.boards, cur: d.board, thumb: a => Art.boardThumb(a), type: 'board', key: a => a.id },
      sets: { list: Skins.sets, cur: d.set, thumb: a => Art.setThumb(a), type: 'set', key: a => a.id } }[tab];
    const grid = el('div', 'grid');
    defs.list.forEach(it => {
      const open = it.level <= lvl, eq = defs.key(it) === defs.cur;
      const c = el('div', 'card' + (eq ? ' eq' : '') + (open ? '' : ' lock'));
      c.innerHTML = `<img alt="" src="${defs.thumb(it)}">${eq ? `<div class="tag">${I.check}</div>` : ''}${open ? '' : `<div class="lk">${I.lock}</div>`}<div>${esc(it.name)}</div><small>${open ? (eq ? 'Выбрано' : 'Открыто') : 'Уровень ' + it.level}</small>`;
      c.onclick = () => {
        if (!open) { sfx('error'); this.toast('Откроется на уровне ' + it.level); return; }
        Profile.equip(defs.type, defs.key(it)); sfx('select');
        if (defs.type !== 'avatar') this.scene.setSkin(Profile.d.board, Profile.d.set);
        this.refreshChip(); this.renderPanel();
      };
      grid.append(c);
    });
    body.append(grid);
    body.append(el('div', 'hint', tab === 'avatars' ? 'Новые аватары открываются на некоторых уровнях.' : 'Выбранное оформление сразу видно на доске справа.'));
  },
  pAwards(body) {
    const tab = this.panelTab || 'ach';
    this.tabs([['ach', 'Достижения'], ['lvl', 'Уровни']], tab, id => { this.panelTab = id; this.renderPanel(); });
    if (tab === 'ach') {
      Profile.ACH.forEach(a => {
        const v = Profile.progress(a), done = !!Profile.d.ach[a.id], row = el('div', 'ach' + (done ? ' done' : ''));
        row.innerHTML = `<div class="ic">${done ? I.check : I.star}</div><div class="tx"><b>${esc(a.name)}</b><span>${esc(a.desc)}</span>${a.goal > 1 ? `<div class="xpbar"><i style="width:${Math.min(100, v / a.goal * 100)}%"></i></div>` : ''}</div><div class="xp">${a.goal > 1 && !done ? v + '/' + a.goal : ''}${done ? '' : ' +' + a.xp + ' XP'}</div>`;
        body.append(row);
      });
    } else {
      const lvl = Profile.level(); let curRow = null;
      for (let L = 1; L <= Skins.MAX_LEVEL; L++) {
        const rw = Profile.rewardsAt(L); if (!rw.length && L !== lvl) continue;
        const row = el('div', 'lvrow' + (L === lvl ? ' cur' : L < lvl ? ' past' : '') + (rw.length ? '' : ' none'));
        row.innerHTML = `<div class="n">${L}</div><div class="rwl" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">${rw.map(r => `<img alt="" src="${this.rewardThumb(r)}"><span class="rn">${esc(r.name.replace(/^[^:]+:\s*/, ''))}</span>`).join('') || '<span class="rn">Вы здесь</span>'}</div>`;
        body.append(row); if (L === lvl) curRow = row;
      }
      if (curRow) setTimeout(() => curRow.scrollIntoView({ block: 'center' }), 30);
    }
  },
  rewardThumb(r) { return r.type === 'avatar' ? Art.avatar(r.id) : r.type === 'board' ? Art.boardThumb(Skins.boards.find(b => b.id === r.id)) : Art.setThumb(Skins.sets.find(b => b.id === r.id)); },
  pHelp(body) {
    body.className = 'pbody help';
    body.innerHTML = `<div class="secttl">Правила</div>
      <p>Русские шашки на доске 8x8. Ходят по тёмным клеткам по диагонали. Первым ходит игрок снизу.</p>
      <ul><li>Простая шашка ходит вперёд на одну клетку, а бьёт и вперёд, и назад.</li><li>Бить обязательно. Если можно продолжить взятие, ход продолжается.</li><li>Дойдя до последнего ряда, шашка становится дамкой. Дамка ходит и бьёт на любое расстояние по диагонали.</li><li>Проигрывает тот, у кого не осталось шашек или ходов.</li></ul>
      <div class="secttl">Суперрежим</div>
      <p>В начале партии каждый игрок получает 3 случайные способности из 16. После применения способность перезаряжается 3 ваших хода и снова становится доступной. Выберите способность внизу экрана и следуйте подсказкам.</p>
      <ul><li><b>Завершает ход</b>: способность заменяет ваш ход.</li><li><b>Затем ваш ход</b>: способность применяется перед обычным ходом.</li></ul>
      <div class="secttl">16 способностей</div>`;
    Abil.list.forEach(a => body.append(el('div', 'abil', `<img alt="" src="${Art.abilityIcon(a.id)}"><div><b>${esc(a.name)}<em>${a.kind === 'action' ? 'ход' : 'до хода'}</em></b><span>${esc(a.desc)}</span></div>`)));
  },
  pSettings(body) {
    const s = Profile.d.settings;
    body.innerHTML = `<div class="setrow"><span>Звук</span><button class="sw ${s.sound ? 'on' : ''}" id="stSnd" aria-label="Звук"></button></div>
      <div class="setrow"><span>Качество графики</span><div class="seg" id="stQ">${['Низкое', 'Среднее', 'Высокое'].map((n, i) => `<button data-q="${i}" class="${s.quality === i ? 'on' : ''}">${n}</button>`).join('')}</div></div>
      <div class="hint">Если игра работает медленно на телефоне, выберите низкое качество.</div>
      <div class="setrow"><span>Сложность бота по умолчанию</span><div class="seg" id="stD">${DIFF.map((n, i) => `<button data-d="${i}" class="${s.diff === i ? 'on' : ''}">${n}</button>`).join('')}</div></div>
      <div class="setrow"><span>Сбросить весь прогресс</span><button class="btn sm ghost" id="stReset">Сбросить</button></div>`;
    $('#stSnd').onclick = e => { s.sound = !s.sound; g.SFX.on = s.sound; e.currentTarget.classList.toggle('on', s.sound); Profile.save(); if (s.sound) { g.SFX.init(); sfx('ui'); } };
    $('#stQ').querySelectorAll('button').forEach(b => b.onclick = () => { s.quality = +b.dataset.q; s.qSet = true; Profile.save(); this.applyQuality(); sfx('ui'); this.renderPanel(); });
    $('#stD').querySelectorAll('button').forEach(b => b.onclick = () => { s.diff = +b.dataset.d; Profile.save(); sfx('ui'); this.renderPanel(); });
    $('#stReset').onclick = () => this.confirm('Сбросить прогресс?', 'Уровень, опыт, аватары, оформления и статистика будут удалены. Это нельзя отменить.', 'Сбросить', () => {
      try { localStorage.removeItem('crownclash.v1'); } catch (e) {} location.reload();
    });
  },
  applyQuality() { const q = Profile.d.settings.quality, R = this.scene.R; R.baseScale = SKIN_SCALE[q]; R.resize(SKIN_SCALE[q]); },
  /* ---------- generic modal ---------- */
  modal(html, blue) {
    const m = el('div', 'modal' + ((blue || this.root.classList.contains('s1')) && this.game.isTwo() ? ' blue' : '')), b = el('div', 'box', html); m.append(b); this.layer.append(m);
    return { m, b, close: () => m.remove() };
  },
  confirm(title, text, okLabel, ok) {
    const md = this.modal(`<h2>${esc(title)}</h2><div class="sub">${esc(text)}</div><div class="acts"><button class="btn ghost" id="cNo">Отмена</button><button class="btn" id="cYes">${esc(okLabel)}</button></div>`);
    $('#cNo', md.b).onclick = () => { sfx('ui'); md.close(); }; $('#cYes', md.b).onclick = () => { md.close(); ok(); };
  },
  /* ---------- game screen ---------- */
  enterGame(game) {
    this.mode = 'game'; this.closePanel(); this.menuEl.classList.add('hidden'); this.hudEl.classList.remove('hidden'); this.hudEl.classList.toggle('noab', !game.isSuper());
    this.layer.innerHTML = ''; $('#abinfoHost').innerHTML = ''; this.scene.menu = false; this.layout(); this.scene.setLayout({ snap: false });
    $('#promptTx').textContent = ''; this.buildCards(); this.refresh();
  },
  buildCards() {
    const G = this.game, names = G.names(), d = Profile.d, s = this.scene.set;
    const av = [Art.avatar(d.avatar), G.isTwo() ? Art.avatar(11) : Art.avatar(3)];
    ['pc0', 'pc1'].forEach((id, i) => {
      const c = $('#' + id); c.innerHTML = `<img alt="" src="${av[i]}"><div><b></b><div class="cnt"><span><i style="background:${i ? s.b : s.a}"></i><u data-n="men" style="text-decoration:none">0</u></span><span>${MINI_CROWN}<u data-n="kings" style="text-decoration:none">0</u></span></div><div class="pips"></div></div>`;
      $('b', c).textContent = names[i];
    });
  },
  refresh() {
    const G = this.game; if (!G.active || this.mode !== 'game') return;
    const cnt = G.counts(), sup = G.isSuper();
    [[0, cnt.a, cnt.ak], [1, cnt.b, cnt.bk]].forEach(([i, n, k]) => {
      const c = $('#pc' + i); $('[data-n=men]', c).textContent = n; $('[data-n=kings]', c).textContent = k; c.classList.toggle('act', !G.over && G.side === i);
      const pips = $('.pips', c); pips.innerHTML = sup ? G.abil[i].map(id => `<s class="${G.used[i][id] > 0 ? 'u' : ''}"></s>`).join('') : '';
    });
    this.renderAbilities();
  },
  setTheme(side, snap) { const two = this.game.isTwo(); this.root.classList.toggle('s1', two && side === 1); },
  setPrompt(text, cancel) {
    const p = $('#prompt'); $('#promptTx').textContent = text; p.classList.toggle('think', /^Соперник думает/.test(text)); $('#promptCancel').classList.toggle('hidden', !cancel); p.classList.toggle('hidden', !text);
  },
  renderAbilities() {
    const G = this.game, bar = $('#abar'); if (!G.isSuper()) { bar.innerHTML = ''; return; }
    const view = G.isTwo() ? G.side : 0, ids = G.abil[view], ready = G.inputOn && !G.over && !G.isBot(G.side) && G.phase !== 'ability' && (!G.isTwo() || true);
    const key = [view, G.over, ready, G.phase, ids.map(id => (G.used[view][id] || 0)).join('')].join('|') + '|' + G.turn;
    if (bar.dataset.key === key) return; bar.dataset.key = key; bar.innerHTML = '';
    ids.forEach((id, k) => {
      const a = Abil.by[id], cd = G.used[view][id] || 0, used = cd > 0, usable = !used && Abil.usable(id, G.S, view, G.env(view));
      const b = el('button', 'ab' + (used ? ' used' : '') + (!used && !usable ? ' off' : '') + (!ready && !used ? ' dis' : ''), `<img alt="" src="${Art.abilityIcon(id)}">${used ? `<i class="cdb">${Math.min(cd, 3)}</i>` : ''}<span>${esc(a.name)}</span>`);
      b.style.animationDelay = (k * .07) + 's'; b.onclick = () => { sfx('ui'); this.abilityInfo(id, usable, cd); }; bar.append(b);
    });
    bar.style.pointerEvents = 'none'; bar.querySelectorAll('.ab').forEach(b => b.style.pointerEvents = 'auto');
  },
  abilityInfo(id, usable, cd) {
    const G = this.game, host = $('#abinfoHost'), a = Abil.by[id]; host.innerHTML = '';
    if (cd > 0) { const k = Math.min(cd, 3); this.toast('Перезарядка: ещё ' + k + (k === 1 ? ' ваш ход' : ' ваших хода')); return; }
    if (!G.inputOn) return;
    const warn = { rewind: 'Нужен хотя бы один ваш предыдущий ход.', frog: 'У соперника нет дамок.' }[id] || 'Сейчас нет подходящих целей.';
    const box = el('div', 'abinfo', `<div class="h"><img alt="" src="${Art.abilityIcon(id)}"><div><b>${esc(a.name)}</b><em>${a.kind === 'action' ? 'ЗАМЕНЯЕТ ХОД' : 'ПЕРЕД ХОДОМ'}</em></div></div><p>${esc(a.desc)}</p>${usable ? '' : `<div class="warn">${esc(warn)}</div>`}<div class="acts"><button class="btn ghost sm" id="aiNo">Отмена</button><button class="btn sm" id="aiYes" ${usable ? '' : 'disabled'}>Применить</button></div>`);
    host.append(box);
    $('#aiNo', box).onclick = () => { sfx('ui'); host.innerHTML = ''; };
    $('#aiYes', box).onclick = () => { host.innerHTML = ''; G.openAbility(id); };
  },
  /* ---------- draft ---------- */
  draftScreen(title, sub, ids, btn) {
    return new Promise(res => {
      const cards = ids.map((id, k) => { const a = Abil.by[id]; return `<div class="dcard" style="--c:${a.color};--d:${(k * .14 + .1).toFixed(2)}s"><img alt="" src="${Art.abilityIcon(id)}"><b>${esc(a.name)}</b><span>${esc(a.desc)}</span><em>${a.kind === 'action' ? 'Заменяет ход' : 'Перед ходом'}</em></div>`; }).join('');
      const md = this.modal(`<h2>${esc(title)}</h2><div class="sub">${esc(sub)}</div><div class="cards">${cards}</div><div class="acts"><button class="btn" id="dgo">${esc(btn)}</button></div>`);
      md.b.style.width = 'min(96vw,640px)'; $('#dgo', md.b).onclick = () => { sfx('ui'); md.close(); res(); };
      sfx('cast');
    });
  },
  async draft(G) {
    this.setPrompt('', false);
    if (G.isTwo()) {
      this.root.classList.remove('s1');
      await this.draftScreen('Игрок 1', 'Ваши суперспособности. Игрок 2, не подглядывайте', G.abil[0], 'Запомнил');
      await this.passDevice('Передайте устройство игроку 2');
      this.root.classList.add('s1');
      await this.draftScreen('Игрок 2', 'Ваши суперспособности. Игрок 1, не подглядывайте', G.abil[1], 'Запомнил');
      await this.passDevice('Верните устройство игроку 1, он ходит первым');
      this.root.classList.remove('s1');
    } else await this.draftScreen('Ваши суперспособности', 'После применения способность перезаряжается 3 ваших хода. Бот тоже получил три способности', G.abil[0], 'В бой');
  },
  passDevice(text) {
    return new Promise(res => { const md = this.modal(`<div class="bigicon">${I.swords}</div><h2>${esc(text)}</h2><div class="acts"><button class="btn" id="pgo">Готово</button></div>`); $('#pgo', md.b).onclick = () => { sfx('ui'); md.close(); res(); }; });
  },
  /* ---------- pause / quit ---------- */
  pauseMenu() {
    const G = this.game; if (!G.active || G.over) return; G.pause(true);
    const md = this.modal(`<h2>Пауза</h2><div class="sub">Партия приостановлена</div><div class="acts" style="flex-direction:column;align-items:stretch"><button class="btn" id="pgo">Продолжить</button><button class="btn ghost" id="prs">Начать заново</button><button class="btn ghost" id="pmn">В главное меню</button></div>`);
    $('#pgo', md.b).onclick = () => { sfx('ui'); md.close(); G.pause(false); };
    $('#prs', md.b).onclick = () => { sfx('ui'); md.close(); G.pause(false); G.quit(); this.layer.innerHTML = ''; G.start(G.mode, G.diff); };
    $('#pmn', md.b).onclick = () => { sfx('ui'); md.close(); this.toMenu(); };
  },
  toMenu() {
    const G = this.game; G.quit(); this.mode = 'menu'; this.layer.innerHTML = ''; $('#abinfoHost').innerHTML = ''; $('#abar').innerHTML = ''; $('#abar').dataset.key = '';
    this.hudEl.classList.add('hidden'); this.menuEl.classList.remove('hidden'); this.root.classList.remove('s1'); this.showMain(); this.refreshChip();
    const sc = this.scene; sc.menu = true; sc.menuInit(); sc.setSkin(Profile.d.board, Profile.d.set); this.layout();
  },
  /* ---------- game over + level up ---------- */
  gameOver(r) {
    const { out, winner, two } = r, win = !two && winner === 0, loss = !two && winner === 1;
    const title = winner < 0 ? 'Ничья' : two ? 'Победил игрок ' + (winner + 1) : win ? 'Победа!' : 'Поражение';
    const icon = win || two ? I.star : loss ? I.close : I.swords;
    const rows = out.items.map((x, i) => `<div style="animation-delay:${(.25 + i * .12).toFixed(2)}s"><span>${esc(x.label)}</span><b>+${x.xp} XP</b></div>`).join('');
    const md = this.modal(`<div class="bigicon">${icon}</div><h2>${title}</h2><div class="sub">${esc(r.reason || '')}</div>
      <div class="xpl">${rows}</div><div class="xptot"><span>Получено</span><span style="color:#ffe28a">+${out.gain} XP</span></div>
      <div id="lvbar"><i></i></div><div class="xptot" style="font-size:13px;margin-top:5px"><span id="lvl">Уровень ${out.from.level}</span><span id="lvx"></span></div>
      <div class="acts"><button class="btn" id="goR">Реванш</button><button class="btn ghost" id="goM">В меню</button></div>`, two && winner === 1);
    this.refreshChip();
    const bar = $('#lvbar i', md.b), set = (p, tr) => { bar.style.transition = tr ? 'width .9s cubic-bezier(.2,.8,.2,1)' : 'none'; bar.style.width = (p * 100) + '%'; };
    set(out.from.pct, false); $('#lvx', md.b).textContent = out.from.max ? '' : out.from.cur + ' / ' + out.from.need + ' XP';
    const total = .3 + out.items.length * .12 + .4;
    setTimeout(async () => {
      if (out.to.level > out.from.level) { set(1, true); await sleep(1000); set(0, false); void bar.offsetWidth; $('#lvl', md.b).textContent = 'Уровень ' + out.to.level; }
      set(out.to.pct, true); $('#lvx', md.b).textContent = out.to.max ? 'Максимум' : out.to.cur + ' / ' + out.to.need + ' XP'; $('#lvl', md.b).textContent = 'Уровень ' + out.to.level;
      for (const lu of out.levelUps) { await sleep(700); await this.levelUp(lu); }
    }, total * 1000);
    $('#goR', md.b).onclick = () => { sfx('ui'); md.close(); this.layer.innerHTML = ''; g.Game.start(r.mode, r.diff); };
    $('#goM', md.b).onclick = () => { sfx('ui'); md.close(); this.toMenu(); };
  },
  levelUp(lu) {
    return new Promise(res => {
      sfx('level'); const m = el('div', 'lvl-modal'); m.append(el('div', 'rays'));
      const rw = lu.rewards.map((r, k) => `<div class="rw" style="--d:${(.9 + k * .22).toFixed(2)}s"><img alt="" src="${this.rewardThumb(r)}"><span>${esc(r.name)}</span></div>`).join('');
      const c = el('div', 'lvl-card', `<div class="ring"></div><div class="ring r2"></div><div class="t1">НОВЫЙ УРОВЕНЬ</div><div class="num">${lu.level}</div>${rw ? `<div class="rwds">${rw}</div>` : '<div style="height:18px"></div>'}<button class="btn">Отлично</button>`);
      m.append(c); this.layer.append(m);
      for (let i = 0; i < 26; i++) { const s = el('div', 'sparkle'); const a = Math.random() * 6.28, d = 120 + Math.random() * 260; s.style.left = '50%'; s.style.top = '42%'; s.style.setProperty('--x', Math.cos(a) * d + 'px'); s.style.setProperty('--y', Math.sin(a) * d + 'px'); s.style.animationDelay = (Math.random() * .6) + 's'; m.append(s); }
      $('.btn', c).onclick = () => { sfx('ui'); m.remove(); res(); };
    });
  }
};
g.UI = UI;
})(window);
