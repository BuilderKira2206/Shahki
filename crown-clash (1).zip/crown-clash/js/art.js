/* Crown & Clash — procedurally drawn art: avatars (original), ability icons, skin thumbnails, UI icons. No external images, no emoji. */
(function (g) {
'use strict';
const OUT = '#1d1a1f';
const cache = {};
function cv(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h || w; return c; }
function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x+r, y); c.arcTo(x+w, y, x+w, y+h, r); c.arcTo(x+w, y+h, x, y+h, r); c.arcTo(x, y+h, x, y, r); c.arcTo(x, y, x+w, y, r); c.closePath(); }
function tile(c, c1, c2) {
  const S = 128, gr = c.createLinearGradient(0, 0, 0, S); gr.addColorStop(0, c1); gr.addColorStop(1, c2);
  c.fillStyle = gr; c.fillRect(0, 0, S, S);
  c.fillStyle = 'rgba(255,255,255,.14)'; rr(c, 8, 8, 112, 50, 10); c.fill();
}
function E(c, x, y, rx, ry, fill, stroke, lw, rot) {
  c.beginPath(); c.ellipse(x, y, rx, ry, rot || 0, 0, Math.PI*2);
  if (fill) { c.fillStyle = fill; c.fill(); } if (stroke !== null) { c.lineWidth = lw || 4; c.strokeStyle = stroke || OUT; c.stroke(); }
}
function P(c, pts, fill, stroke, lw) {
  c.beginPath(); pts.forEach((p, i) => i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1])); c.closePath();
  c.lineJoin = 'round'; if (fill) { c.fillStyle = fill; c.fill(); } if (stroke !== null) { c.lineWidth = lw || 4; c.strokeStyle = stroke || OUT; c.stroke(); }
}
function eye(c, x, y, r, pupil) { E(c, x, y, r, r*1.15, '#fff', OUT, 3); E(c, x + r*0.15, y + r*0.15, pupil || r*0.55, (pupil || r*0.55)*1.1, OUT, null); E(c, x + r*0.3, y - r*0.15, r*0.2, r*0.2, '#fff', null); }
function lin(c, x0, y0, x1, y1, col, lw) { c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.strokeStyle = col || OUT; c.lineWidth = lw || 3; c.lineCap = 'round'; c.stroke(); }

const AV = [
function fox(c) {
  tile(c, '#58b8b0', '#2c7885');
  P(c, [[20,58],[22,10],[54,36]], '#f08a2c'); P(c, [[108,58],[106,10],[74,36]], '#f08a2c');
  P(c, [[28,48],[28,24],[44,38]], '#6b2d1a', null); P(c, [[100,48],[100,24],[84,38]], '#6b2d1a', null);
  c.beginPath(); c.moveTo(16,64); c.quadraticCurveTo(64,24,112,64); c.quadraticCurveTo(116,102,64,118); c.quadraticCurveTo(12,102,16,64); c.closePath();
  c.fillStyle = '#f08a2c'; c.fill();
  c.save(); c.clip(); c.fillStyle = '#fff4e2'; c.beginPath(); c.moveTo(0,82); c.quadraticCurveTo(40,66,64,84); c.quadraticCurveTo(88,66,128,82); c.lineTo(128,128); c.lineTo(0,128); c.fill(); c.restore();
  c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  eye(c, 44, 68, 8, 5); eye(c, 84, 68, 8, 5);
  P(c, [[56,92],[72,92],[64,102]], OUT); lin(c, 64, 102, 64, 108); c.beginPath(); c.moveTo(52,108); c.quadraticCurveTo(64,114,76,108); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
},
function owl(c) {
  tile(c, '#f2b45a', '#c9703a');
  E(c, 64, 74, 44, 46, '#8a5a3c'); E(c, 64, 88, 28, 28, '#e8cfa6', OUT, 3);
  P(c, [[26,44],[24,12],[52,30]], '#8a5a3c'); P(c, [[102,44],[104,12],[76,30]], '#8a5a3c');
  E(c, 44, 56, 18, 18, '#fff3c4'); E(c, 84, 56, 18, 18, '#fff3c4');
  E(c, 46, 58, 8, 8, OUT, null); E(c, 82, 58, 8, 8, OUT, null); E(c, 49, 55, 2.6, 2.6, '#fff', null); E(c, 85, 55, 2.6, 2.6, '#fff', null);
  P(c, [[56,70],[72,70],[64,84]], '#f08a1c');
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { c.beginPath(); c.arc(50 + j*14, 94 + i*8 - (j===1?0:0), 5, 0.2, Math.PI-0.2); c.strokeStyle = '#a77a4a'; c.lineWidth = 2.5; c.stroke(); }
},
function octopus(c) {
  tile(c, '#4a6fd6', '#23367e');
  c.fillStyle = '#b05ad8'; c.strokeStyle = OUT; c.lineWidth = 4; c.lineCap = 'round';
  for (let i = 0; i < 5; i++) { const x = 26 + i*19; c.beginPath(); c.moveTo(x-8, 80); c.bezierCurveTo(x-14, 110, x+10, 104, x+2, 122); c.lineWidth = 12; c.strokeStyle = OUT; c.stroke(); c.lineWidth = 6; c.strokeStyle = '#b05ad8'; c.stroke(); }
  c.beginPath(); c.moveTo(18,86); c.bezierCurveTo(10,20,118,20,110,86); c.bezierCurveTo(90,98,38,98,18,86); c.closePath(); c.fillStyle = '#b05ad8'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  E(c, 40, 40, 6, 4, '#d596ee', null); E(c, 92, 36, 5, 3, '#d596ee', null);
  eye(c, 46, 66, 11, 6); eye(c, 82, 66, 11, 6);
  c.beginPath(); c.arc(64, 82, 8, 0.2, Math.PI-0.2); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
},
function robot(c) {
  tile(c, '#9ad8ff', '#4a86c4');
  lin(c, 64, 24, 64, 10, OUT, 4); E(c, 64, 10, 6, 6, '#ff5a5a', OUT, 3);
  rr(c, 22, 24, 84, 78, 16); c.fillStyle = '#c3ccd6'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  rr(c, 30, 40, 68, 30, 12); c.fillStyle = '#1f2a3a'; c.fill(); c.stroke();
  E(c, 48, 55, 8, 8, '#4af0ff', null); E(c, 80, 55, 8, 8, '#4af0ff', null); E(c, 50, 52, 2.4, 2.4, '#fff', null); E(c, 82, 52, 2.4, 2.4, '#fff', null);
  rr(c, 42, 80, 44, 14, 5); c.fillStyle = '#7a8694'; c.fill(); c.lineWidth = 3; c.stroke();
  for (let i = 0; i < 4; i++) lin(c, 50 + i*10, 82, 50 + i*10, 92, OUT, 2.5);
  E(c, 20, 62, 6, 12, '#7a8694'); E(c, 108, 62, 6, 12, '#7a8694');
  E(c, 30, 30, 3, 3, '#7a8694', null); E(c, 98, 30, 3, 3, '#7a8694', null);
},
function cactus(c) {
  tile(c, '#ffd28a', '#e9895a');
  P(c, [[34,100],[94,100],[86,124],[42,124]], '#c4623a'); P(c, [[30,96],[98,96],[98,104],[30,104]], '#d9774a');
  rr(c, 40, 30, 48, 74, 22); c.fillStyle = '#4fae5a'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  rr(c, 16, 52, 18, 40, 9); c.fill(); c.stroke(); rr(c, 20, 80, 34, 14, 7); c.fill(); c.stroke();
  rr(c, 94, 40, 18, 40, 9); c.fill(); c.stroke(); rr(c, 76, 68, 34, 14, 7); c.fill(); c.stroke();
  rr(c, 40, 30, 48, 74, 22); c.fillStyle = '#4fae5a'; c.fill(); c.stroke();
  lin(c, 64, 32, 64, 96, '#7ccd7f', 3);
  E(c, 64, 28, 8, 8, '#ff6fa5', OUT, 3); E(c, 64, 28, 3, 3, '#ffe28a', null);
  eye(c, 54, 58, 6, 3.5); eye(c, 74, 58, 6, 3.5);
  c.beginPath(); c.arc(64, 70, 6, 0.15, Math.PI-0.15); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
},
function penguin(c) {
  tile(c, '#bfe8ff', '#5aa6dc');
  E(c, 64, 70, 38, 48, '#23304a'); E(c, 64, 82, 26, 34, '#fff', OUT, 3);
  E(c, 28, 80, 8, 22, '#23304a', OUT, 3, 0.25); E(c, 100, 80, 8, 22, '#23304a', OUT, 3, -0.25);
  eye(c, 52, 52, 8, 4.5); eye(c, 76, 52, 8, 4.5);
  P(c, [[54,62],[74,62],[64,74]], '#ff9b1f');
  E(c, 48, 120, 14, 6, '#ff9b1f'); E(c, 80, 120, 14, 6, '#ff9b1f');
},
function rocket(c) {
  tile(c, '#2b2f6b', '#10122e');
  [[20,20],[100,28],[30,100],[104,92],[84,14],[14,60]].forEach(p => E(c, p[0], p[1], 2.4, 2.4, '#fff6c8', null));
  c.save(); c.translate(64, 64); c.rotate(0.6);
  P(c, [[-12,40],[12,40],[0,76]], '#ffb43a'); P(c, [[-6,40],[6,40],[0,60]], '#fff2a0', null);
  P(c, [[-30,30],[-12,0],[-12,38]], '#e8465a'); P(c, [[30,30],[12,0],[12,38]], '#e8465a');
  c.beginPath(); c.moveTo(-18,40); c.lineTo(-18,-8); c.quadraticCurveTo(0,-62,18,-8); c.lineTo(18,40); c.closePath(); c.fillStyle = '#f3f5fb'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  c.beginPath(); c.moveTo(-14,-18); c.quadraticCurveTo(0,-52,14,-18); c.closePath(); c.fillStyle = '#e8465a'; c.fill(); c.stroke();
  E(c, 0, 8, 9, 9, '#69d6ff'); E(c, -3, 5, 2.6, 2.6, '#fff', null);
  c.restore();
},
function knight(c) {
  tile(c, '#8f6fd8', '#4a3a92');
  P(c, [[64,6],[80,2],[94,22],[74,30]], '#e04a5a');
  c.beginPath(); c.moveTo(26,110); c.lineTo(26,56); c.quadraticCurveTo(26,22,64,20); c.quadraticCurveTo(102,22,102,56); c.lineTo(102,110); c.closePath();
  const gr = c.createLinearGradient(26, 0, 102, 0); gr.addColorStop(0, '#9aa5b5'); gr.addColorStop(.5, '#e4eaf2'); gr.addColorStop(1, '#8793a5');
  c.fillStyle = gr; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  rr(c, 32, 52, 64, 14, 5); c.fillStyle = '#1b1d28'; c.fill(); c.stroke();
  lin(c, 64, 66, 64, 108, OUT, 3);
  for (let i = 0; i < 4; i++) E(c, 44 + (i%2)*40, 82 + (i>>1)*14, 2.4, 2.4, OUT, null);
  lin(c, 64, 20, 64, 52, OUT, 3);
},
function whale(c) {
  tile(c, '#6fd0e8', '#2a7fb8');
  lin(c, 56, 38, 56, 24, '#d9f6ff', 5); lin(c, 56, 24, 44, 14, '#d9f6ff', 5); lin(c, 56, 24, 68, 14, '#d9f6ff', 5);
  c.beginPath(); c.moveTo(14,76); c.bezierCurveTo(14,40,100,38,108,72); c.bezierCurveTo(116,70,118,52,122,46); c.bezierCurveTo(122,66,122,84,108,92); c.bezierCurveTo(90,114,24,116,14,76); c.closePath();
  c.fillStyle = '#3d6fd0'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  c.save(); c.clip(); c.fillStyle = '#e9f3ff'; c.beginPath(); c.moveTo(10,86); c.bezierCurveTo(40,96,80,98,112,84); c.lineTo(112,120); c.lineTo(10,120); c.fill(); c.restore();
  c.beginPath(); c.moveTo(14,76); c.bezierCurveTo(14,40,100,38,108,72); c.bezierCurveTo(116,70,118,52,122,46); c.bezierCurveTo(122,66,122,84,108,92); c.bezierCurveTo(90,114,24,116,14,76); c.stroke();
  eye(c, 38, 66, 6, 3.5); c.beginPath(); c.arc(40, 78, 9, 0.2, 1.4); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
  E(c, 40, 74, 5, 3, '#ff9db4', null);
},
function mushroom(c) {
  tile(c, '#a6e08a', '#4a9a58');
  rr(c, 40, 62, 48, 50, 18); c.fillStyle = '#fbeed6'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  c.beginPath(); c.moveTo(10,70); c.bezierCurveTo(10,10,118,10,118,70); c.quadraticCurveTo(64,84,10,70); c.closePath(); c.fillStyle = '#e8403f'; c.fill(); c.stroke();
  E(c, 40, 38, 11, 9, '#fff', null); E(c, 78, 28, 9, 7, '#fff', null); E(c, 98, 50, 8, 6, '#fff', null); E(c, 62, 54, 7, 5, '#fff', null);
  eye(c, 54, 90, 6, 3.5); eye(c, 74, 90, 6, 3.5);
  c.beginPath(); c.arc(64, 98, 5, 0.2, Math.PI-0.2); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
},
function ghost(c) {
  tile(c, '#6d4ab0', '#2a1c4e');
  c.beginPath(); c.moveTo(24,112); c.lineTo(24,56); c.bezierCurveTo(24,10,104,10,104,56); c.lineTo(104,112); c.lineTo(92,100); c.lineTo(80,114); c.lineTo(64,100); c.lineTo(48,114); c.lineTo(36,100); c.closePath();
  c.fillStyle = '#f6f4ff'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.lineJoin = 'round'; c.stroke();
  E(c, 50, 54, 7, 10, OUT, null); E(c, 78, 54, 7, 10, OUT, null); E(c, 52, 50, 2.4, 2.4, '#fff', null); E(c, 80, 50, 2.4, 2.4, '#fff', null);
  E(c, 40, 72, 7, 4, '#ffb4cc', null); E(c, 88, 72, 7, 4, '#ffb4cc', null);
  E(c, 64, 76, 6, 8, OUT, null);
},
function cat(c) {
  tile(c, '#ffc9a0', '#d97f6c');
  P(c, [[20,58],[22,10],[54,34]], '#8e99a8'); P(c, [[108,58],[106,10],[74,34]], '#8e99a8');
  P(c, [[28,48],[28,24],[44,36]], '#ffa6b8', null); P(c, [[100,48],[100,24],[84,36]], '#ffa6b8', null);
  E(c, 64, 74, 46, 40, '#8e99a8');
  c.save(); c.beginPath(); c.ellipse(64, 74, 46, 40, 0, 0, Math.PI*2); c.clip(); E(c, 64, 98, 24, 18, '#f4f6fa', null); lin(c, 64, 34, 64, 50, '#6c7686', 5); lin(c, 50, 36, 53, 48, '#6c7686', 4); lin(c, 78, 36, 75, 48, '#6c7686', 4); c.restore();
  E(c, 64, 74, 46, 40, null, OUT, 4);
  E(c, 44, 70, 9, 10, '#a7e86a', OUT, 3); E(c, 84, 70, 9, 10, '#a7e86a', OUT, 3); E(c, 44, 70, 3, 8, OUT, null); E(c, 84, 70, 3, 8, OUT, null);
  P(c, [[58,86],[70,86],[64,92]], '#ff7f9a', OUT, 3);
  c.beginPath(); c.moveTo(64,92); c.quadraticCurveTo(58,100,52,96); c.moveTo(64,92); c.quadraticCurveTo(70,100,76,96); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
  [[-1,0],[-1,8],[1,0],[1,8]].forEach(d => lin(c, 64 + d[0]*22, 90 + d[1]*0.5, 64 + d[0]*50, 84 + d[1], '#f4f6fa', 2.5));
},
function crown(c) {
  tile(c, '#7a3fb8', '#341660');
  [[24,24],[104,30],[18,96],[110,100],[64,12]].forEach(p => { P(c, [[p[0],p[1]-6],[p[0]+2,p[1]-2],[p[0]+6,p[1]],[p[0]+2,p[1]+2],[p[0],p[1]+6],[p[0]-2,p[1]+2],[p[0]-6,p[1]],[p[0]-2,p[1]-2]], '#ffe9a0', null); });
  P(c, [[22,96],[16,40],[40,64],[64,26],[88,64],[112,40],[106,96]], '#ffc83a');
  rr(c, 20, 92, 88, 18, 6); c.fillStyle = '#e8a41c'; c.fill(); c.lineWidth = 4; c.strokeStyle = OUT; c.stroke();
  E(c, 64, 100, 7, 7, '#ff4f6a', OUT, 3); E(c, 38, 100, 5, 5, '#56c8ff', OUT, 3); E(c, 90, 100, 5, 5, '#56e08a', OUT, 3);
  E(c, 16, 38, 6, 6, '#fff', OUT, 3); E(c, 64, 24, 6, 6, '#fff', OUT, 3); E(c, 112, 38, 6, 6, '#fff', OUT, 3);
}
];

/* ----- ability icons (96px) ----- */
function glyph(c, id, col) {
  c.save(); c.translate(48, 48); c.lineJoin = 'round'; c.lineCap = 'round';
  const W = '#fff', st = (w) => { c.lineWidth = w; c.strokeStyle = W; c.stroke(); };
  const fl = f => { c.fillStyle = f || W; c.fill(); };
  switch (id) {
    case 'unicorn': c.beginPath(); c.moveTo(-20,28); c.lineTo(0,-30); c.lineTo(20,28); c.closePath(); fl(); for (let i = 0; i < 4; i++) { c.beginPath(); c.moveTo(-14+i*3, 10-i*14); c.lineTo(14-i*3, 4-i*14+6); c.strokeStyle = col; c.lineWidth = 4; c.stroke(); } break;
    case 'fireball': c.beginPath(); c.moveTo(0,-34); c.bezierCurveTo(34,-6,30,34,0,34); c.bezierCurveTo(-30,34,-34,0,-10,-14); c.bezierCurveTo(-8,-2,-2,-6,0,-34); fl(); c.beginPath(); c.arc(0,18,10,0,7); fl(col); break;
    case 'frost': for (let i = 0; i < 3; i++) { c.save(); c.rotate(i*Math.PI/3); c.beginPath(); c.moveTo(0,-32); c.lineTo(0,32); st(6); c.beginPath(); c.moveTo(-9,-22); c.lineTo(0,-14); c.lineTo(9,-22); st(4); c.beginPath(); c.moveTo(-9,22); c.lineTo(0,14); c.lineTo(9,22); st(4); c.restore(); } break;
    case 'lightning': c.beginPath(); c.moveTo(8,-36); c.lineTo(-18,6); c.lineTo(-2,6); c.lineTo(-10,36); c.lineTo(20,-8); c.lineTo(3,-8); c.closePath(); fl(); break;
    case 'shield': c.beginPath(); c.moveTo(0,-34); c.lineTo(28,-24); c.lineTo(26,6); c.quadraticCurveTo(22,26,0,36); c.quadraticCurveTo(-22,26,-26,6); c.lineTo(-28,-24); c.closePath(); fl(); c.beginPath(); c.moveTo(0,-22); c.lineTo(0,22); c.moveTo(-14,-4); c.lineTo(14,-4); c.strokeStyle = col; c.lineWidth = 5; c.stroke(); break;
    case 'crown': c.beginPath(); c.moveTo(-30,22); c.lineTo(-34,-18); c.lineTo(-16,2); c.lineTo(0,-28); c.lineTo(16,2); c.lineTo(34,-18); c.lineTo(30,22); c.closePath(); fl(); c.beginPath(); c.moveTo(-30,28); c.lineTo(30,28); st(6); break;
    case 'portal': for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(0, 0, 30 - i*7, 36 - i*8, i*0.5, 0, 6.3); st(4); } c.beginPath(); c.arc(0,0,4,0,7); fl(); break;
    case 'charm': c.beginPath(); c.moveTo(0,30); c.bezierCurveTo(-44,0,-26,-34,0,-14); c.bezierCurveTo(26,-34,44,0,0,30); fl(); break;
    case 'frog': c.beginPath(); c.ellipse(0,10,32,22,0,0,7); fl(); c.beginPath(); c.arc(-16,-12,13,0,7); fl(); c.beginPath(); c.arc(16,-12,13,0,7); fl(); c.fillStyle = col; c.beginPath(); c.arc(-16,-12,5,0,7); c.fill(); c.beginPath(); c.arc(16,-12,5,0,7); c.fill(); c.beginPath(); c.arc(0,10,14,0.2,2.9); c.strokeStyle = col; c.lineWidth = 4; c.stroke(); break;
    case 'barrier': [[-30,-24,28,14],[2,-24,28,14],[-14,-6,28,14],[-30,12,28,14],[2,12,28,14]].forEach(b => { rr(c, b[0], b[1], b[2], b[3], 3); fl(); }); break;
    case 'gust': c.beginPath(); c.moveTo(-32,-12); c.bezierCurveTo(-4,-18,16,-30,26,-18); c.bezierCurveTo(32,-8,18,-2,12,-8); st(6); c.beginPath(); c.moveTo(-32,6); c.bezierCurveTo(0,0,22,4,28,14); c.bezierCurveTo(32,24,18,28,14,20); st(6); c.beginPath(); c.moveTo(-26,24); c.lineTo(4,24); st(6); break;
    case 'rewind': c.beginPath(); c.arc(0,2,26,-0.4,4.6); st(6); c.beginPath(); c.moveTo(18,-34); c.lineTo(28,-18); c.lineTo(8,-16); c.closePath(); fl(); c.beginPath(); c.moveTo(0,-14); c.lineTo(0,2); c.lineTo(12,8); st(5); break;
    case 'haste': for (let i = 0; i < 2; i++) { c.beginPath(); c.moveTo(-26+i*22,-26); c.lineTo(-4+i*22,0); c.lineTo(-26+i*22,26); st(9); } break;
    case 'summon': c.beginPath(); c.moveTo(0,-34); c.quadraticCurveTo(4,-4,34,0); c.quadraticCurveTo(4,4,0,34); c.quadraticCurveTo(-4,4,-34,0); c.quadraticCurveTo(-4,-4,0,-34); fl(); c.beginPath(); c.arc(22,-24,4,0,7); fl(); c.beginPath(); c.arc(-22,24,4,0,7); fl(); break;
    case 'meteor': c.beginPath(); c.arc(10,10,20,0,7); fl(); c.beginPath(); c.moveTo(-6,-6); c.lineTo(-34,-34); c.moveTo(-10,6); c.lineTo(-36,-8); c.moveTo(6,-10); c.lineTo(-8,-36); st(6); break;
    case 'swap': c.beginPath(); c.moveTo(-30,-12); c.lineTo(26,-12); st(7); c.beginPath(); c.moveTo(14,-26); c.lineTo(32,-12); c.lineTo(14,2); c.closePath(); fl(); c.beginPath(); c.moveTo(30,14); c.lineTo(-26,14); st(7); c.beginPath(); c.moveTo(-14,0); c.lineTo(-32,14); c.lineTo(-14,28); c.closePath(); fl(); break;
  }
  c.restore();
}
function abilityIcon(id) {
  if (cache['a' + id]) return cache['a' + id];
  const a = Abil.by[id], c = cv(96), x = c.getContext('2d');
  const gr = x.createRadialGradient(38, 30, 4, 48, 48, 56); gr.addColorStop(0, a.color); gr.addColorStop(1, shade(a.color, -0.38));
  x.fillStyle = gr; x.beginPath(); x.arc(48, 48, 46, 0, 7); x.fill();
  x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = 3; x.beginPath(); x.arc(48, 48, 44, 0, 7); x.stroke();
  x.fillStyle = 'rgba(255,255,255,.18)'; x.beginPath(); x.ellipse(48, 24, 30, 14, 0, 0, 7); x.fill();
  glyph(x, id, shade(a.color, -0.35));
  return cache['a' + id] = c.toDataURL();
}
function shade(h, f) {
  const r = parseInt(h.slice(1,3),16), gg = parseInt(h.slice(3,5),16), b = parseInt(h.slice(5,7),16), m = f < 0 ? 0 : 255, t = Math.abs(f);
  const k = v => Math.round(v + (m - v) * t).toString(16).padStart(2, '0'); return '#' + k(r) + k(gg) + k(b);
}
function avatar(i) {
  if (cache['v' + i]) return cache['v' + i];
  const c = cv(128), x = c.getContext('2d'); x.lineJoin = 'round'; x.lineCap = 'round';
  x.save(); rr(x, 0, 0, 128, 128, 18); x.clip(); AV[i](x); x.restore();
  return cache['v' + i] = c.toDataURL();
}
function boardThumb(b) {
  const k = 'b' + b.id; if (cache[k]) return cache[k];
  const c = cv(96), x = c.getContext('2d'); x.fillStyle = b.frame; rr(x, 0, 0, 96, 96, 12); x.fill();
  for (let r = 0; r < 4; r++) for (let q = 0; q < 4; q++) { x.fillStyle = (r + q) % 2 ? b.dark : b.light; x.fillRect(10 + q*19, 10 + r*19, 19, 19); }
  if (b.glow) { x.strokeStyle = b.glow; x.lineWidth = 2; x.strokeRect(9, 9, 78, 78); }
  return cache[k] = c.toDataURL();
}
function setThumb(s) {
  const k = 's' + s.id; if (cache[k]) return cache[k];
  const c = cv(96), x = c.getContext('2d'); x.fillStyle = 'rgba(0,0,0,.18)'; rr(x, 0, 0, 96, 96, 12); x.fill();
  [[30, 52, s.a], [66, 52, s.b]].forEach(p => {
    x.fillStyle = 'rgba(0,0,0,.25)'; x.beginPath(); x.ellipse(p[0], p[1] + 16, 22, 8, 0, 0, 7); x.fill();
    const gr = x.createLinearGradient(p[0] - 20, 0, p[0] + 20, 0); gr.addColorStop(0, shade(p[2], -0.25)); gr.addColorStop(0.35, p[2]); gr.addColorStop(1, shade(p[2], -0.4));
    x.fillStyle = gr; x.beginPath(); x.ellipse(p[0], p[1] + 8, 20, 9, 0, 0, Math.PI); x.rect(p[0] - 20, p[1] - 4, 40, 12); x.fill();
    x.fillStyle = shade(p[2], 0.15); x.beginPath(); x.ellipse(p[0], p[1] - 4, 20, 9, 0, 0, 7); x.fill();
    x.strokeStyle = 'rgba(255,255,255,.35)'; x.lineWidth = 1.5; x.beginPath(); x.ellipse(p[0], p[1] - 4, 13, 5.5, 0, 0, 7); x.stroke();
  });
  return cache[k] = c.toDataURL();
}

const svg = p => `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const icons = {
  user: svg('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'),
  grid: svg('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
  book: svg('<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5A2.5 2.5 0 0 0 6.5 24H20"/>'),
  gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  close: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
  back: svg('<path d="M15 5l-7 7 7 7"/>'),
  pause: svg('<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>'),
  lock: svg('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
  check: svg('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
  star: svg('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'),
  swords: svg('<path d="M4 4l9 9M20 4l-9 9M7 17l-3 3M17 17l3 3M9 15l-2 2M15 15l2 2"/>'),
  edit: svg('<path d="M4 20h4L19 9l-4-4L4 16z"/>'),
  restart: svg('<path d="M4 12a8 8 0 1 0 3-6.2"/><path d="M4 4v5h5"/>'),
  home: svg('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>')
};
g.Art = { avatar, abilityIcon, boardThumb, setThumb, icons, shade };
})(window);
