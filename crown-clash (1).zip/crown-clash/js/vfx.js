/* Crown & Clash — visual effects for the 16 super abilities (3D props, particles, flashes). Each effect is unique. */
(function (g) {
'use strict';
const { M4, MB, Prim } = g, E = g.Ease, rnd = g.rnd, cx = g.cellX, cz = g.cellZ;
const TAU = Math.PI * 2, lerp = (a, b, k) => a + (b - a) * k;
const X = {}; let SC = null;
const sfx = n => { try { g.SFX && g.SFX.play(n); } catch (e) {} };
function hsv(h, s, v) { const i = Math.floor(h * 6) % 6, f = h * 6 - Math.floor(h * 6), p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s); return [[v,t,p],[q,v,p],[p,v,t],[p,q,v],[t,p,v],[v,p,q]][i]; }

/* ---------- extra 3D props ---------- */
function init(sc) {
  if (SC === sc) return; SC = sc; const R = sc.R;
  const WH = [.98, .95, 1], PK = [1, .5, .85], GD = [1, .84, .3], HO = [.45, .3, .6];
  // unicorn (faces +x)
  let u = new MB(); const A = (mb, m) => u.append(mb, m);
  A(Prim.sphere(.5, 14, 10, WH), M4.mul(M4.T(0, .66, 0), M4.S(1.15, .75, .72)));
  A(Prim.sphere(.3, 10, 8, WH), M4.mul(M4.T(.5, .98, 0), M4.S(1.1, 1.3, .9)));
  A(Prim.sphere(.22, 12, 8, WH), M4.mul(M4.T(.72, 1.2, 0), M4.S(1.35, 1, .9)));
  A(Prim.cone(.05, .46, 8, GD), M4.mul(M4.T(.78, 1.3, 0), M4.RZ(-.75)));
  A(Prim.cone(.05, .16, 6, WH), M4.T(.62, 1.38, .1)); A(Prim.cone(.05, .16, 6, WH), M4.T(.62, 1.38, -.1));
  A(Prim.sphere(.045, 6, 5, [.15, .1, .25]), M4.T(.8, 1.24, .13)); A(Prim.sphere(.045, 6, 5, [.15, .1, .25]), M4.T(.8, 1.24, -.13));
  for (const [lx, lz] of [[.34, .2], [.34, -.2], [-.34, .2], [-.34, -.2]]) { A(Prim.cyl(.07, .5, 8, WH), M4.T(lx, 0, lz)); A(Prim.cyl(.078, .09, 8, HO), M4.T(lx, 0, lz)); }
  [[.5, 1.22], [.42, 1.1], [.35, .98], [.3, .86]].forEach(p => A(Prim.sphere(.1, 7, 5, PK), M4.T(p[0], p[1], 0)));
  [[-.62, .82, .1], [-.74, .7, .12], [-.82, .56, .14], [-.84, .42, .12]].forEach(p => A(Prim.sphere(p[2], 7, 5, PK), M4.T(p[0], p[1], 0)));
  X.unicorn = R.mesh(u);
  // heart
  u = new MB(); A(Prim.sphere(.3, 10, 8, PK), M4.T(-.2, .2, 0)); A(Prim.sphere(.3, 10, 8, PK), M4.T(.2, .2, 0)); A(Prim.cone(.44, .72, 12, PK), M4.mul(M4.T(0, .33, 0), M4.RZ(Math.PI)));
  X.heart = R.mesh(u);
  // frog (faces +z)
  const GR = [.4, .8, .28], GL = [.62, .9, .4];
  u = new MB(); A(Prim.sphere(.38, 12, 8, GR), M4.mul(M4.T(0, .3, 0), M4.S(1, .78, 1.15)));
  A(Prim.sphere(.26, 10, 7, GL), M4.mul(M4.T(0, .2, .12), M4.S(.9, .6, 1.1)));
  for (const sx of [-1, 1]) { A(Prim.sphere(.13, 8, 6, [1, 1, 1]), M4.T(.17 * sx, .58, .22)); A(Prim.sphere(.065, 6, 5, [.08, .08, .1]), M4.T(.17 * sx, .59, .32)); A(Prim.sphere(.15, 8, 6, GR), M4.mul(M4.T(.3 * sx, .1, -.22), M4.S(.8, .8, 1.3))); A(Prim.sphere(.09, 7, 5, GR), M4.T(.17 * sx, .06, .38)); }
  X.frog = R.mesh(u);
  // crown (big, gold)
  u = new MB(); A(Prim.torus(.3, .06, 16, 6, GD), M4.T(0, 0, 0)); A(Prim.torus(.3, .05, 16, 6, GD), M4.T(0, .1, 0));
  for (let i = 0; i < 5; i++) { const a = i / 5 * TAU; A(Prim.cone(.07, .3, 6, GD), M4.T(Math.cos(a) * .3, .08, Math.sin(a) * .3)); A(Prim.sphere(.055, 6, 5, i % 2 ? [1, .3, .4] : [.4, .85, 1]), M4.T(Math.cos(a) * .3, .4, Math.sin(a) * .3)); }
  X.crown = R.mesh(u);
  // meteor rock
  u = new MB(); const RK = [.36, .27, .24]; A(Prim.sphere(.5, 10, 8, RK), M4.S(1, .9, 1));
  [[.3, .2, .2, .3], [-.3, .15, .25, .28], [.1, -.3, -.2, .3], [-.2, .3, -.25, .25]].forEach(p => A(Prim.sphere(p[3], 8, 6, [.3, .22, .2]), M4.T(p[0], p[1], p[2])));
  X.rock = R.mesh(u);
}

/* ---------- helpers ---------- */
function fx(sc, draw, update) { const o = { dead: false, draw, update: dt => o.dead ? false : (update ? update(dt) : true) }; return sc.addFx(o); }
function wave(sc, x, z, col, r0, r1, dur, y) {
  const o = { r: r0, a: .9 };
  const f = fx(sc, (R, s) => R.draw(s.meshes.ring, M4.trs(x, y || .14, z, 0, o.r, 1, o.r), { unlit: true, color: col, alpha: o.a, noDepth: true, add: true }));
  return sc.tween(dur, k => { o.r = lerp(r0, r1, k); o.a = .9 * (1 - k); }, E.eo).then(() => { f.dead = true; });
}
function glowAt(sc, x, y, z, col, n, sp, size, life, grav) { sc.burst(x, y, z, col, n, sp, grav, size, life); }
function smoke(sc, x, z, col, n) { sc.dust(x, z, col, n); }
const pcs = (sc, id) => sc.pieces.get(id);
function scorch(sc, x, z, size, dur) { const o = { a: .55 }; const f = fx(sc, (R, s) => R.draw(s.meshes.shadow, M4.trs(x, .119, z, 0, size, 1, size), { unlit: true, color: [0, 0, 0], alpha: o.a, noDepth: true })); sc.tween(dur, k => { o.a = .55 * (1 - k); }, E.lin).then(() => { f.dead = true; }); }
function loop(sc, dur, fn) { return sc.tween(dur, (e, k) => fn(k, e), E.lin); }

const V = {};

/* 1. Unicorn: a rainbow unicorn gallops in with the checker on its back and carries it over the neighbour */
V.unicorn = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return;
  const ax = cx(info.from), az = cz(info.from), bx = cx(info.to), bz = cz(info.to);
  const hd = -Math.atan2(bz - az, bx - ax), u = { x: ax, y: 0, z: az, s: 0 };
  const f = fx(sc, R => { if (u.s > .01) { const s = u.s * .85; R.draw(X.unicorn, M4.trs(u.x, u.y, u.z, hd, s, s, s), { spec: .7, shin: 50, rim: .5 }); } });
  const rb = (x, y, z, n, sp) => { for (let i = 0; i < n; i++) sc.glow.emit(x + rnd(-.15, .15), y + rnd(-.1, .1), z + rnd(-.15, .15), rnd(-1, 1) * (sp || .4), rnd(-.2, .6), rnd(-1, 1) * (sp || .4), hsv(Math.random(), .55, 1).concat(1), rnd(.16, .3), rnd(.5, .9), .4, 1, .3); };
  sfx('cast'); rb(ax, .5, az, 26, 1.4); sc.flashScreen([1, .7, .95], .18);
  await sc.tween(.35, k => { u.s = k; }, E.eob);
  await sc.tween(.12, k => { p.y = .7 * k; p.x = ax; p.z = az; });
  sfx('select');
  await sc.tween(1.0, k => {
    u.x = lerp(ax, bx, k); u.z = lerp(az, bz, k); u.y = Math.sin(k * Math.PI) * 1.5;
    p.x = u.x; p.z = u.z; p.y = u.y + .7; rb(u.x - Math.cos(hd) * -.3, u.y + .45, u.z, 3, .25);
  }, E.eio);
  await sc.tween(.14, k => { p.y = .7 * (1 - k); });
  sc.shakeCam(.3); sc.dust(bx, bz, [1, .85, 1], 10); rb(bx, .5, bz, 22, 1.4);
  await sc.tween(.3, k => { u.s = 1 - k; }, E.eo); f.dead = true;
};

/* 2. Fireball: a blazing comet flies in from the edge and blows up the target and neighbours */
V.fireball = async (sc, info, ctx) => {
  const tx = cx(info.target), tz = cz(info.target), sg = ctx.side === 0 ? 1 : -1;
  const s0 = [tx * .3 - 6, 6.5, sg * 8.5], b = { x: s0[0], y: s0[1], z: s0[2], s: .5 };
  const f = fx(sc, (R, s) => {
    const fl = 1 + Math.sin(s.time * 45) * .12, M = s.meshes.sphere;
    R.draw(M, M4.trs(b.x, b.y, b.z, 0, b.s * 1.9 * fl, b.s * 1.9 * fl, b.s * 1.9 * fl), { unlit: true, color: [1, .35, .08], alpha: .35, add: true, noDepth: true });
    R.draw(M, M4.trs(b.x, b.y, b.z, 0, b.s * fl, b.s * fl, b.s * fl), { unlit: true, color: [1, .55, .12], emis: [.2, .1, 0] });
    R.draw(M, M4.trs(b.x, b.y, b.z, 0, b.s * .6 * fl, b.s * .6 * fl, b.s * .6 * fl), { unlit: true, color: [1, .95, .55] });
  });
  sfx('cast');
  await sc.tween(.85, k => {
    b.x = lerp(s0[0], tx, k); b.y = lerp(s0[1], .5, k * k); b.z = lerp(s0[2], tz, k); b.s = .5 + k * .35;
    for (let i = 0; i < 4; i++) sc.glow.emit(b.x + rnd(-.2, .2), b.y + rnd(-.2, .2), b.z + rnd(-.2, .2), rnd(-.6, .6), rnd(-.2, .8), rnd(-.6, .6), [1, rnd(.3, .75), .08, .9], rnd(.3, .5), rnd(.35, .6), 0, 1, .3);
    if (i0(k)) sc.soft.emit(b.x, b.y, b.z, 0, .3, 0, [.25, .2, .18, .5], .4, .8, 0, 1, 2);
  }, E.ei || (k => k * k));
  f.dead = true; sfx('boom'); sc.shakeCam(1.3); sc.flashScreen([1, .6, .2], .5);
  wave(sc, tx, tz, [1, .55, .15], .3, 3.2, .6); wave(sc, tx, tz, [1, .9, .5], .2, 2, .4);
  glowAt(sc, tx, .4, tz, [1, .6, .15], 60, 3.6, .36, 1.1); glowAt(sc, tx, .4, tz, [1, .25, .08], 30, 2.4, .3, .9);
  smoke(sc, tx, tz, [.25, .2, .18], 18); scorch(sc, tx, tz, 1.9, 2.4);
  for (const h of info.hit) { const hp = pcs(sc, h.id); if (hp) { hp.emis = [.9, .35, .05]; glowAt(sc, hp.x, .4, hp.z, [1, .5, .1], 20, 2.6, .26, .9); } }
  await sc.wait(.55);
};
const i0 = k => Math.random() < .5;

/* 3. Frost: icy spikes erupt around the target while snow swirls down */
V.frost = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return; const x = p.x, z = p.z;
  sfx('ice'); sc.flashScreen([.6, .9, 1], .2);
  const sp = []; for (let i = 0; i < 9; i++) { const a = i / 9 * TAU + rnd(-.2, .2), r = .5 + rnd(0, .35); sp.push({ x: x + Math.cos(a) * r, z: z + Math.sin(a) * r, h: rnd(.7, 1.5), lean: a }); }
  const o = { k: 0, a: .85 };
  const f = fx(sc, (R, s) => { for (const q of sp) { const h = q.h * Math.min(1, o.k * 2.2); R.draw(s.meshes.cone, M4.trs(q.x, .11, q.z, 0, .13, h, .13), { unlit: true, color: [.7, .93, 1], alpha: o.a, emis: [.1, .2, .25] }); } });
  wave(sc, x, z, [.6, .9, 1], .2, 2.2, .7);
  await loop(sc, .9, (k) => {
    o.k = k; if (k > .65) o.a = .85 * (1 - (k - .65) / .35);
    sc.soft.emit(x + rnd(-1.1, 1.1), 2.4, z + rnd(-1.1, 1.1), rnd(-.2, .2), -2.2, rnd(-.2, .2), [.92, .98, 1, .95], .16, 1.1, 0, 0, 1);
    if (Math.random() < .5) sc.glow.emit(x + rnd(-.6, .6), .2, z + rnd(-.6, .6), 0, rnd(.4, 1.2), 0, [.6, .9, 1, 1], .14, .7, 0, .5, .3);
  });
  f.dead = true; glowAt(sc, x, .5, z, [.7, .95, 1], 24, 2, .2, .8);
};

/* 4. Lightning: jagged bolts strike the strongest enemy from the sky */
V.lightning = async (sc, info) => {
  const tx = cx(info.target), tz = cz(info.target), hp = info.hit[0] && pcs(sc, info.hit[0].id);
  sfx('zap');
  const bolt = () => {
    let x = tx + rnd(-.7, .7), z = tz + rnd(-.7, .7); const pts = [];
    for (let i = 0; i <= 10; i++) { pts.push([x, 9 * (1 - i / 10) + .1, z]); x += rnd(-.5, .5) * (1 - i / 12); z += rnd(-.5, .5) * (1 - i / 12); }
    pts[10] = [tx, .15, tz];
    for (let i = 0; i < 10; i++) for (let j = 0; j < 7; j++) { const t = j / 7, px = lerp(pts[i][0], pts[i + 1][0], t), py = lerp(pts[i][1], pts[i + 1][1], t), pz = lerp(pts[i][2], pts[i + 1][2], t);
      sc.glow.emit(px, py, pz, 0, 0, 0, [1, 1, .9, 1], .24, .16, 0, 0, .4); sc.glow.emit(px, py, pz, 0, 0, 0, [1, .9, .3, .55], .7, .22, 0, 0, .6); }
    if (Math.random() < .8) { const bx = pts[4][0], by = pts[4][1], bz = pts[4][2], a = Math.random() * TAU; for (let j = 0; j < 14; j++) { const t = j / 14; sc.glow.emit(bx + Math.cos(a) * t * 1.6 + rnd(-.1, .1), by - t * 1.4, bz + Math.sin(a) * t * 1.6, 0, 0, 0, [.9, .95, 1, .9], .16, .14, 0, 0, .4); } }
  };
  for (let n = 0; n < 3; n++) {
    bolt(); sc.flashScreen([1, 1, .85], n === 0 ? .55 : .35); sc.shakeCam(.8);
    glowAt(sc, tx, .3, tz, [1, .95, .5], 18, 3.2, .16, .5, 2); wave(sc, tx, tz, [1, .95, .6], .2, 1.8, .3);
    if (hp) hp.emis = n % 2 ? [.3, .3, .1] : [1, 1, .7];
    await sc.wait(.1);
  }
  if (hp) hp.emis = [.5, .5, .25]; smoke(sc, tx, tz, [.25, .22, .2], 12); scorch(sc, tx, tz, 1.3, 2);
  await sc.wait(.45);
};

/* 5. Shield: runes converge and a luminous bubble snaps around the checker */
V.shield = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return; const x = p.x, z = p.z, o = { a: 0, s: 1.6 };
  sfx('cast');
  const f = fx(sc, (R, s) => {
    const t = s.time;
    R.draw(s.meshes.ring, M4.trs(x, .14, z, 0, .95, 1, .95), { unlit: true, color: [.45, .72, 1], alpha: .8 * o.a, add: true, noDepth: true });
    for (let i = 0; i < 6; i++) { const a = t * 2.2 + i / 6 * TAU; R.draw(s.meshes.box, M4.trs(x + Math.cos(a) * .95, .16, z + Math.sin(a) * .95, -a, .12, .03, .3), { unlit: true, color: [.7, .88, 1], alpha: o.a, add: true, noDepth: true }); }
    R.draw(s.meshes.sphere, M4.trs(x, .38, z, 0, .6 * o.s, .55 * o.s, .6 * o.s), { unlit: true, color: [.5, .75, 1], alpha: .25 * o.a, add: true, noDepth: true });
  });
  await loop(sc, .85, k => {
    o.a = Math.min(1, k * 3); o.s = lerp(1.7, 1.08, E.eo(Math.min(1, k * 1.4)));
    const a = Math.random() * TAU; sc.glow.emit(x + Math.cos(a) * 1.5, .3 + rnd(0, .6), z + Math.sin(a) * 1.5, -Math.cos(a) * 2.4, 0, -Math.sin(a) * 2.4, [.55, .8, 1, 1], .16, .6, 0, 0, .3);
  });
  sc.flashScreen([.5, .75, 1], .18); glowAt(sc, x, .45, z, [.6, .85, 1], 24, 2.2, .18, .7); wave(sc, x, z, [.5, .75, 1], .6, 1.8, .5);
  f.dead = true;
};

/* 6. Coronation: a golden crown spins down from a beam of light */
V.crown = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return; const x = p.x, z = p.z, c = { y: 3.8, s: 1.7, a: 0, beam: 0 };
  sfx('cast');
  const f = fx(sc, (R, s) => {
    R.draw(s.meshes.cyl, M4.trs(x, 0, z, 0, .5, 6, .5), { unlit: true, color: [1, .9, .5], alpha: .2 * c.beam, add: true, noDepth: true });
    if (c.a > .01) R.draw(X.crown, M4.trs(x, c.y, z, s.time * 5, c.s, c.s, c.s), { spec: 1, shin: 60, rim: .4, alpha: c.a, emis: [.2, .15, 0] });
  });
  await sc.tween(.7, k => { c.beam = Math.min(1, k * 3); c.a = Math.min(1, k * 2.5); c.y = lerp(3.8, .62, k); c.s = lerp(1.7, 1, k);
    sc.glow.emit(x + rnd(-.4, .4), c.y + rnd(0, .3), z + rnd(-.4, .4), 0, -.3, 0, [1, .85, .3, 1], .18, .6, 0, 0, .3); }, E.eio);
  sfx('king'); sc.shakeCam(.35); sc.flashScreen([1, .9, .5], .3); glowAt(sc, x, .8, z, [1, .85, .3], 40, 3, .24, 1); wave(sc, x, z, [1, .85, .35], .3, 2, .5);
  await sc.tween(.35, k => { c.s = 1 - k * .9; c.y = lerp(.62, .45, k); c.a = 1 - k; c.beam = 1 - k; }, E.eo);
  f.dead = true;
};

/* 7. Portal: two spinning rune gates; the checker spirals into one and steps out of the other */
V.portal = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return;
  const ax = cx(info.from), az = cz(info.from), bx = cx(info.to), bz = cz(info.to), P = [{ x: ax, z: az, s: 0 }, { x: bx, z: bz, s: 0 }];
  sfx('cast');
  const f = fx(sc, (R, s) => { const t = s.time; for (const q of P) { if (q.s < .01) continue;
    R.draw(s.meshes.dot, M4.trs(q.x, .13, q.z, 0, .8 * q.s, 1, .8 * q.s), { unlit: true, color: [.18, .05, .35], alpha: .9, noDepth: true });
    R.draw(s.meshes.ring, M4.trs(q.x, .14, q.z, 0, .9 * q.s, 1, .9 * q.s), { unlit: true, color: [.7, .45, 1], alpha: .95, add: true, noDepth: true });
    for (let i = 0; i < 8; i++) { const a = t * 3 + i / 8 * TAU; R.draw(s.meshes.box, M4.trs(q.x + Math.cos(a) * .72 * q.s, .15, q.z + Math.sin(a) * .72 * q.s, -a, .1, .03, .26 * q.s), { unlit: true, color: [.85, .65, 1], alpha: .9, add: true, noDepth: true }); }
    if (Math.random() < .8) { const a = Math.random() * TAU; sc.glow.emit(q.x + Math.cos(a) * .8, .15, q.z + Math.sin(a) * .8, -Math.sin(a) * 1.6 - Math.cos(a) * .6, 1.2, Math.cos(a) * 1.6 - Math.sin(a) * .6, [.75, .5, 1, 1], .15, .8, 0, 0, .3); } } });
  await sc.tween(.5, k => { P[0].s = k; P[1].s = k; }, E.eob);
  await sc.tween(.55, k => { p.s = 1 - k; p.rot = k * 9; p.y = k * .5; }, E.eio);
  p.x = bx; p.z = bz; glowAt(sc, bx, .5, bz, [.8, .6, 1], 30, 2.6, .2, .9); sfx('select');
  await sc.tween(.55, k => { p.s = k; p.rot = (1 - k) * 9; p.y = (1 - k) * .5; }, E.eob);
  p.rot = 0; p.y = 0; p.s = 1;
  await sc.tween(.4, k => { P[0].s = 1 - k; P[1].s = 1 - k; }, E.eo); f.dead = true;
};

/* 8. Charm: pink hearts float up and the enemy checker falls for you */
V.charm = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return; const x = p.x, z = p.z;
  sfx('cast'); sc.flashScreen([1, .5, .75], .15);
  const H = []; for (let i = 0; i < 9; i++) H.push({ ox: rnd(-.55, .55), oz: rnd(-.55, .55), d: rnd(0, .45), ph: rnd(0, 6), sp: rnd(.9, 1.5), s: rnd(.22, .38) });
  const o = { t: 0 };
  const f = fx(sc, (R, s) => { for (const h of H) { const k = Math.max(0, (o.t - h.d) / .9); if (k <= 0 || k >= 1) continue; const sz = h.s * Math.min(1, k * 4) * (1 + Math.sin(s.time * 9 + h.ph) * .08);
    R.draw(X.heart, M4.trs(x + h.ox + Math.sin(o.t * 4 + h.ph) * .15, .5 + k * 1.9 * h.sp, z + h.oz, Math.sin(o.t * 3 + h.ph) * .5, sz, sz, sz * .7), { unlit: true, color: [1, .45, .7], emis: [.2, .05, .1], alpha: 1 - Math.max(0, k - .7) / .3 }); } });
  wave(sc, x, z, [1, .5, .8], .3, 1.8, .8);
  await loop(sc, 1.35, k => { o.t = k * 1.35; p.y = Math.abs(Math.sin(k * 9)) * .12 * Math.min(1, k * 3); if (Math.random() < .5) sc.glow.emit(x + rnd(-.6, .6), .2, z + rnd(-.6, .6), 0, rnd(.6, 1.4), 0, [1, .5, .8, 1], .14, .8, 0, 0, .3); });
  p.y = 0; f.dead = true; glowAt(sc, x, .6, z, [1, .5, .8], 30, 2.4, .2, .9); sfx('king');
};

/* 9. Frog: a green poof and a hopping frog replaces the king for a moment */
V.frog = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return; const x = p.x, z = p.z, fr = { x, y: 0, z, s: 0, r: 0 };
  sfx('cast'); sc.flashScreen([.5, 1, .35], .15);
  const f = fx(sc, R => { if (fr.s > .01) R.draw(X.frog, M4.trs(fr.x, .115 + fr.y, fr.z, fr.r, fr.s, fr.s * (1 + Math.sin(fr.y * 6) * .1), fr.s), { spec: .6, shin: 30, rim: .3 }); });
  sc.dust(x, z, [.45, .9, .3], 18); glowAt(sc, x, .5, z, [.5, 1, .3], 24, 2.4, .22, .8);
  p.hide = true;
  await sc.tween(.3, k => { fr.s = k * 1.2; }, E.eob);
  const hops = [[.45, .1], [-.3, .4], [-.15, -.4], [0, 0]];
  for (const [hx, hz] of hops) {
    const x0 = fr.x, z0 = fr.z, tx = x + hx, tz = z + hz; fr.r = Math.atan2(tx - x0, tz - z0) - 0; sfx('select');
    await sc.tween(.3, k => { fr.x = lerp(x0, tx, k); fr.z = lerp(z0, tz, k); fr.y = Math.sin(k * Math.PI) * .55; }, E.lin);
    fr.y = 0; sc.puff(fr.x, fr.z);
  }
  sc.dust(x, z, [.45, .9, .3], 14); glowAt(sc, x, .5, z, [.6, 1, .4], 22, 2.2, .2, .8);
  p.hide = false; p.s = 0; await sc.tween(.25, k => { p.s = k; }, E.eob); p.s = 1; f.dead = true;
};

/* 10. Stone wall: two boulders crash down from the sky */
V.barrier = async (sc, info) => {
  const cells = info.cells;
  sfx('cast');
  const run = async (i, delay) => {
    await sc.wait(delay); const x = cx(i), z = cz(i), b = { y: 7, s: 1, a: 1, t: 5 };
    sc.blocks.set(i, b); const o = { a: .8 };
    const f = fx(sc, (R, s) => R.draw(s.meshes.ring, M4.trs(x, .14, z, 0, .8, 1, .8), { unlit: true, color: [.9, .75, .5], alpha: o.a, add: true, noDepth: true }));
    await sc.tween(.5, k => { b.y = 7 * (1 - k * k); }, E.lin); b.y = 0;
    sfx('boom'); sc.shakeCam(.9); sc.dust(x, z, [.78, .7, .6], 26); wave(sc, x, z, [.9, .78, .55], .3, 1.8, .45); glowAt(sc, x, .3, z, [.9, .75, .5], 16, 2.4, .14, .7);
    await sc.tween(.4, k => { o.a = .8 * (1 - k); }); f.dead = true;
  };
  await Promise.all([run(cells[0], 0), run(cells[1], .3)]);
};

/* 11. Hurricane: a whirlwind scoops the checker and hurls it along the diagonal */
V.gust = async (sc, info) => {
  const p = pcs(sc, info.id); if (!p) return;
  const ax = cx(info.from), az = cz(info.from), d = g.Rules.DIRS[info.dir], dx = d[1], dz = d[0];
  const bx = info.to >= 0 ? cx(info.to) : ax + dx * 10, bz = info.to >= 0 ? cz(info.to) : az + dz * 10;
  const T = { x: ax, z: az, s: 0 }; sfx('cast');
  const f = fx(sc, (R, s) => { const t = s.time; for (let i = 0; i < 8; i++) { const y = .12 + i * .3, r = (.18 + i * .12) * T.s, a = t * (9 - i * .7) + i;
    R.draw(s.meshes.ring, M4.trs(T.x + Math.sin(a) * .08 * i, y, T.z + Math.cos(a) * .08 * i, 0, r, 1, r), { unlit: true, color: [.78, .97, .92], alpha: .6, add: true, noDepth: true }); } });
  const swirl = () => { const a = Math.random() * TAU, h = rnd(0, 2.2), r = (.25 + h * .14) * T.s; sc.soft.emit(T.x + Math.cos(a) * r, h, T.z + Math.sin(a) * r, -Math.sin(a) * 2.5, .4, Math.cos(a) * 2.5, [.85, 1, .95, .6], .16, .5, 0, 0, 1.4); };
  await loop(sc, .55, k => { T.s = Math.min(1, k * 2); swirl(); swirl(); p.y = k * 1.0; p.rot = k * k * 14; });
  const total = Math.hypot(bx - ax, bz - az), dur = Math.min(1.4, .2 + total * .14);
  await loop(sc, dur, k => { const e = E.eio(k); T.x = lerp(ax, bx, e); T.z = lerp(az, bz, e); p.x = T.x; p.z = T.z; p.y = 1 + Math.sin(k * Math.PI) * .3 + (info.to < 0 ? k * 2.5 : 0); p.rot += .45; swirl(); swirl(); if (info.to < 0) p.a = 1 - Math.max(0, k - .5) * 2; });
  sc.shakeCam(.3);
  if (info.to >= 0) { await sc.tween(.25, k => { p.y = (1 - k) * 1.0; p.rot = p.rot * (1 - k); T.s = 1 - k; }, E.eo); p.rot = 0; p.y = 0; sc.dust(bx, bz, [.85, 1, .95], 12); }
  else { await sc.tween(.2, k => { T.s = 1 - k; }); }
  f.dead = true;
};

/* 12. Time rewind: a giant spectral clock hovers over the board with hands spinning backwards */
V.rewind = async (sc, info, ctx) => {
  const c = { a: 0, h: 0, m: 0, s: .6 }; sfx('cast');
  const f = fx(sc, (R, s) => { const y = 2.6, rr = 3.6 * c.s, t = s.time;
    R.draw(s.meshes.dot, M4.trs(0, y, 0, 0, rr, 1, rr), { unlit: true, color: [.3, .45, 1], alpha: .08 * c.a, add: true, noDepth: true });
    R.draw(s.meshes.ring, M4.trs(0, y + .01, 0, 0, rr, 1, rr), { unlit: true, color: [.6, .8, 1], alpha: .9 * c.a, add: true, noDepth: true });
    for (let i = 0; i < 12; i++) { const a = i / 12 * TAU, big = i % 3 === 0; R.draw(s.meshes.box, M4.trs(Math.cos(a) * rr * .86, y + .02, -Math.sin(a) * rr * .86, a, big ? .5 : .28, .03, .09), { unlit: true, color: [.8, .9, 1], alpha: .9 * c.a, add: true, noDepth: true }); }
    const hand = (ang, L, w) => R.draw(s.meshes.box, M4.trs(Math.cos(ang) * L * rr / 2, y + .03, -Math.sin(ang) * L * rr / 2, ang, L * rr, .04, w), { unlit: true, color: [1, 1, 1], alpha: c.a, add: true, noDepth: true });
    hand(c.m, .8, .14); hand(c.h, .52, .2); });
  await sc.tween(.5, k => { c.a = k; c.s = lerp(.6, 1, k); }, E.eo);
  sc.flashScreen([.45, .6, 1], .25);
  const run = ctx.restore ? ctx.restore() : Promise.resolve();
  await loop(sc, 1.15, k => { c.m = 1.57 - k * 5 * TAU / 1.6 * .9; c.h = 1.57 - k * 5 * TAU / 12 * 1.0 * 2; const a = Math.random() * TAU, r = rnd(1, 3.8);
    sc.glow.emit(Math.cos(a) * r, .3, Math.sin(a) * r, Math.sin(a) * 1.2, 1.8, -Math.cos(a) * 1.2, [.5, .7, 1, 1], .15, .9, 0, 0, .3); });
  await run;
  await sc.tween(.5, k => { c.a = 1 - k; c.s = 1 + k * .3; }, E.eo); f.dead = true;
};

/* 13. Haste: golden chevrons sweep across the board and the checkers start to glow */
V.haste = async (sc, info, ctx) => {
  const sg = ctx.side === 0 ? -1 : 1, o = { t: 0 }; sfx('cast'); sc.hasteGlow[ctx.side] = true;
  const f = fx(sc, (R, s) => { for (let r = 0; r < 4; r++) { const k = o.t * 1.4 - r * .12; if (k <= 0 || k >= 1) continue; const z = lerp(-sg * 5.5, sg * 5.5, k), al = Math.sin(k * Math.PI);
    for (const sx of [-1, 1]) R.draw(s.meshes.box, M4.trs(sx * .9, .5 + r * .02, z - sg * (.7 * 0), -sx * .6 * sg, 1.6, .05, .16), { unlit: true, color: [1, .75, .2], alpha: al * .9, add: true, noDepth: true }); } });
  await loop(sc, .95, k => { o.t = k; for (let i = 0; i < 4; i++) { const x = rnd(-4, 4); sc.glow.emit(x, rnd(.2, 1.2), -sg * 5 + rnd(-1, 1), 0, 0, sg * 14, [1, rnd(.5, .8), .15, .9], .12, .35, 0, 0, 1); } });
  sc.flashScreen([1, .75, .25], .22); f.dead = true;
  for (const q of sc.pieces.values()) if ((q.code < 3 ? 0 : 1) === ctx.side) glowAt(sc, q.x, .4, q.z, [1, .7, .2], 6, 1.6, .18, .6);
};

/* 14. Summon: a magic circle and a pillar of light call a brand new checker */
V.summon = async (sc, info) => {
  const x = cx(info.i), z = cz(info.i), c = { a: 0, s: 0, h: 0 }; sfx('cast');
  const f = fx(sc, (R, s) => { const t = s.time;
    R.draw(s.meshes.ring, M4.trs(x, .14, z, 0, .9 * c.s, 1, .9 * c.s), { unlit: true, color: [.5, 1, .6], alpha: c.a, add: true, noDepth: true });
    R.draw(s.meshes.ring, M4.trs(x, .141, z, 0, .55 * c.s, 1, .55 * c.s), { unlit: true, color: [.8, 1, .85], alpha: c.a, add: true, noDepth: true });
    for (let i = 0; i < 6; i++) { const a = -t * 2 + i / 6 * TAU; R.draw(s.meshes.box, M4.trs(x + Math.cos(a) * .72 * c.s, .15, z + Math.sin(a) * .72 * c.s, -a, .1, .03, .24), { unlit: true, color: [.7, 1, .8], alpha: c.a, add: true, noDepth: true }); }
    R.draw(s.meshes.cyl, M4.trs(x, 0, z, 0, .42, 3 * c.h, .42), { unlit: true, color: [.55, 1, .65], alpha: .3 * c.a, add: true, noDepth: true }); });
  await loop(sc, .65, k => { c.s = Math.min(1, k * 2); c.a = Math.min(1, k * 2); c.h = E.eo(k); const a = Math.random() * TAU; sc.glow.emit(x + Math.cos(a) * .7, .1, z + Math.sin(a) * .7, 0, rnd(1.2, 2.4), 0, [.6, 1, .7, 1], .14, .8, 0, 0, .3); });
  sc.flashScreen([.5, 1, .6], .2); glowAt(sc, x, .5, z, [.6, 1, .7], 30, 2.6, .2, .9);
  sc.tween(.7, k => { c.a = 1 - k; c.h = 1 + k; }, E.eo).then(() => { f.dead = true; });
  await sc.wait(.1);
};

/* 15. Meteor: a lock-on reticle in the sky + a warning, the crash itself happens after the enemy turn */
V.meteor = async (sc, info) => {
  const x = cx(info.i), z = cz(info.i), o = { r: 2.6, a: 0 }; sfx('cast');
  const f = fx(sc, (R, s) => { R.draw(s.meshes.ring, M4.trs(x, .15, z, 0, o.r, 1, o.r), { unlit: true, color: [1, .3, .2], alpha: o.a, add: true, noDepth: true });
    for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + s.time * 1.5; R.draw(s.meshes.box, M4.trs(x + Math.cos(a) * o.r * .9, .15, z + Math.sin(a) * o.r * .9, -a, .3, .03, .08), { unlit: true, color: [1, .5, .3], alpha: o.a, add: true, noDepth: true }); } });
  for (let n = 0; n < 2; n++) { await sc.tween(.4, k => { o.r = lerp(2.6, .7, E.eo(k)); o.a = Math.min(1, k * 3); }); sc.shakeCam(.3); glowAt(sc, x, .3, z, [1, .35, .15], 10, 1.6, .16, .6); }
  sc.flashScreen([1, .3, .2], .2); await sc.tween(.25, k => { o.a = 1 - k; }); f.dead = true;
};
async function meteorImpact(sc, imp) {
  init(sc); const x = cx(imp.i), z = cz(imp.i), r = { x: x + 7, y: 9, z: z - 7, s: 1.1, a: 1 };
  const f = fx(sc, (R, s) => { const fl = 1 + Math.sin(s.time * 30) * .08, M = s.meshes.sphere;
    R.draw(M, M4.trs(r.x, r.y, r.z, 0, r.s * 2.1 * fl, r.s * 2.1 * fl, r.s * 2.1 * fl), { unlit: true, color: [1, .3, .08], alpha: .3, add: true, noDepth: true });
    R.draw(X.rock, M4.trs(r.x, r.y, r.z, s.time * 3, r.s, r.s, r.s), { emis: [.35, .1, .02], spec: .1, shin: 6 }); });
  sfx('cast');
  await sc.tween(.8, k => { r.x = lerp(x + 7, x, k); r.y = lerp(9, .5, k); r.z = lerp(z - 7, z, k);
    for (let i = 0; i < 5; i++) sc.glow.emit(r.x + rnd(-.3, .3), r.y + rnd(-.3, .3), r.z + rnd(-.3, .3), rnd(-.5, .5), rnd(0, .8), rnd(-.5, .5), [1, rnd(.25, .7), .05, .9], rnd(.35, .6), rnd(.4, .7), 0, 1, .3);
    sc.soft.emit(r.x, r.y, r.z, 0, .2, 0, [.2, .17, .15, .6], .5, 1, 0, 1, 2.5); }, k => k * k);
  f.dead = true; sc.meteors.delete(imp.i);
  sfx('boom'); sc.shakeCam(2.2); sc.flashScreen([1, .75, .4], .65);
  wave(sc, x, z, [1, .5, .15], .3, 3.8, .7); wave(sc, x, z, [1, .9, .5], .2, 2.6, .5);
  glowAt(sc, x, .5, z, [1, .6, .15], 80, 4.2, .4, 1.2); glowAt(sc, x, .5, z, [1, .25, .08], 40, 3, .34, 1);
  smoke(sc, x, z, [.2, .17, .15], 26); scorch(sc, x, z, 2.6, 3);
  for (const h of imp.hit) { const hp = pcs(sc, h.id); if (hp) { hp.emis = [.9, .35, .05]; glowAt(sc, hp.x, .4, hp.z, [1, .5, .1], 18, 3, .26, 1); } }
  await sc.wait(.55);
}

/* 16. Swap: both checkers rise and dance around each other along a helix */
V.swap = async (sc, info) => {
  const pa = pcs(sc, info.idA), pb = pcs(sc, info.idB); if (!pa || !pb) return;
  const ax = cx(info.a), az = cz(info.a), bx = cx(info.b), bz = cz(info.b), mx = (ax + bx) / 2, mz = (az + bz) / 2, rx = ax - mx, rz = az - mz;
  sfx('cast'); sc.flashScreen([.85, .55, 1], .18);
  const trail = (x, y, z, col) => sc.glow.emit(x + rnd(-.08, .08), y, z + rnd(-.08, .08), rnd(-.2, .2), rnd(-.1, .3), rnd(-.2, .2), col, rnd(.14, .24), rnd(.4, .7), 0, 1, .3);
  await sc.tween(1.15, k => {
    const th = Math.PI * k, c = Math.cos(th), s = Math.sin(th), y = Math.sin(Math.PI * k) * 1.3;
    pa.x = mx + rx * c - rz * s; pa.z = mz + rx * s + rz * c; pb.x = mx - (rx * c - rz * s); pb.z = mz - (rx * s + rz * c);
    pa.y = pb.y = y; pa.rot = pb.rot = k * TAU * 2; trail(pa.x, y + .3, pa.z, [.85, .5, 1, 1]); trail(pb.x, y + .3, pb.z, [1, .85, .35, 1]);
  }, E.eio);
  pa.rot = pb.rot = 0; pa.y = pb.y = 0; pa.x = bx; pa.z = bz; pb.x = ax; pb.z = az;
  sc.shakeCam(.3); glowAt(sc, ax, .4, az, [1, .85, .4], 16, 2, .18, .7); glowAt(sc, bx, .4, bz, [.85, .5, 1], 16, 2, .18, .7); sc.puff(ax, az); sc.puff(bx, bz);
};

/* extras */
function confetti(sc, side) {
  const cols = [[1, .4, .4], [1, .85, .3], [.4, .9, .5], [.45, .7, 1], [.85, .5, 1]];
  for (let w = 0; w < 6; w++) setTimeout(() => { for (let i = 0; i < 26; i++) { const a = rnd(0, TAU), s = rnd(1, 4.5); sc.glow.emit(rnd(-3, 3), 3.5, rnd(-3, 3), Math.cos(a) * s * .5, rnd(2, 5), Math.sin(a) * s * .5, cols[i % 5].concat(1), rnd(.14, .26), rnd(1.4, 2.2), 3.2, .6, .3); } }, w * 260);
}
async function cast(sc, id, info, ctx) { init(sc); if (V[id]) await V[id](sc, info, ctx || {}); }
g.Vfx = { init, cast, meteorImpact, confetti, wave, hsv };
})(window);
