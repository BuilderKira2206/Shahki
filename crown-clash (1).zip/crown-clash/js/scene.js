/* Crown & Clash — 3D scene: board, pieces, camera, tweens, picking, state sync, menu autoplay. */
(function (g) {
'use strict';
const { M4, MB, Prim } = g;
const lin = k => k, eo = k => 1 - Math.pow(1 - k, 3), eio = k => k < .5 ? 4*k*k*k : 1 - Math.pow(-2*k + 2, 3) / 2;
const eob = k => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
const cx = i => (i & 7) - 3.5, cz = i => (i >> 3) - 3.5;
const GOLD = [1, .82, .3];
const rnd = (a, b) => a + Math.random() * (b - a);

class Scene {
  constructor(cv) {
    this.cv = cv; this.R = new Renderer(cv);
    const R = this.R; this.gl = R.gl;
    this.glow = new Particles(R, 900, true); this.soft = new Particles(R, 500, false);
    this.pieces = new Map(); this.blocks = new Map(); this.meteors = new Map();
    this.marks = []; this.tw = []; this.fx = []; this.time = 0;
    this.yaw = 0; this.yawT = 0; this.pitch = 0.95; this.dist = 13; this.shiftX = 0; this.shiftY = 0; this.shiftXT = 0; this.shiftYT = 0;
    this.menu = false; this.paused = false; this.shake = 0; this.menuTimer = 2.5; this.busy = false; this.flash = null;
    this.target = [0, 0, 0]; this.quality = 1;
    this.fr = 1; this.vf = 1; this.frT = 1; this.vfT = 1; this.hasteGlow = [false, false];
    this.meshes = {};
    this.build();
    this.setSkin('classic', 'classic');
  }
  build() {
    const R = this.R, M = this.meshes;
    M.dot = R.mesh(Prim.disc(1, 24, 1, 1, [1,1,1])); M.ring = R.mesh(Prim.ring(.78, 1, 36, 1, 1, [1,1,1])); M.tile = R.mesh(Prim.plane(1, 1, [1,1,1]));
    M.ringSoft = R.mesh(Prim.ring(.55, 1, 36, 0, 1, [1,1,1]));
    M.shadow = R.mesh(Prim.disc(1, 20, .5, 0, [0,0,0]));
    M.floor = R.mesh(Prim.disc(1, 48, .4, 0, [0,0,0]));
    M.sphere = R.mesh(Prim.sphere(1, 16, 12, [1,1,1])); M.cone = R.mesh(Prim.cone(1, 1, 10, [1,1,1])); M.cyl = R.mesh(Prim.cyl(1, 1, 16, [1,1,1]));
    M.box = R.mesh(Prim.box(1, 1, 1, [1,1,1]));
    const ice = Prim.box(.86, .8, .86, [.62, .88, 1]);
    for (const [x, z, h, r] of [[-.4,-.4,.55,.13],[.4,-.4,.7,.12],[-.4,.4,.65,.12],[.4,.4,.5,.14]]) ice.append(Prim.cone(r, h, 6, [.85, .97, 1]), M4.T(x, .35, z));
    M.ice = R.mesh(ice);
    M.stone = R.mesh((() => {
      const s = Prim.box(.9, .75, .9, [.62, .56, .5], [.78, .72, .64]);
      s.append(Prim.box(.5, .2, .5, [.7, .64, .56], [.84, .78, .7]), M4.T(0, .47, 0));
      s.append(Prim.box(.18, .14, .18, [.55, .5, .45]), M4.T(.3, -.32, .46)); s.append(Prim.box(.14, .1, .14, [.5, .46, .42]), M4.T(-.4, -.34, .45));
      return s;
    })());
    M.col = R.mesh(Prim.lathe([[0,0],[1,0],[1,1],[0,1]], 20, [1,1,1]));
    this.cache = {};
  }
  setSkin(boardId, setId) {
    const gl = this.gl, R = this.R, free = m => { if (m) { gl.deleteBuffer(m.vb); gl.deleteBuffer(m.ib); } };
    const b = Skins.boards.find(x => x.id === boardId) || Skins.boards[0], s = Skins.sets.find(x => x.id === setId) || Skins.sets[0];
    this.board = b; this.set = s; this.boardId = b.id; this.setId = s.id;
    free(this.bm); free(this.glowM);
    const m = new MB();
    m.append(Prim.box(9.5, .5, 9.5, b.F), M4.T(0, -.25, 0));
    m.append(Prim.box(9.5, .18, 9.5, b.F.map(v => Math.min(1, v * 1.2))), M4.T(0, -.02, 0)); // lip
    m.append(Prim.box(8.2, .12, 8.2, b.F.map(v => v * .5)), M4.T(0, .02, 0));
    let seed = 7; const rn = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      const dark = (r + c) & 1, base = dark ? b.D : b.L; let col = base;
      if (b.pattern === 'wood') { const v = .9 + rn() * .16; col = base.map(x => Math.min(1, x * v)); }
      else if (b.pattern === 'marble') { const v = .86 + rn() * .14; col = base.map(x => Math.min(1, x * v)); }
      else if (b.pattern === 'grad') { const t = r / 7; col = base.map((x, k) => Math.min(1, x * (.92 + t * .12))); }
      const sq = Prim.box(.985, .1, .985, col);
      m.append(sq, M4.T(c - 3.5, .06, r - 3.5));
    }
    this.bm = R.mesh(m);
    if (b.G) {
      const gm = new MB();
      gm.append(Prim.box(8.12, .02, .08, [1,1,1]), M4.T(0, .115, -4.04)); gm.append(Prim.box(8.12, .02, .08, [1,1,1]), M4.T(0, .115, 4.04));
      gm.append(Prim.box(.08, .02, 8.0, [1,1,1]), M4.T(-4.04, .115, 0)); gm.append(Prim.box(.08, .02, 8.0, [1,1,1]), M4.T(4.04, .115, 0));
      this.glowM = R.mesh(gm);
    } else this.glowM = null;
    ['A', 'B'].forEach((k, side) => { free(this.meshes['m' + k]); free(this.meshes['k' + k]); const col = side ? s.B : s.A; this.meshes['m' + k] = R.mesh(this.pieceMesh(s, col, false)); this.meshes['k' + k] = R.mesh(this.pieceMesh(s, col, true)); });
  }
  pieceMesh(s, col, king) {
    const sh = (v, f) => v.map(x => Math.max(0, Math.min(1, x * f)));
    let prof;
    if (s.shape === 'disc') prof = [[0,0,.8],[.42,0,.8],[.43,.05,.9],[.41,.17,1],[.36,.22,1],[.3,.23,1],[.26,.205,.9],[0,.205,.9]];
    else if (s.shape === 'dome') prof = [[0,0,.8],[.42,0,.8],[.43,.06,.9],[.41,.16,1],[.34,.25,1.04],[.2,.31,1.08],[0,.33,1.1]];
    else if (s.shape === 'ridge') prof = [[0,0,.8],[.42,0,.8],[.44,.04,.9],[.42,.1,.95],[.4,.16,1],[.36,.2,1.05],[.3,.205,1],[.27,.22,1.1],[.2,.23,1.1],[.17,.205,.95],[0,.2,.95]];
    else prof = [[0,0,.75],[.38,0,.8],[.44,.08,.92],[.38,.18,1.02],[.28,.27,1.08],[.12,.33,1.12],[0,.34,1.15]];
    const seg = s.shape === 'gem' ? 10 : 22, m = Prim.lathe(prof, seg, col), top = prof[prof.length - 2][1] + .01;
    if (king) {
      const up = Prim.lathe(prof, seg, col); m.append(up, M4.mul(M4.T(0, top - .02, 0), M4.S(.82, .95, .82)));
      const y = top * 1.95 - .03, ring = Prim.torus(.25, .045, 14, 6, GOLD); m.append(ring, M4.T(0, y - .02, 0));
      for (let i = 0; i < 5; i++) { const a = i / 5 * Math.PI * 2; m.append(Prim.cone(.055, .17, 6, GOLD), M4.T(Math.cos(a) * .25, y - .01, Math.sin(a) * .25)); }
      m.append(Prim.sphere(.065, 8, 6, [1, .35, .4]), M4.T(0, y + .03, 0));
    }
    return m;
  }
  meshFor(code) { return this.meshes[(code & 1 ? 'm' : 'k') + (code < 3 ? 'A' : 'B')]; }
  /* ---------- tween helpers ---------- */
  tween(dur, fn, ease) { return new Promise(res => this.tw.push({ t: 0, dur: Math.max(.001, dur), fn, ease: ease || lin, res })); }
  wait(s) { return this.tween(s, () => {}); }
  addFx(o) { this.fx.push(o); return o; }
  /* ---------- state ---------- */
  mkPiece(id, code, i) { return { id, code, x: cx(i), z: cz(i), y: 0, s: 1, a: 1, rot: 0, fr: 0, sh: 0, frA: 0, shA: 0, lift: 0, cell: i, hide: false, tilt: 0 }; }
  loadState(S) {
    this.pieces.clear(); this.blocks.clear(); this.meteors.clear(); this.ghosts = []; this.ghostB = []; this.fx.length = 0; this.tw.length = 0; this.marks = [];
    for (let i = 0; i < 64; i++) { if (S.c[i]) { const p = this.mkPiece(S.id[i], S.c[i], i); p.fr = S.fr[i]; p.sh = S.sh[i]; p.frA = p.fr ? 1 : 0; p.shA = p.sh ? 1 : 0; this.pieces.set(p.id, p); } if (S.bl[i]) this.blocks.set(i, { y: 0, s: 1, a: 1, t: S.bl[i] }); }
    for (const m of S.mt) this.meteors.set(m.i, { t: 0 });
  }
  syncTo(S, dur) {
    dur = dur === undefined ? .3 : dur; const seen = new Set(), ps = [];
    for (let i = 0; i < 64; i++) {
      const code = S.c[i]; if (!code) continue; const id = S.id[i]; seen.add(id);
      let p = this.pieces.get(id);
      if (!p) { p = this.mkPiece(id, code, i); p.s = 0; this.pieces.set(id, p); this.burst(p.x, .3, p.z, GOLD, 12, 1.4); }
      if (p.code !== code) { p.code = code; if (!p.flip) { p.flip = true; ps.push(this.tween(.5, k => { p.rot = Math.PI * 2 * eo(k); p.y = Math.sin(k * Math.PI) * .5; }, lin).then(() => { p.rot = 0; p.y = 0; p.flip = false; })); this.burst(p.x, .4, p.z, GOLD, 16, 1.8); } }
      p.fr = S.fr[i]; p.sh = S.sh[i]; p.cell = i;
      const tx = cx(i), tz = cz(i);
      if (Math.abs(p.x - tx) > .01 || Math.abs(p.z - tz) > .01 || p.s < 1 || p.a < 1 || p.y > 0) {
        const x0 = p.x, z0 = p.z, s0 = p.s, y0 = p.y, a0 = p.a;
        ps.push(this.tween(dur, k => { p.x = x0 + (tx - x0) * k; p.z = z0 + (tz - z0) * k; p.s = s0 + (1 - s0) * k; p.a = a0 + (1 - a0) * k; p.y = y0 * (1 - k); }, eio));
      }
    }
    for (const [id, p] of [...this.pieces]) if (!seen.has(id)) { this.pieces.delete(id); this.ghost(p); }
    // blocks
    for (let i = 0; i < 64; i++) {
      const has = this.blocks.has(i);
      if (S.bl[i] && !has) { const b = { y: 0, s: 0, a: 1, t: S.bl[i] }; this.blocks.set(i, b); this.tween(.55, k => { b.s = k; }, eob); this.dust(cx(i), cz(i), [.78, .72, .64], 14); }
      else if (!S.bl[i] && has) { const b = this.blocks.get(i); this.blocks.delete(i); this.dust(cx(i), cz(i), [.78, .72, .64], 18); this.ghostBlock(i, b); }
      else if (S.bl[i]) this.blocks.get(i).t = S.bl[i];
    }
    const mset = new Set(S.mt.map(m => m.i));
    for (const i of mset) if (!this.meteors.has(i)) this.meteors.set(i, { t: 0 });
    for (const i of [...this.meteors.keys()]) if (!mset.has(i) && !this.meteors.get(i).falling) this.meteors.delete(i);
    return Promise.all(ps);
  }
  ghost(p) { // fade out a removed piece
    const q = Object.assign({}, p); this.ghosts = this.ghosts || []; this.ghosts.push(q);
    this.tween(.35, k => { q.s = p.s * (1 - k); q.a = 1 - k; q.y = p.y + k * .3; }, eo).then(() => { const i = this.ghosts.indexOf(q); if (i >= 0) this.ghosts.splice(i, 1); });
  }
  ghostBlock(i, b) { const q = { y: 0, s: 1, a: 1, x: cx(i), z: cz(i) }; this.ghostB = this.ghostB || []; this.ghostB.push(q); this.tween(.4, k => { q.s = 1 - k; q.y = -k * .5; }, eo).then(() => { const k = this.ghostB.indexOf(q); if (k >= 0) this.ghostB.splice(k, 1); }); }
  /* ---------- piece animations ---------- */
  hop(p, cells, opts) {
    opts = opts || {}; let chain = Promise.resolve(); let px = p.x, pz = p.z;
    cells.forEach((i, n) => {
      const x0 = px, z0 = pz, x1 = cx(i), z1 = cz(i); px = x1; pz = z1;
      const d = Math.hypot(x1 - x0, z1 - z0), dur = opts.fast ? .2 : (.22 + Math.min(.4, d * .06)), h = opts.king || d > 1.6 ? .22 : (opts.jump || cells.length > 1 || opts.cap ? .6 : .32);
      chain = chain.then(() => { if (opts.step) opts.step(n, i); let fired = false; return this.tween(dur, (e, k) => { p.x = x0 + (x1 - x0) * e; p.z = z0 + (z1 - z0) * e; p.y = Math.sin(e * Math.PI) * h; p.s = 1 + Math.sin(e * Math.PI) * .08; if (!fired && k > .5) { fired = true; if (opts.mid) opts.mid(n, i); } }, eio).then(() => { p.y = 0; p.s = 1; p.cell = i; this.puff(x1, z1); }); });
    });
    return chain;
  }
  puff(x, z) { for (let i = 0; i < 4; i++) { const a = Math.random() * 6.28; this.soft.emit(x, .08, z, Math.cos(a) * .6, .35, Math.sin(a) * .6, [.9, .85, .8, .4], .22, .5, 0, 2, 2); } }
  dust(x, z, col, n) { for (let i = 0; i < (n || 10); i++) { const a = Math.random() * 6.28, s = rnd(.4, 1.4); this.soft.emit(x + Math.cos(a) * .3, .12, z + Math.sin(a) * .3, Math.cos(a) * s, rnd(.3, 1.2), Math.sin(a) * s, [col[0], col[1], col[2], .6], rnd(.2, .45), rnd(.5, .9), 1, 1.5, 2.2); } }
  burst(x, y, z, col, n, sp, grav, size, life) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.28, e = rnd(-.2, 1), s = rnd(.4, 1) * (sp || 2), r = Math.sqrt(1 - e * e);
      this.glow.emit(x, y, z, Math.cos(a) * r * s, e * s + .6, Math.sin(a) * r * s, [col[0], col[1], col[2], 1], (size || .22) * rnd(.6, 1.2), (life || .8) * rnd(.6, 1.2), grav === undefined ? 2.2 : grav, 1.2, .2);
    }
  }
  shakeCam(v) { this.shake = Math.max(this.shake, v); }
  flashScreen(col, a) { this.flash = { col, a: a || .5 }; }
  /* ---------- camera / picking ---------- */
  setView(o) { if (o.yaw !== undefined) this.yawT = o.yaw; if (o.shiftX !== undefined) this.shiftXT = o.shiftX; if (o.shiftY !== undefined) this.shiftYT = o.shiftY; if (o.pitch !== undefined) this.pitch = o.pitch; }
  pick(px, py) {
    const r = this.R.ray(px, py); if (Math.abs(r.d[1]) < 1e-4) return -1;
    const t = (.16 - r.o[1]) / r.d[1]; if (t < 0) return -1;
    const x = r.o[0] + r.d[0] * t, z = r.o[2] + r.d[2] * t, c = Math.floor(x + 4), rr = Math.floor(z + 4);
    if (c < 0 || c > 7 || rr < 0 || rr > 7) return -1; return rr * 8 + c;
  }
  project(wx, wy, wz) { const p = M4.pt(this.R.vp, wx, wy, wz); return [(p[0] * .5 + .5) * this.cv.clientWidth, (1 - (p[1] * .5 + .5)) * this.cv.clientHeight]; }
  setLayout(o) { if (o.frac !== undefined) this.frT = o.frac; if (o.vfrac !== undefined) this.vfT = o.vfrac; if (o.sx !== undefined) this.shiftXT = o.sx; if (o.sy !== undefined) this.shiftYT = o.sy; if (o.snap) { this.fr = this.frT; this.vf = this.vfT; this.shiftX = this.shiftXT; this.shiftY = this.shiftYT; } }
  fit() {
    const R = this.R, asp = R.aspect, fov = this.menu ? 30 : 34, t = Math.tan(fov * Math.PI / 360);
    const wide = 5.4 / (t * asp * this.fr), tall = (this.menu ? 3.9 : 4.1) / (t * this.vf);
    this.fov = fov; this.dist = Math.max(wide, tall);
  }
  /* ---------- frame ---------- */
  frame(dt) {
    dt = Math.min(dt, .05) * (this.timeScale || 1); this.time += dt; const R = this.R;
    if (!this.paused) {
      for (let i = this.tw.length - 1; i >= 0; i--) { const w = this.tw[i]; w.t += dt; const k = Math.min(1, w.t / w.dur); w.fn(w.ease(k), k); if (k >= 1) { this.tw.splice(i, 1); w.res(); } }
      for (let i = this.fx.length - 1; i >= 0; i--) if (this.fx[i].update(dt) === false) this.fx.splice(i, 1);
      this.glow.update(dt); this.soft.update(dt);
      for (const p of this.pieces.values()) { p.frA += ((p.fr ? 1 : 0) - p.frA) * Math.min(1, dt * 7); p.shA += ((p.sh ? 1 : 0) - p.shA) * Math.min(1, dt * 7); }
      if (this.menu) this.menuTick(dt);
    }
    this.yaw += (this.yawT - this.yaw) * Math.min(1, dt * 4.2);
    this.shiftX += (this.shiftXT - this.shiftX) * Math.min(1, dt * 5); this.shiftY += (this.shiftYT - this.shiftY) * Math.min(1, dt * 5);
    this.shake *= Math.exp(-dt * 7);
    this.fr += (this.frT - this.fr) * Math.min(1, dt * 5); this.vf += (this.vfT - this.vf) * Math.min(1, dt * 5);
    this.fit();
    let yaw = this.yaw, pitch = this.pitch, d = this.dist;
    if (this.menu) { yaw += Math.sin(this.time * .22) * .35 - .15; pitch = .78 + Math.sin(this.time * .31) * .05; }
    const sh = this.shake, ex = this.target[0] + Math.sin(yaw) * Math.cos(pitch) * d + (Math.random() - .5) * sh * .4, ey = this.target[1] + Math.sin(pitch) * d + (Math.random() - .5) * sh * .3, ez = this.target[2] + Math.cos(yaw) * Math.cos(pitch) * d;
    R.setCamera([ex, ey, ez], this.target, this.fov, this.shiftX, this.shiftY);
    R.begin(); this.draw();
  }
  draw() {
    const R = this.R, M = this.meshes, ID = M4.id(), t = this.time;
    R.draw(M.floor, M4.trs(0, -.36, 0, 0, 7.4, 1, 7.4), { unlit: true, color: [.05, .02, .03], alpha: .55, noDepth: true });
    R.draw(this.bm, ID, { spec: .22, shin: 28 });
    if (this.glowM) { const G = this.board.G, k = .75 + Math.sin(t * 2) * .2; R.draw(this.glowM, ID, { unlit: true, color: G, emis: [G[0] * .4 * k, G[1] * .4 * k, G[2] * .4 * k] }); }
    // marks
    for (const m of this.marks) {
      const x = cx(m.i), z = cz(m.i), pu = 1 + Math.sin(t * 5 + m.i) * .08, col = m.col || [1, 1, 1];
      if (m.kind === 'dot') R.draw(M.dot, M4.trs(x, .125, z, 0, .17 * pu, 1, .17 * pu), { unlit: true, color: col, alpha: .85, noDepth: true });
      else if (m.kind === 'ring') R.draw(M.ring, M4.trs(x, .126, z, 0, .46 * pu, 1, .46 * pu), { unlit: true, color: col, alpha: .95, noDepth: true });
      else if (m.kind === 'tile') R.draw(M.tile, M4.trs(x, .118, z, 0, .96, 1, .96), { unlit: true, color: col, alpha: (m.a || .4) * (.85 + Math.sin(t * 4 + m.i) * .15), noDepth: true });
      else if (m.kind === 'soft') R.draw(M.tile, M4.trs(x, .117, z, 0, .96, 1, .96), { unlit: true, color: col, alpha: m.a || .25, noDepth: true });
    }
    // meteors markers
    for (const [i, m] of this.meteors) {
      const x = cx(i), z = cz(i), pu = 1 + Math.sin(t * 6) * .1;
      R.draw(M.ring, M4.trs(x, .13, z, 0, .62 * pu, 1, .62 * pu), { unlit: true, color: [1, .3, .2], alpha: .9, noDepth: true });
      R.draw(M.ringSoft, M4.trs(x, .13, z, t, .35 + .15 * Math.sin(t * 4), 1, .35 + .15 * Math.sin(t * 4)), { unlit: true, color: [1, .55, .2], alpha: .7, noDepth: true });
      if (Math.random() < .3) this.glow.emit(x + rnd(-.3, .3), .15, z + rnd(-.3, .3), 0, rnd(.5, 1.2), 0, [1, .45, .2, .8], .12, .8, 0, .5, .5);
    }
    // shadows + pieces
    const list = [...this.pieces.values()].concat(this.ghosts || []);
    for (const p of list) if (!p.hide) R.draw(M.shadow, M4.trs(p.x, .118, p.z, 0, .5 * p.s * (1 - p.y * .25), 1, .5 * p.s * (1 - p.y * .25)), { unlit: true, color: [0, 0, 0], alpha: .5 * p.a * Math.max(.2, 1 - p.y * .5), noDepth: true });
    const s = this.set;
    for (const p of list) {
      if (p.hide) continue; const mesh = this.meshFor(p.code); const bob = p.lift ? Math.sin(t * 5) * .03 : 0;
      const m = M4.trs(p.x, .115 + p.y + p.lift + bob, p.z, p.rot, p.s, p.s, p.s);
      let em = p.emis; if (!em && this.hasteGlow[p.code < 3 ? 0 : 1]) { const q = .5 + .5 * Math.sin(t * 7); em = [.32 + q * .2, .16 + q * .1, 0]; }
      if (p.tilt) { const T = M4.mul(m, M4.RZ(p.tilt)); R.draw(mesh, T, { spec: s.spec, shin: s.shin, rim: s.rim || .12, alpha: p.a, emis: em }); }
      else R.draw(mesh, m, { spec: s.spec, shin: s.shin, rim: s.rim || .12, alpha: p.a, emis: em || (p.sel ? [.1, .09, .02] : undefined) });
    }
    // blocks
    for (const [i, b] of this.blocks) R.draw(M.stone, M4.trs(cx(i), .1 + .375 * b.s + b.y, cz(i), 0, 1, b.s, 1), { spec: .1, shin: 8 });
    for (const q of this.ghostB || []) R.draw(M.stone, M4.trs(q.x, .1 + .375 * q.s + q.y, q.z, 0, 1, q.s, 1), { alpha: q.s });
    // translucent overlays
    for (const p of this.pieces.values()) {
      if (p.hide) continue;
      if (p.frA > .02) R.draw(M.ice, M4.trs(p.x, .5 + p.y, p.z, 0, 1, 1, 1), { alpha: .62 * p.frA, spec: 1, shin: 60, rim: .8, color: [.8, .95, 1], noDepth: true });
      if (p.shA > .02) { const k = 1.08 + Math.sin(t * 3 + p.id) * .04; R.draw(M.sphere, M4.trs(p.x, .38 + p.y, p.z, t * .5, .6 * k, .55 * k, .6 * k), { alpha: .3 * p.shA, color: [.5, .75, 1], spec: 1, shin: 80, rim: 1, noDepth: true, cullOff: false }); }
    }
    for (const f of this.fx) if (f.draw) f.draw(R, this);
    const ID2 = ID; this.soft.draw(ID2); this.glow.draw(ID2);
  }
  /* ---------- menu autoplay ---------- */
  menuInit() {
    const S = Rules.newState(); let side = 0;
    for (let n = 0; n < 14; n++) { const ms = Rules.genMoves(S, side); if (!ms.length) break; const m = ms[Math.random() * ms.length | 0]; Rules.apply(S, m); side = 1 - side; }
    this.mS = S; this.mSide = side; this.loadState(S); this.menuTimer = 1.8;
  }
  menuTick(dt) {
    this.menuTimer -= dt; if (this.menuTimer > 0 || this.mBusy) return;
    const ms = Rules.genMoves(this.mS, this.mSide);
    if (!ms.length || Rules.counts(this.mS).a + Rules.counts(this.mS).b < 6) { this.menuInit(); return; }
    const caps = ms.filter(m => m.caps.length); const m = (caps.length ? caps : ms)[Math.random() * (caps.length ? caps.length : ms.length) | 0];
    const p = this.pieces.get(this.mS.id[m.from]); this.mBusy = true; const S = this.mS;
    const res = Rules.apply(S, m);
    this.hop(p, m.path, { cap: m.caps.length > 0, mid: n => { if (m.caps[n] !== undefined) { const cp = this.pieces.get(res.capIds[n].id); if (cp) { this.pieces.delete(cp.id); this.ghost(cp); } } } }).then(() => this.syncTo(S, .2)).then(() => { this.mSide = 1 - this.mSide; this.menuTimer = rnd(1.6, 2.6); this.mBusy = false; });
  }
}
g.Scene = Scene; g.Ease = { lin, eo, eio, eob }; g.rnd = rnd; g.cellX = cx; g.cellZ = cz;
})(window);
