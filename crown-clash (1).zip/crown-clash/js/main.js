/* Crown & Clash — bootstrap: input, render loop, adaptive resolution, quality, fallbacks. */
(function (g) {
'use strict';
const { Profile, SFX, Scene, Game, UI, Vfx } = g;
const SCALE = [.6, .85, 1];
function fail(msg) {
  const d = document.createElement('div'); d.className = 'boot'; d.innerHTML = '<div><b style="font-size:26px">CROWN &amp; CLASH</b><br><br>' + msg + '</div>'; document.getElementById('root').append(d);
}
function boot() {
  const cv = document.getElementById('gl'); Profile.load();
  const s = Profile.d.settings;
  if (!s.qSet) s.quality = (window.matchMedia && matchMedia('(pointer:fine)').matches) ? 2 : 1;
  SFX.on = s.sound;
  let scene;
  try { scene = new Scene(cv); } catch (e) { fail('Не удалось запустить 3D-графику (WebGL).<br>Обновите браузер или включите аппаратное ускорение.<br><small style="opacity:.8">' + String(e.message || e).slice(0, 120) + '</small>'); return; }
  g.__scene = scene;
  scene.R.baseScale = SCALE[s.quality]; scene.R.scale = SCALE[s.quality];
  scene.setSkin(Profile.d.board, Profile.d.set); Vfx.init(scene);
  UI.init(scene); Game.init(scene, UI);
  scene.R.resize(); scene.menu = true; scene.menuInit(); scene.setLayout({ snap: true });
  /* input: taps on the canvas */
  let down = null;
  cv.addEventListener('pointerdown', e => { SFX.init(); down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
  cv.addEventListener('pointerup', e => {
    if (!down) return; const dx = e.clientX - down.x, dy = e.clientY - down.y, ok = dx * dx + dy * dy < 196 && performance.now() - down.t < 800; down = null;
    if (ok && Game.active) { const r = cv.getBoundingClientRect(); Game.onTap(scene.pick(e.clientX - r.left, e.clientY - r.top)); }
  });
  cv.addEventListener('pointercancel', () => { down = null; });
  document.addEventListener('pointerdown', () => SFX.init(), { passive: true });
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && Game.active && !Game.over) UI.pauseMenu(); });
  cv.addEventListener('webglcontextlost', e => { e.preventDefault(); UI.toast('Графика перезапускается...'); });
  cv.addEventListener('webglcontextrestored', () => location.reload());
  /* loop */
  const flashEl = document.getElementById('flash'); let last = performance.now(), ema = .016, slow = 0, since = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    if (document.hidden) { last = now; return; }
    const dt = Math.min(.1, Math.max(0, (now - last) / 1000)); last = now; since += dt;
    scene.R.resize(); scene.frame(dt);
    const f = scene.flash;
    if (f) { flashEl.style.background = 'rgb(' + (f.col[0] * 255 | 0) + ',' + (f.col[1] * 255 | 0) + ',' + (f.col[2] * 255 | 0) + ')'; flashEl.style.opacity = Math.max(0, f.a); f.a -= dt * 2.4; if (f.a <= 0) { scene.flash = null; flashEl.style.opacity = 0; } }
    ema += (dt - ema) * .05;
    if (since > 3 && ema > .034 && scene.R.scale > .58) { if (++slow > 80) { slow = 0; ema = .02; scene.R.resize(scene.R.scale * .85); } } else slow = 0;
  }
  requestAnimationFrame(loop);
  g.__ready = true;
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
