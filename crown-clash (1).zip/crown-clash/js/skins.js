/* Crown & Clash — skin catalogues (boards, checker sets, avatars). `level` = level at which the item unlocks. */
(function (g) {
'use strict';
const hex = h => [parseInt(h.slice(1,3),16)/255, parseInt(h.slice(3,5),16)/255, parseInt(h.slice(5,7),16)/255];
const boards = [
  { id: 'classic',  name: 'Классика',  level: 1,  light: '#ecd0a2', dark: '#8d5a3b', frame: '#5b3926', pattern: 'wood' },
  { id: 'mint',     name: 'Мята',      level: 3,  light: '#eaf6ef', dark: '#6bb596', frame: '#3e7c67', pattern: 'soft' },
  { id: 'midnight', name: 'Полночь',   level: 6,  light: '#7885b3', dark: '#222a55', frame: '#12153a', pattern: 'soft', glow: '#7aa2ff' },
  { id: 'sunset',   name: 'Закат',     level: 9,  light: '#ffdba6', dark: '#d85c62', frame: '#7c2f4f', pattern: 'grad' },
  { id: 'marble',   name: 'Мрамор',    level: 12, light: '#f3f1ee', dark: '#4f4f5a', frame: '#b99a4e', pattern: 'marble' },
  { id: 'neon',     name: 'Неон',      level: 15, light: '#1f2858', dark: '#0e1131', frame: '#090b20', pattern: 'soft', glow: '#37f5d0' },
  { id: 'lolly',    name: 'Леденец',   level: 18, light: '#fff0f6', dark: '#ff8fb8', frame: '#c94f86', pattern: 'grad' }
];
const sets = [
  { id: 'classic',  name: 'Классические', level: 1,  a: '#f6ecd9', b: '#7a2f2c', shape: 'disc',  spec: 0.35, shin: 30 },
  { id: 'ivory',    name: 'Слоновая кость', level: 4, a: '#fffaf0', b: '#25222a', shape: 'dome',  spec: 0.55, shin: 60 },
  { id: 'jade',     name: 'Нефрит',       level: 7,  a: '#d3f1e5', b: '#1d7058', shape: 'ridge', spec: 0.7,  shin: 70 },
  { id: 'candy',    name: 'Карамель',     level: 10, a: '#ffb6d3', b: '#8fd4ff', shape: 'dome',  spec: 0.6,  shin: 50 },
  { id: 'gold',     name: 'Золото и серебро', level: 13, a: '#ffd96a', b: '#c9d1de', shape: 'ridge', spec: 1.0, shin: 90 },
  { id: 'obsidian', name: 'Обсидиан',     level: 16, a: '#ff6b5c', b: '#1c1629', shape: 'gem',   spec: 0.9,  shin: 80, rim: 0.5 },
  { id: 'royal',    name: 'Королевские',  level: 19, a: '#ffe9a8', b: '#5b3aa8', shape: 'gem',   spec: 0.85, shin: 70, rim: 0.3 }
];
const avatars = [
  { id: 0,  name: 'Лис',        level: 1 },  { id: 1,  name: 'Сова',      level: 1 },
  { id: 2,  name: 'Осьминог',   level: 2 },  { id: 3,  name: 'Робот',     level: 5 },
  { id: 4,  name: 'Кактус',     level: 8 },  { id: 5,  name: 'Пингвин',   level: 11 },
  { id: 6,  name: 'Ракета',     level: 14 }, { id: 7,  name: 'Рыцарь',    level: 17 },
  { id: 8,  name: 'Кит',        level: 20 }, { id: 9,  name: 'Гриб',      level: 23 },
  { id: 10, name: 'Призрак',    level: 26 }, { id: 11, name: 'Кот',       level: 28 },
  { id: 12, name: 'Корона',     level: 30 }
];
boards.forEach(b => { b.L = hex(b.light); b.D = hex(b.dark); b.F = hex(b.frame); if (b.glow) b.G = hex(b.glow); });
sets.forEach(s => { s.A = hex(s.a); s.B = hex(s.b); });
g.Skins = { boards, sets, avatars, hex, MAX_LEVEL: 30 };
})(window);
