#!/usr/bin/env python3
"""Builds the single-file index.html (everything inlined, works offline / from file:// / in Android WebView)."""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent
html = (root / 'dev.html').read_text(encoding='utf-8')
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', lambda m: '<style>\n' + (root / m.group(1)).read_text(encoding='utf-8') + '\n</style>', html)
def inline(m):
    code = (root / m.group(1)).read_text(encoding='utf-8')
    assert '</script' not in code.lower(), m.group(1)
    return '<script>\n' + code + '\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
(root / 'index.html').write_text(html, encoding='utf-8')
print('index.html', round(len(html.encode('utf-8')) / 1024), 'KB')
